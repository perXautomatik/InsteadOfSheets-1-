create view ObjektIdRefRecTillsynsobjektID as

select outer1.recTillsynsobjektID,
       outer1.strObjektsNamn,
       outer2.ObjektID,
       (select count(ObjektID)
        from tempExcel.dbo.BladObjObjIdNamn
        where tempExcel.dbo.BladObjObjIdNamn.Objektnamn = outer2.Objektnamn
        group by tempExcel.dbo.BladObjObjIdNamn.Objektnamn
       ) as doubels
from EDPVisionRegionGotlandAvlopp.dbo.vwTrTillsynsobjekt as outer1
         RIGHT outer join tempExcel.dbo.BladObjObjIdNamn as outer2 on outer2.Objektnamn =
                                                                      outer1.strObjektsNamn AND
                                                                      outer2.ObjektID =
                                                                      case
                                                                          when 1 = (select count(ObjektID)
                                                                                    from tempExcel.dbo.BladObjObjIdNamn
                                                                                    where tempExcel.dbo.BladObjObjIdNamn.Objektnamn = outer2.Objektnamn
                                                                                    group by tempExcel.dbo.BladObjObjIdNamn.Objektnamn
                                                                          ) then outer2.ObjektID
                                                                          else (outer1.recTillsynsobjektID -
                                                                                (
                                                                                        (select top 1 min(
                                                                                                              EDPVisionRegionGotlandAvlopp.dbo.vwTrTillsynsobjekt.recTillsynsobjektID)
                                                                                         from EDPVisionRegionGotlandAvlopp.dbo.vwTrTillsynsobjekt
                                                                                         where outer2.Objektnamn =
                                                                                               EDPVisionRegionGotlandAvlopp.dbo.vwTrTillsynsobjekt.strObjektsNamn
                                                                                         group by EDPVisionRegionGotlandAvlopp.dbo.vwTrTillsynsobjekt.strObjektsNamn) -
                                                                                        (select top 1 min(tempExcel.dbo.BladObjObjIdNamn.ObjektID)
                                                                                         from tempExcel.dbo.BladObjObjIdNamn
                                                                                         where outer2.Objektnamn = tempExcel.dbo.BladObjObjIdNamn.Objektnamn
                                                                                         group by tempExcel.dbo.BladObjObjIdNamn.Objektnamn))) end
go

