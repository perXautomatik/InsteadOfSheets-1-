CREATE view MittVsEdpAvlopsAnl as select concat(100 * cast((cast(eq1 as int) + cast(eq2 as int) + cast(eq3 as int) + cast(eq4 as int) + cast(eq5 as int) +
                          cast(eq6 as int)) as float) / 8.0, '%') as procentColumnerKorrekt,
       *
from (select asd._ObjektID_,
             q.recTillsynsobjektID,

             q.strBoendetyp,
             dbo.stringComparision(q.strBoendetyp, asd.flikAvloppsänlaggniBoendetyp) as eq1,
             asd.flikAvloppsänlaggniBoendetyp,

             q.strVatten,
             dbo.stringComparision(q.strVatten, asd._Vatten_)                        as eq2,
             asd._Vatten_,


             q.intByggnadsaar,
             dbo.stringComparision(q.intByggnadsaar,
                                   asd.flikAvloppsanläggnByggnadsår)                 as eq3,
             asd.flikAvloppsanläggnByggnadsår,


             q.datBeslutsdatum,
             dbo.stringComparision(CONVERT(VARCHAR(10), q.datBeslutsdatum, 112),
                                   _flik_Avloppsanläg_Beslutsdatum_)                 as eq4,
             asd._flik_Avloppsanläg_Beslutsdatum_,


             q.datBesiktningsdatum,
             dbo.stringComparision(CONVERT(VARCHAR(10), q.datBesiktningsdatum, 112),
                                   _flik_Avloppsa_Besiktningsdatum_)                 as eq5,
             asd._flik_Avloppsa_Besiktningsdatum_,


             q.strEfterfoeljandereningRecipient,
             dbo.stringComparision(q.strEfterfoeljandereningRecipient,
                                   asd._Recipient_)                                  as eq6,
             asd._Recipient_


      from EDPVisionRegionGotlandAvlopp.dbo.tbTrEaAvloppsanlaeggning as q
               join (select recTillsynsobjektID, ObjektID from master.dbo.ObjektIdRefRecTillsynsobjektID) nycklar
                    on nycklar.recTillsynsobjektID = q.recTillsynsobjektID
               left outer join
           tempExcel.dbo.BladObjPåkoppladFastighet as asd on
               nycklar.[ObjektID] = asd._ObjektID_

      where _ObjektID_ is not null) sel
go

