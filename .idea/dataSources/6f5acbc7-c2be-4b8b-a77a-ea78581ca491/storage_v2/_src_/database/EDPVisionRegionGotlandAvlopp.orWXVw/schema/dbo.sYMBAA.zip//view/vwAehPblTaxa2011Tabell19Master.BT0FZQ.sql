

CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell19Master]
AS
SELECT     tbAehPblTaxa2011Tabell19Master.recTabell19ID, 
           recMasterID as 'intRecnum', 
		   recMasterID, 
		   strObjekt, 
		   strBeskrivning, 
		   intHF1, 
		   recTaxa2011ID,
		   intHF2
FROM         dbo.tbAehPblTaxa2011Tabell19Master
LEFT OUTER JOIN vwAehPblTaxa2011Tabell19 
ON vwAehPblTaxa2011Tabell19.recTabell19ID = tbAehPblTaxa2011Tabell19Master.recTabell19ID



go

