
CREATE VIEW [dbo].[vwTrLiDricksvattenParametrar]
AS
SELECT     recParameterID, strParameter, recTillsynsobjektID, strRapporteringsID
FROM         dbo.tbTrLiDricksvattenParametrar
go

