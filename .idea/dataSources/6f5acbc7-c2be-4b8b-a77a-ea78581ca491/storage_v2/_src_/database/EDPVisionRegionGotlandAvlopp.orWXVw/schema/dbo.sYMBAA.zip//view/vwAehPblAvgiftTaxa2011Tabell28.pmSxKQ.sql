
CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell28]
AS
SELECT
  dbo.tbAehPblAvgiftTaxa2011Tabell28.recPblAvgiftTaxa2011Tabell28ID,
  dbo.tbAehPblAvgiftTaxa2011Tabell28.recPblAvgiftTaxa2011Tabell28ID AS intRecnum,
  dbo.tbAehPblAvgiftTaxa2011Tabell28.recAvgiftID,
  dbo.tbAehPblAvgiftTaxa2011Tabell28.decAvgift,
  dbo.tbAehPblAvgiftTaxa2011Tabell28.decAaf,
  dbo.tbAehPblAvgiftTaxa2011Tabell28.decmPBB,
  dbo.tbAehPblAvgiftTaxa2011Tabell28.decN,
  dbo.tbAehPblAvgiftTaxa2011Tabell28.decAreadm2,
  dbo.tbAehPblAvgiftTaxa2011Tabell28.bolDebiterad
FROM    dbo.tbAehPblAvgiftTaxa2011Tabell28

go

