


CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell08PlanavgiftOberoende]
AS
SELECT		  recPblAvgiftTaxa2011Tabell08ID
			, recPblAvgiftTaxa2011Tabell08PlanavgiftOberoendeID
			, recPblAvgiftTaxa2011Tabell08PlanavgiftOberoendeID as 'intRecnum'
			, strObjekt
			, strBeskrivning
			, intPF
FROM         dbo.tbAehPblAvgiftTaxa2011Tabell08PlanavgiftOberoende
go

