
CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell18]
AS
SELECT
  dbo.tbAehPblAvgiftTaxa2011Tabell18.recPblAvgiftTaxa2011Tabell18ID, 
  dbo.tbAehPblAvgiftTaxa2011Tabell18.recPblAvgiftTaxa2011Tabell18ID AS intRecnum, 
  dbo.tbAehPblAvgiftTaxa2011Tabell18.recAvgiftID, 
  dbo.tbAehPblAvgiftTaxa2011Tabell18.bolDebiterad,
  dbo.tbAehPblAvgiftTaxa2011Tabell18.bolTidsersaettning,
  dbo.tbAehPblAvgiftTaxa2011Tabell18.bolHandlaeggningsfaktor,
  dbo.tbAehPblAvgiftTaxa2011Tabell18.decAvgiftTotalt,
  dbo.tbAehPblAvgiftTaxa2011Tabell18.decmPBB
FROM dbo.tbAehPblAvgiftTaxa2011Tabell18

go

