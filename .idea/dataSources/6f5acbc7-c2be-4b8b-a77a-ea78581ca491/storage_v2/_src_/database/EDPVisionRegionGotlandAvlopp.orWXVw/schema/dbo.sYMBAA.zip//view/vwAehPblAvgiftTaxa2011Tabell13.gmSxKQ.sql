
CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell13]
AS
SELECT     
  dbo.tbAehPblAvgiftTaxa2011Tabell13.recPblAvgiftTaxa2011Tabell13ID, 
  dbo.tbAehPblAvgiftTaxa2011Tabell13.recAvgiftID, 
  dbo.tbAehPblAvgiftTaxa2011Tabell13.recPblAvgiftTaxa2011Tabell13ID AS intRecnum, 
  dbo.tbAehPblAvgiftTaxa2011Tabell13.bolHaemtaHF1,
  dbo.tbAehPblAvgiftTaxa2011Tabell13.bolHaemtaHF2,
  dbo.tbAehPblAvgiftTaxa2011Tabell13.bolDebiterad,
  dbo.tbAehPblAvgiftTaxa2011Tabell13.bolTidsersaettning,
  dbo.tbAehPblAvgiftTaxa2011Tabell13.bolHandlaeggningsfaktor,
  dbo.tbAehPblAvgiftTaxa2011Tabell13.decAvgift,
  dbo.tbAehPblAvgiftTaxa2011Tabell13.decHF1,
  dbo.tbAehPblAvgiftTaxa2011Tabell13.decHF2,
  dbo.tbAehPblAvgiftTaxa2011Tabell13.decOF,
  dbo.tbAehPblAvgiftTaxa2011Tabell13.decmPBB,
  dbo.tbAehPblAvgiftTaxa2011Tabell13.decN,
  dbo.tbAehPblAvgiftTaxa2011Tabell13.decHF1Justering,
  dbo.tbAehPblAvgiftTaxa2011Tabell13.decHF2Justering,
  dbo.tbAehPblAvgiftTaxa2011Tabell13.decOFJustering
FROM dbo.tbAehPblAvgiftTaxa2011Tabell13

go

