CREATE VIEW [dbo].[vwVisFakturaFilUtdata]
AS
SELECT     dbo.tbVisFakturaFilUtdata.*
FROM         dbo.tbVisFakturaFilUtdata
go

