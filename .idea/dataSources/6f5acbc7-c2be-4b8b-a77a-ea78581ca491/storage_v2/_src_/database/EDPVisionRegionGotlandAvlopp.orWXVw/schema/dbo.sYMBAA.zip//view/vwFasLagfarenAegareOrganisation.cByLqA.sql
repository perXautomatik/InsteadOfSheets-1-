CREATE VIEW [dbo].[vwFasLagfarenAegareOrganisation]
AS
SELECT     dbo.tbFasLAGF.recLAGF AS intRecNum, dbo.tbFasLAGF.strFNRID, dbo.tbFasLAGF.strOTYP, dbo.tbFasLAGF.strDATUMLOP, dbo.tbFasLAGF.strDBNRID, 
                      dbo.tbFasLAGF.strFANG, dbo.tbFasLAGF.strFANGDATUM, dbo.tbFasLAGF.strKOPTYP, dbo.tbFasLAGF.strINSKDATUM, dbo.tbFasLAGF.strANDEL, 
                      dbo.tbFasLAGF.strPERSONNR, dbo.tbFasLAGF.strLAGFANM, dbo.tbFasLAGF.strNAMN, dbo.tbFasORG.strORGNAMN, dbo.tbFasORG.strORGADR_CO, 
                      dbo.tbFasORG.strORGUTAADR1, dbo.tbFasORG.strORGUTAADR2, dbo.tbFasORG.strPOSTNR, dbo.tbFasORG.strPOSTORT, dbo.tbFasORG.strLAND, 
                      dbo.tbFasLAGF.intKOPSUM
FROM         dbo.tbFasLAGF INNER JOIN
                      dbo.tbFasORG ON dbo.tbFasLAGF.strPERSONNR = dbo.tbFasORG.strORGNRID
go

