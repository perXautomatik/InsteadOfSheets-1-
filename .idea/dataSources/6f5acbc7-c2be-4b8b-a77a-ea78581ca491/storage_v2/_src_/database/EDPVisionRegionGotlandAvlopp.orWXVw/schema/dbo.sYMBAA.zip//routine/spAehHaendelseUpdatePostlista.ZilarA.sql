CREATE PROCEDURE [dbo].[spAehHaendelseUpdatePostlista]
  @recHaendelseID int,
  @recDiarieAarsSerieID int
AS
BEGIN
  SET NOCOUNT ON;
  
  UPDATE tbAehHaendelse SET
    strTillhoerPostlista = ISNULL(tbAehDiarieSerie.strDiarieSerieKod, '') + 
      ISNULL('-' +   CONVERT(VARCHAR, tbAehDiarieAarsSerie.intDiarieAar), '') + 
      ISNULL('-P' + CONVERT(VARCHAR, tbAehHaendelse.intLoepnummer), '')
  FROM tbAehHaendelse
  LEFT OUTER JOIN tbAehDiarieAarsSerie
    ON tbAehDiarieAarsSerie.recDiarieAarsSerieID = @recDiarieAarsSerieID
  LEFT OUTER JOIN tbAehDiarieSerie 
    ON tbAehDiarieSerie.recDiarieSerieID = tbAehDiarieAarsSerie.recDiarieSerieID
  WHERE tbAehHaendelse.recHaendelseID = @recHaendelseID
END
go

