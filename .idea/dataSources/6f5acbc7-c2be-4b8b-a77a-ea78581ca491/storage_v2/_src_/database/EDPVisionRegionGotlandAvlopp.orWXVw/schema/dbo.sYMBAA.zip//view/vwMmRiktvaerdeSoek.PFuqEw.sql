CREATE VIEW dbo.vwMmRiktvaerdeSoek
AS
SELECT     recRiktvaerdeNatID AS recRiktvaerdeSoekID, guidAemneID, guidRiktvaerdetypID, strMarkanvaendning, strMatris, strMarktaethet, intOrganiskHalt,
                      intLerhalt, decFraanDjup, decTillDjup, intAartal, decVaerde, strEnhet, strAemneNamn, strAemneKemBeteckning, bolEditOk, strRiktvaerdetypNamn,
                      recRiktvaerdeNatID AS intRecnum, 'Nat' AS strTabellnamn, strKommentar
FROM         dbo.vwMmRiktvaerdeNat
UNION ALL
SELECT     recRiktvaerdeEgetID AS recRiktvaerdeSoekID, guidAemneID, guidRiktvaerdetypID, strMarkanvaendning, strMatris, strMarktaethet, intOrganiskHalt,
                      intLerhalt, decFraanDjup, decTillDjup, intAartal, decVaerde, strEnhet, strAemneNamn, strAemneKemBeteckning, bolEditOk, strRiktvaerdetypNamn,
                      recRiktvaerdeEgetID AS intRecnum, 'Eget' AS strTabellnamn, strKommentar
FROM         dbo.vwMmRiktvaerdeEget
go

