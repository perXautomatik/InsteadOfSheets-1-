
        CREATE TRIGGER TRG_tbMhMoetespunktHaendelse_SetMoetesDatum ON tbMhMoetespunktHaendelse
        AFTER  INSERT,DELETE

        AS
BEGIN
        DECLARE heandelseID_cursor CURSOR FAST_FORWARD
        FOR
            SELECT recHaendelseID FROM INSERTED UNION SELECT recHaendelseID FROM DELETED
        OPEN heandelseID_cursor
        DECLARE @haendelseID as INT
        FETCH NEXT FROM heandelseID_cursor INTO @haendelseID
        WHILE (@@fetch_status = 0)
        BEGIN

            DECLARE	aerendeid_cursor CURSOR FAST_FORWARD
            FOR
                SELECT recAerendeID FROM tbAehAerendeHaendelse taah WHERE taah.recHaendelseID = @haendelseID
            OPEN aerendeid_cursor
            DECLARE @aerendeId as INT
            FETCH NEXT FROM aerendeid_cursor INTO @aerendeId
            WHILE (@@fetch_status = 0)
            BEGIN
                UPDATE tbAehAerende SET datMoetesDatum = dbo.FnAehAerendeMoetesDatum(@aerendeId)
                WHERE recAerendeID = @aerendeId
            FETCH NEXT FROM aerendeid_cursor INTO @aerendeId
            END
            CLOSE aerendeid_cursor
            DEALLOCATE aerendeid_cursor

        FETCH NEXT FROM heandelseID_cursor INTO @haendelseID
        END

        CLOSE heandelseID_cursor
		DEALLOCATE heandelseID_cursor
END
        go

