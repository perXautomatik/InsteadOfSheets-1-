
CREATE VIEW vwTrTillsynsbesoeksStatistik
AS
SELECT vwTrTillsynsbesoek.recTillsynsbesoekID,
  vwTrTillsynsbesoek.recTillsynsbesoekID AS intRecnum,
  (SELECT COUNT(*) FROM tbTrChecklistaPunkt 
   WHERE recTillsynsbesoekID = vwTrTillsynsbesoek.recTillsynsbesoekID
   AND recChecklistamallVersionVaerdenID IN (SELECT recChecklistamallVersionVaerdenID 
                                             FROM tbTrChecklistamallVersionVaerden 
                                             WHERE strVaerde = 'A')) AS intAntalA,
  (SELECT COUNT(*) FROM tbTrChecklistaPunkt 
   WHERE recTillsynsbesoekID = vwTrTillsynsbesoek.recTillsynsbesoekID
   AND recChecklistamallVersionVaerdenID IN (SELECT recChecklistamallVersionVaerdenID 
                                             FROM tbTrChecklistamallVersionVaerden 
                                             WHERE strVaerde = 'AA')) AS intAntalAA,
  (SELECT COUNT(*) FROM tbTrChecklistaPunkt 
   WHERE recTillsynsbesoekID = vwTrTillsynsbesoek.recTillsynsbesoekID
   AND recChecklistamallVersionVaerdenID IN (SELECT recChecklistamallVersionVaerdenID 
                                             FROM tbTrChecklistamallVersionVaerden 
                                             WHERE strVaerde = 'EK')) AS intAntalEK,
  (SELECT COUNT(*) FROM tbTrChecklistaPunkt 
   WHERE recTillsynsbesoekID = vwTrTillsynsbesoek.recTillsynsbesoekID
   AND recChecklistamallVersionVaerdenID IN (SELECT recChecklistamallVersionVaerdenID 
                                             FROM tbTrChecklistamallVersionVaerden 
                                             WHERE strVaerde = 'EA')) AS intAntalEA,
  (SELECT COUNT(*) FROM tbTrChecklistaPunkt 
   WHERE recTillsynsbesoekID = vwTrTillsynsbesoek.recTillsynsbesoekID
   AND recChecklistamallVersionVaerdenID IN (SELECT recChecklistamallVersionVaerdenID 
                                             FROM tbTrChecklistamallVersionVaerden 
                                             WHERE strVaerde = 'UA')) AS intAntalUA,
  (SELECT COUNT(*) FROM tbTrChecklistaPunkt 
   WHERE recTillsynsbesoekID = vwTrTillsynsbesoek.recTillsynsbesoekID
   AND recChecklistamallVersionVaerdenID IN (SELECT recChecklistamallVersionVaerdenID 
                                             FROM tbTrChecklistamallVersionVaerden 
                                             WHERE strVaerde = 'Ja')) AS intAntalJa,
  (SELECT COUNT(*) FROM tbTrChecklistaPunkt 
   WHERE recTillsynsbesoekID = vwTrTillsynsbesoek.recTillsynsbesoekID
   AND recChecklistamallVersionVaerdenID IN (SELECT recChecklistamallVersionVaerdenID 
                                             FROM tbTrChecklistamallVersionVaerden 
                                             WHERE strVaerde = 'Nej')) AS intAntalNej
FROM vwTrTillsynsbesoek
go

