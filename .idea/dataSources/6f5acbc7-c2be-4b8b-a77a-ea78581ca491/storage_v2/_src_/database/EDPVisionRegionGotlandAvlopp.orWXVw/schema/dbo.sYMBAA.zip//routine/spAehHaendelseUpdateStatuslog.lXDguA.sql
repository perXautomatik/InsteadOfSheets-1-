CREATE PROCEDURE [dbo].[spAehHaendelseUpdateStatuslog]
  @recHaendelseID int
AS
BEGIN
  SET NOCOUNT ON;
  
  UPDATE dbo.tbAehHaendelse SET recLastHaendelseStatusLogID = 
    ( SELECT TOP (1) recHaendelseStatusLogID FROM tbAehHaendelseStatusLog
      INNER JOIN tbAehHaendelseStatusLogTyp
        ON tbAehHaendelseStatusLog.recHaendelseStatusLogTypID = tbAehHaendelseStatusLogTyp.recHaendelseStatusLogTypID
        AND tbAehHaendelseStatusLogTyp.bolVisas = 1
      WHERE tbAehHaendelseStatusLog.recHaendelseID = @recHaendelseID
      ORDER BY datDatum DESC
    )
  WHERE recHaendelseID = @recHaendelseID

  UPDATE dbo.tbAehHaendelseData SET
    datDatum = dbo.tbAehHaendelseStatusLog.datDatum, 
    strLogKommentar = dbo.tbAehHaendelseStatusLog.strKommentar,
    strHaendelseStatusPresent = dbo.tbAehHaendelseStatusLogTyp.strHaendelseStatusPresent, 
    strHaendelseStatusLogTyp = dbo.tbAehHaendelseStatusLogTyp.strHaendelseStatusLogTyp, 
    strHaendelseStatusLocalizationCode = dbo.tbAehHaendelseStatusLogTyp.strLocalizationCode
  FROM dbo.tbAehHaendelseData
  LEFT OUTER JOIN dbo.tbAehHaendelse
    ON dbo.tbAehHaendelse.recHaendelseID = dbo.tbAehHaendelseData.recHaendelseID 
  LEFT OUTER JOIN dbo.tbAehHaendelseStatusLog 
    ON dbo.tbAehHaendelseStatusLog.recHaendelseStatusLogID = dbo.tbAehHaendelse.recLastHaendelseStatusLogID
  LEFT OUTER JOIN dbo.tbAehHaendelseStatusLogTyp 
    ON dbo.tbAehHaendelseStatusLogTyp.recHaendelseStatusLogTypID = dbo.tbAehHaendelseStatusLog.recHaendelseStatusLogTypID 
  WHERE tbAehHaendelseData.recHaendelseID = @recHaendelseID
END
go

