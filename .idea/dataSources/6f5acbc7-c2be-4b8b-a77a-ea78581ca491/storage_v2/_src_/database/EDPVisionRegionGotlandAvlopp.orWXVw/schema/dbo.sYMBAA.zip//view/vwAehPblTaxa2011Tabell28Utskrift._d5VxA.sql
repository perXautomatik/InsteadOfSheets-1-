
CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell28Utskrift]
AS
SELECT     tbAehPblTaxa2011Tabell28Utskrift.recTabell28ID, 
           recUtskriftID as 'intRecnum', 
		   recUtskriftID, 
		   strAatgaerd, 
		   strBeskrivning, 
		    recTaxa2011ID,
		   decAaf
FROM         dbo.tbAehPblTaxa2011Tabell28Utskrift
LEFT OUTER JOIN vwAehPblTaxa2011Tabell28 
ON vwAehPblTaxa2011Tabell28.recTabell28ID = tbAehPblTaxa2011Tabell28Utskrift.recTabell28ID


go

