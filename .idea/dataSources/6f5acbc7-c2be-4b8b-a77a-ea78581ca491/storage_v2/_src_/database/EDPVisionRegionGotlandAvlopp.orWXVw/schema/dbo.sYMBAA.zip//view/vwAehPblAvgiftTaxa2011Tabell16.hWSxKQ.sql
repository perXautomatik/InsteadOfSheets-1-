
CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell16]
AS
SELECT     
  dbo.tbAehPblAvgiftTaxa2011Tabell16.recAehPblAvgiftTaxa2011Tabell16ID, 
  dbo.tbAehPblAvgiftTaxa2011Tabell16.recAehPblAvgiftTaxa2011Tabell16ID AS intRecnum,
  dbo.tbAehPblAvgiftTaxa2011Tabell16.recAvgiftID, 
  dbo.tbAehPblAvgiftTaxa2011Tabell16.bolDebiterad,
  dbo.tbAehPblAvgiftTaxa2011Tabell16.decAvgift,
  dbo.tbAehPblAvgiftTaxa2011Tabell16.intHF,
  dbo.tbAehPblAvgiftTaxa2011Tabell16.decmPBB,
  dbo.tbAehPblAvgiftTaxa2011Tabell16.decN,
  dbo.tbAehPblAvgiftTaxa2011Tabell16.bolTidersaettning,
  dbo.tbAehPblAvgiftTaxa2011Tabell16.bolHandlaeggningsfaktor
FROM dbo.tbAehPblAvgiftTaxa2011Tabell16

go

