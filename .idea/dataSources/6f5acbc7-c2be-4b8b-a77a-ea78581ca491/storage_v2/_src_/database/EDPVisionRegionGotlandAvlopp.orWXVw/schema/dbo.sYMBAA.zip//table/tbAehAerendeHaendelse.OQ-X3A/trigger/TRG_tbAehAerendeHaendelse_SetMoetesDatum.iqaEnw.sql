
        -- =============================================
        -- Author:		David Svedberg,Dzenan Dabulhanic
        -- Create date: 2016-02-23
        -- Description:	<Description,,>
        -- =============================================
        CREATE TRIGGER TRG_tbAehAerendeHaendelse_SetMoetesDatum ON tbAehAerendeHaendelse
        AFTER INSERT,DELETE
        AS
        BEGIN
            -- SET NOCOUNT ON; added to prevent extra result sets from
            -- interfering with SELECT statements.
            SET NOCOUNT ON;
            DECLARE @recAerendeID INT
            DECLARE aerendeid_cursor CURSOR FAST_FORWARD
            FOR
            SELECT recAerendeID FROM INSERTED UNION SELECT recAerendeID FROM DELETED
            OPEN aerendeid_cursor
            FETCH NEXT FROM aerendeid_cursor INTO @recAerendeID
            WHILE (@@fetch_status = 0)
            BEGIN
                UPDATE tbAehAerende SET datMoetesDatum = dbo.FnAehAerendeMoetesDatum(@recAerendeID)
                WHERE tbAehAerende.recAerendeID = @recAerendeID
            FETCH NEXT FROM aerendeid_cursor INTO @recAerendeID
            END
            CLOSE aerendeid_cursor
            DEALLOCATE aerendeid_cursor

        END
        go

