
        CREATE TRIGGER HuvudHandlaggareUppgift ON tbVisUppgiftUser
        AFTER INSERT
        AS
        BEGIN
        -- SET NOCOUNT ON; added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;

        DECLARE insert_cursor CURSOR FAST_FORWARD
        FOR
        SELECT recUppgiftID FROM INSERTED
        OPEN insert_cursor
        DECLARE @recUppgiftID as INT
        FETCH NEXT FROM insert_cursor INTO @recUppgiftID
        WHILE (@@fetch_status = 0)
        BEGIN
            IF (SELECT COUNT(recVisUppgiftUserID) FROM tbVisUppgiftUser WHERE recUppgiftID = @recUppgiftID) = 1
            UPDATE tbVisUppgiftUser SET bolHuvudhandlaeggare = 1 WHERE recUppgiftID = @recUppgiftID
            FETCH NEXT FROM insert_cursor INTO @recUppgiftID
        END
        CLOSE insert_cursor
        DEALLOCATE insert_cursor
        END
        go

