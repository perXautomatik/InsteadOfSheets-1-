
CREATE VIEW [dbo].[vwTrTillsynsobjektSlvRapportering]
AS
SELECT     
					dbo.vwTrTillsynsobjekt.recTillsynsobjektID, 
					dbo.vwTrTillsynsobjekt.recTillsynsobjektID as intRecnum, 					
					dbo.vwTrTillsynsobjekt.strVerksamhetNamn, 
					dbo.vwTrTillsynsobjekt.strObjektsNamn, 
                    dbo.vwTrTillsynsobjekt.strHuvudfastighetFastighetsbeteckning, 
                    dbo.vwTrTillsynsobjekt.strStatus, 
                    dbo.vwTrTillsynsobjekt.datDatum, 
                    dbo.vwTrLiLivsmedel.strNivaa1, 
                    dbo.vwTrLiLivsmedel.strNivaa2, 
                    dbo.vwTrLiLivsmedel.strNivaa3, 
                    dbo.vwTrLiLivsmedel.strNivaa4, 
                    dbo.vwTrLiLivsmedel.datKlassningsdatum, 
                    dbo.vwTrLiLivsmedel.strRiskklasstyp, 
                    dbo.vwTrLiLivsmedel.strStorlek, 
                    dbo.vwTrLiLivsmedel.strKonsument,
                    dbo.vwTrLiLivsmedel.intRiskklass, 
                    dbo.vwTrLiLivsmedel.strErfarenhetsklass, 
                    dbo.vwTrTillsynsobjekt.decJusteradKontrolltid, 
                    dbo.vwTrLiLivsmedel.strAnlaeggningsnamn, 
                    dbo.vwTrLiLivsmedel.intMinskadOmfattning, 
                    dbo.vwTrLiLivsmedel.strParametrar
FROM         
			dbo.vwTrLiLivsmedel left outer join 
                      dbo.vwTrTillsynsobjekt
                      on dbo.vwTrTillsynsobjekt.recTillsynsobjektID = dbo.vwTrLiLivsmedel.recTillsynsobjektID

go

