
CREATE VIEW [dbo].[vwTrTillsynsobjektBranschkod]
AS
SELECT tbTrTillsynsobjektBranschkod.recTillsynsobjektBranschkodID
  , tbTrTillsynsobjektBranschkod.recTillsynsobjektBranschkodID AS intRecnum
  , tbTrTillsynsobjektBranschkod.recTillsynsobjektID
  , tbTrTillsynsobjektBranschkod.recBranschkodID 
  , tbTrTillsynsobjektBranschkod.bolHuvudBranschkod
  , tbTrBranschkod.strBranschkod
  , tbTrBranschkod.strUnderrubrik
  , tbTrBranschkod.strHuvudrubrik
  , tbTrBranschkod.strBeskrivning
FROM tbTrTillsynsobjektBranschkod
INNER JOIN tbTrBranschkod
ON tbTrBranschkod.recBranschkodID = tbTrTillsynsobjektBranschkod.recBranschkodID
go

