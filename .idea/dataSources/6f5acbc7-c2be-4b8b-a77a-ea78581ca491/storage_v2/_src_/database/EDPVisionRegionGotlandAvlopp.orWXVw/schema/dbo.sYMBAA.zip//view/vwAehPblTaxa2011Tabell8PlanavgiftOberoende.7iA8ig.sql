

CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell8PlanavgiftOberoende]
AS
SELECT     tbAehPblTaxa2011Tabell8PlanavgiftOberoende.recTabell8ID, 
           recPlanavgiftOberoendeID as 'intRecnum', 
		   recPlanavgiftOberoendeID, 
		   strObjekt,
		    strBeskrivning, 
			 recTaxa2011ID,
			intPF
FROM         dbo.tbAehPblTaxa2011Tabell8PlanavgiftOberoende
LEFT OUTER JOIN vwAehPblTaxa2011Tabell8
ON vwAehPblTaxa2011Tabell8.recTabell8ID = tbAehPblTaxa2011Tabell8PlanavgiftOberoende.recTabell8ID



go

