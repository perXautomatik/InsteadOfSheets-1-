

CREATE VIEW [dbo].[vwMhMoetespunkt]
AS
SELECT DISTINCT dbo.tbMhMoetespunkt.recMoetespunktID, dbo.tbMhMoetespunkt.intParagrafnummer,
  dbo.tbMhMoetespunkt.intOrdningsnummer, dbo.tbMhMoetespunkt.strMoetespunktRubrik,
  dbo.tbMhMoetespunkt.recMoeteID, dbo.tbMhMoetespunkt.strBeslut,
  dbo.tbMhMoetespunkt.strDelges, dbo.tbMhMoetespunkt.recMoetespunktID AS intRecnum,
  dbo.tbMhUtfall.guidUtfall, dbo.tbMhUtfall.recUtfallID, dbo.tbMhUtfall.strUtfall,
  u.strSignature, u.recHandlaeggareID, u.strFullName,
  dbo.tbMhMoetespunkt.bolParagrafKraevs, dbo.vwMhMoete.strMoete,
  dbo.vwMhMoete.strOrgannamn, dbo.vwMhMoete.recOrganID, dbo.vwMhMoete.datMoetesDatum,
  dbo.vwMhMoete.strStarttid, dbo.tbMhMoetespunkt.strBeslutstextFoerslag, dbo.tbMhMoetespunkt.strAnteckning,
  dbo.tbMhMoetespunkt.intAntalFiler,

--Enbart för dokumentmallar, kan flyttas till egen vy vid behov. Char(9) = Tab,  Char(13) = Carriage return, Char(10) Line feed
CAST(intOrdningsnummer AS NVARCHAR) + CHAR(9) + strMoetespunktRubrik + CHAR(13) + CHAR(10)  AS strOrdningsNummerOchMoetespunktRubrik

FROM dbo.tbMhMoetespunkt
LEFT OUTER JOIN dbo.vwMhMoete
  ON dbo.tbMhMoetespunkt.recMoeteID = dbo.vwMhMoete.recMoeteID
LEFT OUTER JOIN dbo.tbMhUtfall
  ON dbo.tbMhMoetespunkt.recUtfallID = dbo.tbMhUtfall.recUtfallID
LEFT OUTER JOIN dbo.vwVisHandlaeggareEDPUser AS u
  ON dbo.tbMhMoetespunkt.recHandlaeggareID = u.recHandlaeggareID
go

