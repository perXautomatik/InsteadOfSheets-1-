
CREATE VIEW [dbo].[vwAehAerende]
AS
SELECT dbo.tbAehAerende.recAerendeID
	,dbo.tbAehAerende.strDiarienummerSerie
	,dbo.tbAehAerende.intDiarienummerLoepNummer
	,dbo.tbAehAerendeData.strDiarienummer
	,dbo.tbAehAerende.strAerendemening
	,dbo.tbAehAerende.strSoekbegrepp
	,dbo.tbAehAerende.strAerendeKommentar
	,dbo.tbAehAerende.recFoervaltningID
	,dbo.tbAehAerende.recEnhetID
	,dbo.tbAehAerende.recAvdelningID
	,dbo.tbAehAerende.recExterntID
	,dbo.tbAehAerende.recDiarieAarsSerieID
	,dbo.tbAehAerende.strPublicering
	,dbo.tbAehAerendeData.recLastAerendeStatusLogID
	,dbo.tbAehAerende.recAerendeID AS intRecnum
	,dbo.tbAehAerendeData.strFastighetsbeteckning
	,dbo.tbAehAerendeData.strFnrID
	,dbo.tbAehAerendeData.recFastighetID
	,dbo.tbAehAerende.datInkomDatum
	,dbo.tbAehAerendeData.datDatum
	,dbo.tbAehAerendeData.strLogKommentar
	,dbo.tbAehAerendeData.strAerendeStatusPresent
	,dbo.tbAehAerendeData.strLocalizationCode
	,dbo.tbAehAerendeData.strSignature
	,dbo.tbEDPUser.strUserFirstName + ' ' + dbo.tbEDPUser.strUserSurName AS strUserVisasSom
	,dbo.tbAehAerendeData.intUserID
	,dbo.tbAehAerendeData.recDiarieSerieID
	,dbo.tbAehAerendeData.intDiarieAar
	,dbo.tbAehAerendeData.intSerieStartVaerde
	,dbo.tbAehAerendeData.strDiarieSerieKod
	,dbo.tbAehAerendeData.strSekretess
	,dbo.tbAehAerendeData.strBegraensa
	,dbo.tbAehAerendeData.strSekretessMyndighet
	,dbo.tbAehAerendeData.datSekretessDatum
	,dbo.tbAehAerende.recProjektID
	,dbo.tbAehAerendeData.recEnstakaKontaktID
	,dbo.tbAehAerendeData.strVisasSom
	,dbo.tbAehAerendeData.strGatuadress
	,dbo.tbAehAerendeData.strPostnummer
	,dbo.tbAehAerendeData.strPostort
	,dbo.tbAehAerendeData.strRoll
	,dbo.tbAehAerendeData.recKontaktRollID
	,dbo.tbAehAerendeData.recAerendeEnstakaKontaktID
	,dbo.tbAehAerende.recEnstakaFakturamottagareID
	,dbo.tbAehAerende.recKommunID
	,dbo.tbAehProjekt.strProjektNamn
	,dbo.tbAehHaendelseBeslut.datBeslutsDatum
	,dbo.tbAehHaendelseBeslut.strBeslutsNummer
	,dbo.tbAehHaendelseBeslut.strBeslutsutfall
	,dbo.tbAehHaendelseBeslut.recHaendelseID
	,dbo.tbAehHaendelseBeslut.recHaendelseBeslutID
	,dbo.tbAehAerendetyp.strAerendeTyp
	,dbo.tbAehAerendetyp.strAerendekategori
	,dbo.tbAehAerendetyp.strAerendetypKod
	,dbo.tbAehAerendetyp.recAerendetypID
	,dbo.tbAehAerendetyp.bolKomplettAerende
	,dbo.tbVisEnhet.strEnhetNamn
	,dbo.tbVisEnhet.strEnhetKod
	,dbo.tbVisFoervaltning.strFoervaltningNamn
	,dbo.tbVisFoervaltning.strFoervaltningKod
	,dbo.tbVisAvdelning.strAvdelningKod
	,dbo.tbVisAvdelning.strAvdelningNamn
	,fakturamottagarekontakt.strVisasSom AS strFakturamottagare
	,dbo.tbVisKommun.strKommunNamn
	,dbo.tbAehAerendeData.datKomplett
	,datMoetesDatum
	,dbo.tbAehHaendelseBeslut.intArbetsdagar
	,vwAehAerendeTotaltid.strSummaTidposter
	,dbo.tbAehAerende.recExternTjaenstID
	,dbo.tbVisExternTjaenst.strExternTjaenst
	,dbo.tbVisExternTjaenst.strETjaenstNamn
	,dbo.tbAehHaendelse.datHaendelseDatum AS datBeslutExpedierat
FROM dbo.tbAehAerende
LEFT OUTER JOIN dbo.tbAehAerendeData ON dbo.tbAehAerendeData.recAerendeID = dbo.tbAehAerende.recAerendeID
LEFT OUTER JOIN dbo.tbAehProjekt ON dbo.tbAehAerende.recProjektID = dbo.tbAehProjekt.recProjektID
LEFT OUTER JOIN dbo.tbAehHaendelseBeslut ON dbo.tbAehAerende.recLastHaendelseBeslutID = dbo.tbAehHaendelseBeslut.recHaendelseBeslutID
LEFT OUTER JOIN dbo.tbAehAerendetyp ON dbo.tbAehAerende.recAerendetypID = dbo.tbAehAerendetyp.recAerendetypID
LEFT OUTER JOIN dbo.tbVisEnhet ON dbo.tbAehAerende.recEnhetID = dbo.tbVisEnhet.recEnhetID
LEFT OUTER JOIN dbo.tbVisFoervaltning ON dbo.tbAehAerende.recFoervaltningID = dbo.tbVisFoervaltning.recFoervaltningID
LEFT OUTER JOIN dbo.tbVisAvdelning ON dbo.tbAehAerende.recAvdelningID = dbo.tbVisAvdelning.recAvdelningID
LEFT OUTER JOIN tbVisEnstakaKontakt AS fakturamottagarekontakt ON fakturamottagarekontakt.recEnstakaKontaktID = (
		SELECT recEnstakaKontaktID
		FROM tbVisEnstakafakturamottagare
		WHERE recEnstakaFakturamottagareID = tbAehAerende.recEnstakaFakturamottagareID
		)
LEFT OUTER JOIN dbo.tbVisKommun ON dbo.tbVisKommun.recKommunID = dbo.tbAehAerende.recKommunID
LEFT OUTER JOIN dbo.tbEDPUser ON dbo.tbEDPUser.intUserID = dbo.tbAehAerendeData.intUserID
LEFT OUTER JOIN dbo.vwAehAerendeTotaltid ON dbo.vwAehAerendeTotaltid.recAerendeID = tbAehAerende.recAerendeID
LEFT OUTER JOIN dbo.tbVisExternTjaenst ON dbo.tbVisExternTjaenst.recExternTjaenstID = tbAehAerende.recExternTjaenstID
LEFT OUTER JOIN dbo.tbAehHaendelse ON dbo.tbAehHaendelse.recHaendelseID = tbAehHaendelseBeslut.recHaendelseID
go

