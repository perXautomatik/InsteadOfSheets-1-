

CREATE VIEW [dbo].[vwTrKmKoeldMedium]
AS
    SELECT  dbo.tbTrKmKoeldmedium.recKoeldmediumID, 
            dbo.tbTrKmKoeldmedium.recKoeldmediumID AS intRecnum,
            dbo.tbTrKmKoeldmedium.strRNummer, 
            dbo.tbTrKmKoeldmedium.strAemnesNamn, 
            dbo.tbTrKmKoeldmedium.strKoeldmedieTyp, 
            dbo.tbTrKmKoeldmedium.decGWP, 
            dbo.tbTrKmKoeldmedium.bolEjAktuell
    FROM    dbo.tbTrKmKoeldmedium


go

