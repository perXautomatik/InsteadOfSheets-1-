
        CREATE TRIGGER HuvudFastighetSkyddsrumPaaObjekt ON tbTrSkSkyddsrumPaaObjektFastighet
        AFTER INSERT
        AS
        BEGIN
        -- SET NOCOUNT ON; added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;

        DECLARE insert_cursor CURSOR FAST_FORWARD
        FOR
        SELECT recSkyddsrumPaaObjektID FROM INSERTED
        OPEN insert_cursor
        DECLARE @recSkyddsrumPaaObjektID as INT
        FETCH NEXT FROM insert_cursor INTO @recSkyddsrumPaaObjektID
        WHILE (@@fetch_status = 0)
        BEGIN
            IF (SELECT COUNT(recSkyddsrumPaaObjektFastighetID) FROM tbTrSkSkyddsrumPaaObjektFastighet WHERE recSkyddsrumPaaObjektID = @recSkyddsrumPaaObjektID ) = 1
            UPDATE tbTrSkSkyddsrumPaaObjektFastighet SET bolHuvudfastighet = 1 WHERE recSkyddsrumPaaObjektID = @recSkyddsrumPaaObjektID

            FETCH NEXT FROM insert_cursor INTO @recSkyddsrumPaaObjektID
        END
        CLOSE insert_cursor
        DEALLOCATE insert_cursor
        END
        go

