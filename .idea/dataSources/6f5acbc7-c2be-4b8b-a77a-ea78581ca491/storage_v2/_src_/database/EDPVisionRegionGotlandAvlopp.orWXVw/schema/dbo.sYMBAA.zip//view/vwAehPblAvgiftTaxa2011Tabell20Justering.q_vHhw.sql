

CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell20Justering]
AS
SELECT		  recPblAvgiftTaxa2011Tabell20JusteringID
			, recPblAvgiftTaxa2011Tabell20ID
			, recPblAvgiftTaxa2011Tabell20JusteringID as 'intRecnum'
			, strAatgaerd
			, strBeskrivning
			, decOF
			, decHF1
			, decHF2

FROM    dbo.tbAehPblAvgiftTaxa2011Tabell20Justering
go

