
CREATE VIEW [dbo].[vwVisDeladFastighetAdress]
AS
SELECT
	dbo.tbVisDeladFastighetAdress.recFastighetAdressID,
	dbo.tbVisDeladFastighetAdress.strAdress,
    dbo.tbVisDeladFastighetAdress.strPostort,
    dbo.tbVisDeladFastighetAdress.strFnrID,
    dbo.tbVisDeladFastighetAdress.recFastighetAdressID AS intRecnum,
    dbo.tbVisDeladFastighetAdress.strPostnr,

    dbo.tbVisDeladFastighet.strBlock,
	dbo.tbVisDeladFastighet.strTkn,
	dbo.tbVisDeladFastighet.intEnhet,
    dbo.tbVisDeladFastighet.strTrakt,
    dbo.tbVisDeladFastighet.strFastighetsbeteckning

FROM dbo.tbVisDeladFastighet

RIGHT OUTER JOIN dbo.tbVisDeladFastighetAdress
	ON dbo.tbVisDeladFastighet.strFnrID = dbo.tbVisDeladFastighetAdress.strFnrID
go

