



CREATE PROCEDURE dbo.spEDPGetParentRoleID
	@intRoleID int
AS
	SELECT     intRoleParentID
	FROM         tbEDPRole
	WHERE     (intRoleID = @intRoleID)
	RETURN
go

