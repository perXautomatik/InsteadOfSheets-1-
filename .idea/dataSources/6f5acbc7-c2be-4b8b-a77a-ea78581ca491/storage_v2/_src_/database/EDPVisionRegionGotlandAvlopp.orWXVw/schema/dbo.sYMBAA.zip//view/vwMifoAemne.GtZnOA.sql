CREATE VIEW [dbo].[vwMifoAemne]
AS
SELECT     dbo.tbMifoAemne.recAemneID, dbo.tbMifoAemne.recObjektID, dbo.tbMifoAemne.strFas, dbo.tbMifoAemne.strMedium, dbo.tbMifoAemne.strAemne,
                      dbo.tbMifoAemne.strTyp, dbo.tbMifoAemne.strBedoemning, dbo.tbMifoAemne.bolBedoemningEjMoejlig, dbo.tbMifoObjekt.strObjektId,
                      dbo.tbMifoObjekt.strObjektNamn, dbo.tbMifoAemne.recAemneID AS intRecnum
FROM         dbo.tbMifoAemne LEFT OUTER JOIN
                      dbo.tbMifoObjekt ON dbo.tbMifoAemne.recObjektID = dbo.tbMifoObjekt.recObjektID
go

