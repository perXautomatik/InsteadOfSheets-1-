
CREATE PROCEDURE [dbo].[spEDPAddParameterDefaultValueRequired] 
  @intParameterID int, 
  @strParameterValueDefault varchar(200),
  @bolRequired bit
AS
BEGIN
  SET NOCOUNT ON;
  INSERT INTO tbEDPParameterDefaultValue (strParameterDefaultValue, intParameterID, bolRequired)
  VALUES (@strParameterValueDefault, @intParameterID, @bolRequired)
END
go

