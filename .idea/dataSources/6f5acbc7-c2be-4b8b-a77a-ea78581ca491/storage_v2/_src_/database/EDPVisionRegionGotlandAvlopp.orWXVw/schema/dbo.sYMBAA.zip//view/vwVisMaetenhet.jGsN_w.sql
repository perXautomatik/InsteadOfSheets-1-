
CREATE VIEW vwVisMaetenhet 
  AS
  SELECT tbVisMaetenhet.recEnhetID, tbVisMaetenhet.strEnhet, tbVisMaetenhet.recEnhetTypID
    , tbVisMaetenhetTyp.strEnhetTyp, tbVisMaetenhet.recEnhetID AS intRecnum
  FROM tbVisMaetenhet 
  LEFT OUTER JOIN tbVisMaetenhetTyp 
    ON tbVisMaetenhet.recEnhetTypID = tbVisMaetenhetTyp.recEnhetTypID
go

