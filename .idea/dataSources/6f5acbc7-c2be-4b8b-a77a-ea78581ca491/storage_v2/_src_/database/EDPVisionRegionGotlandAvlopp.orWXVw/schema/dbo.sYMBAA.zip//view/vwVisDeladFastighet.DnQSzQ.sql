
CREATE VIEW [dbo].[vwVisDeladFastighet]
AS
WITH Fastighetsadress AS(
  SELECT strFnrID, MIN(recFastighetAdressID) AS ID 
  FROM tbVisDeladFastighetAdress 
  GROUP BY tbVisDeladFastighetAdress.strFnrID
)
SELECT tbVisDeladFastighet.strFnrID, 
  strTrakt, 
  strBlock, 
  strTkn, 
  intEnhet, 
  recFastighet, 
  strKommunNamn, 
  tbVisKommun.recKommunID,
  recFastighet AS intRecnum,
  guidUuid,
  strFastighetsbeteckning,
  tbVisDeladFastighetAdress.strAdress,
  tbVisDeladFastighetAdress.strPostnr,
  tbVisDeladFastighetAdress.strPostort
FROM dbo.tbVisDeladFastighet
LEFT OUTER JOIN tbVisKommun
	ON tbVisKommun.recKommunID = tbVisDeladFastighet.recKommunID
LEFT OUTER JOIN tbVisDeladFastighetAdress
  ON tbVisDeladFastighetAdress.recFastighetAdressID = (SELECT ID FROM Fastighetsadress WHERE strFnrID = tbVisDeladFastighet.strFnrID)

go

