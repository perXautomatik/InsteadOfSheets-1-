

CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell19Justering]
AS
SELECT		  recPblAvgiftTaxa2011Tabell19JusteringID
			, recPblAvgiftTaxa2011Tabell19ID
			, recPblAvgiftTaxa2011Tabell19ID as 'intRecnum'
			, strAatgaerd
			, strBeskrivning
			, decHF1
			, decHF2
FROM    dbo.tbAehPblAvgiftTaxa2011Tabell19Justering
go

