
CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell20]
AS
SELECT     

recTabell20ID, 
recTaxa2011ID, 
recTabell20ID as 'intRecnum', 
dbo.tbAehPblTaxa2011Tabell20.recTjaenstID,
dbo.tbAehPblTaxa2011Tabell20.recFakturatextID,
strFritext,
decMoms,
	dbo.tbVisTjaenst.strTjaenstKod,
	dbo.tbVisTjaenst.strTjaenst,
	dbo.tbVisFakturatext.strFakturatextkod
	
FROM dbo.tbAehPblTaxa2011Tabell20

	LEFT OUTER JOIN dbo.tbVisFakturatext
	ON dbo.tbVisFakturatext.recFakturatextID = dbo.tbAehPblTaxa2011Tabell20.recFakturatextID
	
	LEFT OUTER JOIN dbo.tbVisTjaenst
	ON dbo.tbVisTjaenst.recTjaenstID = dbo.tbAehPblTaxa2011Tabell20.recTjaenstID


go

