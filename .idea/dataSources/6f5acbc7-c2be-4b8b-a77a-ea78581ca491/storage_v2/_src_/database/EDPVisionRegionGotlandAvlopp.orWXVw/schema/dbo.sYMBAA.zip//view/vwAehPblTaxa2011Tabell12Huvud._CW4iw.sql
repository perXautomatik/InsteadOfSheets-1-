


CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell12Huvud]
AS
SELECT     tbAehPblTaxa2011Tabell12Huvud.recTabell12ID,
           recHuvudID as 'intRecnum', 
		   recHuvudID,
		   intFraanYta,
		   intTillYta,
		   intOf,
		   intHF1,
		   recTaxa2011ID,
		   intHF2
FROM         dbo.tbAehPblTaxa2011Tabell12Huvud
LEFT OUTER JOIN vwAehPblTaxa2011Tabell12
ON vwAehPblTaxa2011Tabell12.recTabell12ID = tbAehPblTaxa2011Tabell12Huvud.recTabell12ID

go

