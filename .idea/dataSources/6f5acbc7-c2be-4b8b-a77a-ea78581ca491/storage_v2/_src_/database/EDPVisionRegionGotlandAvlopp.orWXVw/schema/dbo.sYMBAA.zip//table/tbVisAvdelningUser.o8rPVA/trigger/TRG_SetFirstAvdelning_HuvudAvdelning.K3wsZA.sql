
        CREATE TRIGGER TRG_SetFirstAvdelning_HuvudAvdelning ON tbVisAvdelningUser
        AFTER INSERT, DELETE, UPDATE
        AS
        BEGIN

        IF @@ROWCOUNT = 0
        RETURN

        DECLARE @intUserID INT

        -- LOOP WARS ;)
        DECLARE @run_delete INT  -- ALWAYS RUN INSERTS, ON UPDATES ONLY RUN INSERTS
        SET @run_delete = 1

        -- LOOP
        -- INSERT QUERYS
        DECLARE insert_cursor CURSOR FAST_FORWARD
            FOR SELECT intUserID FROM INSERTED;
        OPEN insert_cursor;

        FETCH NEXT FROM insert_cursor INTO @intUserID;
        WHILE @@FETCH_STATUS = 0
        BEGIN
            SET @run_delete = 0
            IF (SELECT COUNT(tbVisAvdelningUser.recAvdelningUserID)
                FROM tbVisAvdelningUser
                WHERE  (tbVisAvdelningUser.intUserID = @intUserID)) = 1
            BEGIN
                UPDATE tbVisAvdelningUser
                SET tbVisAvdelningUser.bolHuvudavdelning = 1
                WHERE  tbVisAvdelningUser.intUserID = @intUserID
            END

            FETCH NEXT FROM insert_cursor INTO @intUserID;
        END

        CLOSE insert_cursor;
        DEALLOCATE insert_cursor;


        -- DELETE QUERYS
        IF @run_delete <> 0
        BEGIN
            DECLARE delete_cursor CURSOR FAST_FORWARD
                FOR SELECT intUserID FROM DELETED;
            OPEN delete_cursor;

            FETCH NEXT FROM delete_cursor INTO @intUserID;
            WHILE @@FETCH_STATUS = 0
            BEGIN
                IF (SELECT COUNT(tbVisAvdelningUser.recAvdelningUserID)
                    FROM tbVisAvdelningUser
                    WHERE  (tbVisAvdelningUser.intUserID = @intUserID)) = 1
                BEGIN
                    UPDATE tbVisAvdelningUser
                    SET tbVisAvdelningUser.bolHuvudavdelning = 1
                    WHERE  tbVisAvdelningUser.intUserID = @intUserID
                END

                FETCH NEXT FROM delete_cursor INTO @intUserID;
            END

            CLOSE delete_cursor;
            DEALLOCATE delete_cursor;
        END
        END
        go

