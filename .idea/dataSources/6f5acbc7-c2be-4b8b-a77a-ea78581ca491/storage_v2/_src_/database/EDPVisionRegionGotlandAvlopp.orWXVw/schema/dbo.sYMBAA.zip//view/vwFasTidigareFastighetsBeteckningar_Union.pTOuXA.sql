CREATE VIEW [dbo].[vwFasTidigareFastighetsBeteckningar_Union]
AS
SELECT     recTIBET as recUNION, strFNRID as strUFnrID, strOMDAT, strKOMMUN as strRegisterOmraadeKommun, strTREGAST as strTrakt, strBLKVSS as strBlock, 
                  strTKN, strENHET, strFastighetsbeteckning as strUrsprungsbeteckning, 'Tidigare, efter' AS strInfoTabell
FROM         dbo.vwFasTidigareFastBeteckning
UNION ALL
SELECT     recGTIBET as recUNION, strFNRID as strUFnrID, strOMDAT, strREGO as strRegisterOmraadeKommun, strTREGAST as strTrakt, strBLKVSS as strBlock, 
                  strTKN, strENHET, strFastighetsbeteckning as strUrsprungsbeteckning, 'Tidigare, före' AS strInfoTabell
FROM        dbo.vwFasTidigareFastBeteckningFoere 
UNION ALL
SELECT   recFASTIGH as recUNION,  strFNRID as strUFnrID, '' as strOMDAT,  strKOMMUN  as strRegisterOmraadeKommun, strTrakt, strBLOCK, 
               strTKN, CAST(intENHET as varchar) as strENHET, strFastighetsbeteckning as strUrsprungsbeteckning, 'Fastighet' AS strInfoTabell
FROM     dbo.vwFasFastighet


go

