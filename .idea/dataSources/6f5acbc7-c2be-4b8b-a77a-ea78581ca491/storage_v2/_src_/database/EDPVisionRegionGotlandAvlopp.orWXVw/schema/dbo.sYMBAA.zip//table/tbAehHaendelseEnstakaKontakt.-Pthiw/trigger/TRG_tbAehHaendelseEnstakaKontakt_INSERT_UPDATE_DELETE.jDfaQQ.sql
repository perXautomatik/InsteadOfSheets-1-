
        CREATE TRIGGER TRG_tbAehHaendelseEnstakaKontakt_INSERT_UPDATE_DELETE ON tbAehHaendelseEnstakaKontakt
        AFTER INSERT, UPDATE, DELETE
        AS
        BEGIN
        SET NOCOUNT ON;

        DECLARE haendelse_kontakt_cursor CURSOR FAST_FORWARD
        FOR
        SELECT recHaendelseID FROM INSERTED UNION SELECT recHaendelseID FROM DELETED
        OPEN haendelse_kontakt_cursor
        DECLARE @recHaendelseID INT
        FETCH NEXT FROM haendelse_kontakt_cursor INTO @recHaendelseID
        WHILE (@@fetch_status = 0)
        BEGIN
            EXEC spAehHaendelseUpdateKontakt @recHaendelseID

            FETCH NEXT FROM haendelse_kontakt_cursor INTO @recHaendelseID
        END
        CLOSE haendelse_kontakt_cursor
        DEALLOCATE haendelse_kontakt_cursor
        END
        go

