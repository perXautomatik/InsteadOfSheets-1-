
        CREATE TRIGGER HuvudFastighetHiss ON tbTrHiHissFastighet
        AFTER  INSERT
        AS
        BEGIN
        -- SET NOCOUNT ON; added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;

        DECLARE insert_cursor CURSOR FAST_FORWARD
        FOR
        SELECT recHissID FROM INSERTED
        OPEN insert_cursor
        DECLARE @recHissID as INT
        FETCH NEXT FROM insert_cursor INTO @recHissID
        WHILE (@@fetch_status = 0)
        BEGIN
            IF (SELECT COUNT(recHissFastighetID) FROM tbTrHiHissFastighet WHERE recHissID = @recHissID ) = 1
            UPDATE tbTrHiHissFastighet SET bolHuvudfastighet = 1 WHERE recHissID = @recHissID

            FETCH NEXT FROM insert_cursor INTO @recHissID
        END
        CLOSE insert_cursor
        DEALLOCATE insert_cursor
        END
        go

