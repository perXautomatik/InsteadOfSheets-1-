CREATE VIEW [dbo].[vwVisEnhet]
AS
SELECT     dbo.tbVisEnhet.recEnhetID, dbo.tbVisEnhet.recAvdelningID, dbo.tbVisEnhet.strEnhetKod, dbo.tbVisEnhet.strEnhetNamn,
                      dbo.tbVisAvdelning.recFoervaltningID, dbo.tbVisAvdelning.strAvdelningKod, dbo.tbVisAvdelning.strAvdelningNamn,
                      dbo.tbVisFoervaltning.strFoervaltningKod, dbo.tbVisFoervaltning.strFoervaltningNamn, dbo.tbVisEnhet.recEnhetID AS intRecnum,
						dbo.tbVisEnhet.bolEjAktuell
FROM         dbo.tbVisEnhet LEFT OUTER JOIN
                      dbo.tbVisAvdelning ON dbo.tbVisEnhet.recAvdelningID = dbo.tbVisAvdelning.recAvdelningID LEFT OUTER JOIN
                      dbo.tbVisFoervaltning ON dbo.tbVisAvdelning.recFoervaltningID = dbo.tbVisFoervaltning.recFoervaltningID
go

