

CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell11ByggnaderAnlaeggningar]
AS
SELECT     tbAehPblTaxa2011Tabell11ByggnaderAnlaeggningar.recTabell11ID, 
		   recByggnadID,
		   recByggnadID as 'intRecnum', 
		   intFraanYta,
		   intTillYta,
		   intOF,
		   intHF1,
		   recTaxa2011ID,
		   intHF2
FROM         dbo.tbAehPblTaxa2011Tabell11ByggnaderAnlaeggningar
LEFT OUTER JOIN vwAehPblTaxa2011Tabell11 
ON vwAehPblTaxa2011Tabell11.recTabell11ID = tbAehPblTaxa2011Tabell11ByggnaderAnlaeggningar.recTabell11ID



go

