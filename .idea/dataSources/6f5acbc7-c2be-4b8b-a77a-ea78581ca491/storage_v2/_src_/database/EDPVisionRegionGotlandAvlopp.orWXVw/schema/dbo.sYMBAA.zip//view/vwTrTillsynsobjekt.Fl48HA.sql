


CREATE VIEW [dbo].[vwTrTillsynsobjekt]
AS
WITH VTPRIS AS (
  SELECT recTjaenstID, intPris AS intAktuellTimavgift
  FROM dbo.tbVisTjaenstPris P1
  WHERE datPrisGaellerFraan < GETDATE()	
  AND datPrisGaellerFraan = (
    SELECT MAX(datPrisGaellerFraan) 
    FROM dbo.tbVisTjaenstPris P2
    WHERE P2.recTjaenstID = P1.recTjaenstID
    AND P2.datPrisGaellerFraan < GETDATE()
    GROUP BY P2.recTjaenstID
    )
), HFLIK AS (
  SELECT recTillsynsobjektID, strHuvudflik
  FROM tbTrTillsynsobjektHuvudflik F1
  WHERE recTillsynsobjektHuvudflikID = (
    SELECT MIN(recTillsynsobjektHuvudflikID)
    FROM tbTrTillsynsobjektHuvudflik F2
    WHERE F2.recTillsynsobjektID = F1.recTillsynsobjektID
    GROUP BY F2.recTillsynsobjektID
    )
), TPOST AS (
  SELECT recTillsynsobjektID, CAST(SUM(intMinuter)/60 AS VARCHAR) + ':' + RIGHT('0' + CAST(SUM(intMinuter)%60 AS VARCHAR), 2) AS strSummaTidposterDettaAar 
  FROM tbVisTidpost			
  WHERE YEAR(datUtfoerandeTill) = YEAR(GETDATE())
  GROUP BY recTillsynsobjektID
)

SELECT			dbo.tbTrTillsynsobjekt.recTillsynsobjektID AS intRecnum, 
				dbo.tbTrTillsynsobjekt.recTillsynsobjektID, 
				dbo.tbTrTillsynsobjekt.strObjektsNamn, 
                dbo.tbTrTillsynsobjekt.strAdress, 
                dbo.tbTrTillsynsobjekt.strOrt, 
                dbo.tbTrTillsynsobjekt.strPostnummer,
                dbo.tbTrTillsynsobjekt.strSoekbegrepp, 
                dbo.tbTrTillsynsobjekt.strAnteckning, 
                dbo.tbTrTillsynsobjekt.intBeraeknadAarsavgift, 
                dbo.tbTrTillsynsobjekt.intJusteradAarsavgift, 
                dbo.tbTrTillsynsobjekt.decRabatt, 
                dbo.tbTrTillsynsobjekt.decKontrolltid, 
                dbo.tbTrTillsynsobjekt.decJusteradKontrolltid,
                dbo.tbTrTillsynsobjekt.bolSpecialpris, 
                dbo.tbTrTillsynsobjekt.bolTimdebitering, 
                dbo.tbTrTillsynsobjekt.strProevningsplikt, 
                dbo.tbTrTillsynsobjekt.intAarsavgiftAttDebitera, 
                dbo.tbTrTillsynsobjekt.bolDebiterasEj, 
                dbo.tbTrTillsynsobjekt.strDebiteradFoer, 
                dbo.tbTrTillsynsobjekt.recTyperID, 
                dbo.tbTrTillsynsobjekt.recAvdelningID, 
                dbo.tbTrTillsynsobjekt.recEnhetID, 
                dbo.tbTrTillsynsobjekt.recDeladFakturamottagareID, 
				dbo.tbTrTillsynsobjekt.intBesoeksintervall, 
				dbo.tbTrTillsynsobjekt.datFoeregaaendeBesoek, 
				dbo.tbTrTillsynsobjekt.datNaastaBesoeks,
				dbo.tbTrTillsynsobjekt.intTidsskuld,
                CONVERT(VARCHAR(7),intTidsskuld / 60) + ':' + RIGHT('00' + CONVERT(VARCHAR(2),intTidsskuld % 60),2) as strTidsskuld,
                dbo.tbTrTillsynsobjektsTyp.recTillsynsobjektTypID, 
                dbo.tbTrTillsynsobjektsTyp.strTillsynsobjektsTypNamn, 
                dbo.tbTrTillsynsobjektsTyp.strTillsynsTabellnamn,
				VTPRIS.intAktuellTimavgift,
				dbo.tbTrTillsynsobjektUser.intUserID AS recHuvudHandlaeggareID, 
                dbo.tbEDPUser.strSignature AS strHuvudhandlaeggareSignatur, 
                vwVisVerksamhetsutoevareKontakt.recDeladKontaktID AS recVerksamhetsutoevareKontaktID, 
                vwVisVerksamhetsutoevareKontakt.strVisasSom AS strVerksamhetsutoevareNamn, 
                vwVisVerksamhetsutoevareKontakt.strOrginisationPersonnummer AS strVerksamhetsutoevareOrgPersNr, 
                tbVisKontaktPerson.recDeladKontaktID AS recKontaktpersonID, 
                tbVisKontaktPerson.strVisasSom AS strKontaktpersonNamn, 
                dbo.vwVisDeladFastighet.strFnrID AS strHuvudfastighetFnrID, 
                dbo.vwVisDeladFastighet.strFastighetsbeteckning AS strHuvudfastighetFastighetsbeteckning, 
                dbo.vwVisDeladFastighet.recFastighet AS recHuvudfastighetID, 
                dbo.tbTrVerksamhet.recVerksamhetID, 
                dbo.tbTrVerksamhet.strVerksamhetNamn, 
                dbo.tbTrVerksamhet.recLaenID, 
                dbo.tbTrVerksamhet.recKommunID, 
                dbo.tbVisLaen.strLaensNamn, 
                dbo.tbVisKommun.strKommunNamn, 
                dbo.tbTrTillsynsobjektStatus.recStatusID, 
                dbo.tbTrTillsynsobjektStatus.strStatus, 
                dbo.tbTrTillsynsobjektStatus.datDatum, 
                dbo.tbTrTyper.strTyp, 
                dbo.tbVisAvdelning.strAvdelningKod, 
                dbo.tbVisEnhet.strEnhetKod, 
                dbo.vwVisDeladFakturamottagare.strVisasSom AS strFakturamottagare,
                HFLIK.strHuvudflik,
           		ISNULL(TPOST.strSummaTidposterDettaAar, '0:00') AS strSummaTidposterDettaAar,
           		dbo.tbTrTillsynsobjektBranschkod.recBranschKodID as recHuvudBranschKodID
			
FROM			dbo.tbTrTillsynsobjekt 
LEFT OUTER JOIN	dbo.tbTrTillsynsobjektsTyp 
				ON	dbo.tbTrTillsynsobjekt.recTillsynsobjektTypID = dbo.tbTrTillsynsobjektsTyp.recTillsynsobjektTypID 
LEFT OUTER JOIN	dbo.tbTrTillsynsobjektFastighet	
				ON	dbo.tbTrTillsynsobjektFastighet.recTillsynsobjektID = dbo.tbTrTillsynsobjekt.recTillsynsobjektID 
				AND dbo.tbTrTillsynsobjektFastighet.bolHuvudfastighet = 1 
LEFT OUTER JOIN	dbo.vwVisDeladFastighet 
				ON	dbo.vwVisDeladFastighet.strFnrID = dbo.tbTrTillsynsobjektFastighet.strFnrID 
LEFT OUTER JOIN	dbo.tbTrTillsynsobjektUser 
				ON	dbo.tbTrTillsynsobjektUser.recTillsynsobjektID = dbo.tbTrTillsynsobjekt.recTillsynsobjektID 
				AND	dbo.tbTrTillsynsobjektUser.bolHuvudhandlaeggare = 1 
LEFT OUTER JOIN	dbo.tbEDPUser 
				ON	dbo.tbEDPUser.intUserID = dbo.tbTrTillsynsobjektUser.intUserID 
LEFT OUTER JOIN	dbo.tbVisDeladKontakt AS vwVisVerksamhetsutoevareKontakt 
				ON	dbo.tbTrTillsynsobjekt.recVerksamhetsutoevareKontaktID = vwVisVerksamhetsutoevareKontakt.recDeladKontaktID 
LEFT OUTER JOIN	dbo.tbVisDeladKontakt AS tbVisKontaktPerson 
				ON	dbo.tbTrTillsynsobjekt.recKontaktPersonID = tbVisKontaktPerson.recDeladKontaktID 
LEFT OUTER JOIN	dbo.tbTrVerksamhet 
				ON	dbo.tbTrTillsynsobjekt.recVerksamhetID = dbo.tbTrVerksamhet.recVerksamhetID 
LEFT OUTER JOIN	dbo.tbVisKommun 
				ON	dbo.tbVisKommun.recKommunID = dbo.tbTrVerksamhet.recKommunID 
LEFT OUTER JOIN	dbo.tbVisLaen 
				ON	dbo.tbTrVerksamhet.recLaenID = dbo.tbVisLaen.recLaenID 
LEFT OUTER JOIN	dbo.tbTrTillsynsobjektStatus 
				ON	dbo.tbTrTillsynsobjekt.recLastLogPostID = dbo.tbTrTillsynsobjektStatus.recTillsynsobjektStatusID 
LEFT OUTER JOIN	dbo.tbTrTyper 
				ON	dbo.tbTrTillsynsobjekt.recTyperID = dbo.tbTrTyper.recTyperID 
LEFT OUTER JOIN	dbo.tbVisAvdelning 
				ON	dbo.tbTrTillsynsobjekt.recAvdelningID = dbo.tbVisAvdelning.recAvdelningID 
LEFT OUTER JOIN	dbo.tbVisEnhet 
				ON	dbo.tbTrTillsynsobjekt.recEnhetID = dbo.tbVisEnhet.recEnhetID 
LEFT OUTER JOIN	dbo.vwVisDeladFakturamottagare 
				ON	dbo.vwVisDeladFakturamottagare.recDeladFakturamottagareID = dbo.tbTrTillsynsobjekt.recDeladFakturamottagareID
LEFT OUTER JOIN	dbo.tbTrTillsynsobjektBranschkod 
				ON	dbo.tbTrTillsynsobjektBranschkod.recTillsynsobjektID = dbo.tbTrTillsynsobjekt.recTillsynsobjektID 
				AND	dbo.tbTrTillsynsobjektBranschkod.bolHuvudBranschKod = 1 
LEFT OUTER JOIN VTPRIS
  ON VTPRIS.recTjaenstID= dbo.tbTrTillsynsobjektsTyp.recTimavgiftTjaenstID
LEFT OUTER JOIN HFLIK
  ON HFLIK.recTillsynsobjektID=dbo.tbTrTillsynsobjekt.recTillsynsobjektID
LEFT OUTER JOIN TPOST
  ON TPOST.recTillsynsobjektID=dbo.tbTrTillsynsobjekt.recTillsynsobjektID



go

