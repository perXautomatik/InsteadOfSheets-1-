
CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell17]
AS
SELECT
  dbo.tbAehPblAvgiftTaxa2011Tabell17.recAehPblAvgiftTaxa2011Tabell17ID,
  dbo.tbAehPblAvgiftTaxa2011Tabell17.recAehPblAvgiftTaxa2011Tabell17ID AS intRecnum,
  dbo.tbAehPblAvgiftTaxa2011Tabell17.recAvgiftID,
  dbo.tbAehPblAvgiftTaxa2011Tabell17.bolDebiterad,
  dbo.tbAehPblAvgiftTaxa2011Tabell17.bolTidsersaettning,
  dbo.tbAehPblAvgiftTaxa2011Tabell17.bolHandlaeggningsfaktor,
  dbo.tbAehPblAvgiftTaxa2011Tabell17.decAvgift,
  dbo.tbAehPblAvgiftTaxa2011Tabell17.intHF,
  dbo.tbAehPblAvgiftTaxa2011Tabell17.decmPBB,
  dbo.tbAehPblAvgiftTaxa2011Tabell17.decN
FROM dbo.tbAehPblAvgiftTaxa2011Tabell17

go

