


CREATE VIEW [dbo].[vwAehPoITInstaellningar]
AS
SELECT recPoITInstaellningarID, 
       recPoITInstaellningarID AS intRecnum, 
       tbAehPoITInstaellningar.recKommunID, 
       strKundnummerPoit, 
       strUrlPoit, 
       strCertifikat, 
       bolbekraeftelseAerendeExtraInfo, 
       bolBekraeftelseNyHaendelse, 
       bolRubrikAerendemening, 
       bolRubrikHaendelserubrik, 
       bolKontaktinfoHandlaeggare, 
       bolKontaktinfoText, 
       strKontaktinfo,
       tbVisKommun.strKommunNamn
FROM dbo.tbAehPoITInstaellningar
LEFT OUTER JOIN tbVisKommun 
  ON tbVisKommun.recKommunID = tbAehPoITInstaellningar.recKommunID


go

