



CREATE VIEW [dbo].[vwTrAatgaerdsOrsakLookUp]
AS

SELECT		
			tbTrTillsynsbesoek.recTillsynsbesoekID,
			tbTrChecklistamallVersionPunkt.recChecklistamallVersionPunktID,
			tbTrChecklistamallVersionPunkt.recChecklistamallVersionPunktID AS intRecnum,
			tbTrChecklistamallVersionOmraade.intNummer as OmraadeNummer,
			tbTrChecklistamallVersionPunkt.intNummer as PunktNummer,
			tbTrChecklistamallVersionOmraade.strNamn as Omraadesnamn,
			tbTrChecklistamallVersionPunkt.strNamn as Punktnamn,
			CAST(tbTrChecklistamallVersionOmraade.intNummer AS VARCHAR) + '. ' + tbTrChecklistamallVersionOmraade.strNamn AS Omraade,
			CAST(tbTrChecklistamallVersionPunkt.intNummer AS VARCHAR) + '. ' + tbTrChecklistamallVersionPunkt.strNamn AS Punkt
FROM		
			tbTrChecklistamallVersionPunkt
INNER JOIN  			
			tbTrChecklistamallVersionOmraade
			ON tbTrChecklistamallVersionOmraade.recChecklistamallVersionOmraadeID = tbTrChecklistamallVersionPunkt.recChecklistamallVersionOmraadeID
INNER JOIN			
			tbTrChecklistamallVersion
			ON tbTrChecklistamallVersion.recChecklistaVersionID = tbTrChecklistamallVersionOmraade.recChecklistaVersionID
INNER JOIN			
			tbTrTillsynsbesoek
			ON tbTrChecklistamallVersion.recChecklistaVersionID = tbTrTillsynsbesoek.recChecklistaVersionID



go

