
CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell11Justering]
AS
SELECT		recPblAvgiftTaxa2011Tabell11ID, 
			recPblAvgiftTaxa2011Tabell11JusteringID as 'intRecnum',
			recPblAvgiftTaxa2011Tabell11JusteringID,
			strAatgaerd,
			strBeskrivning,
			decHF1,
			decHF2,
			decOF
FROM         dbo.tbAehPblAvgiftTaxa2011Tabell11Justering

go

