

CREATE VIEW [dbo].[vwVisFakturaUnderlag]
AS
SELECT dbo.tbVisFakturaUnderlag.recFakturaUnderlagID, dbo.tbVisFakturaUnderlag.recFakturaUnderlagID AS intRecnum, dbo.tbVisFakturaUnderlag.intFakturaNr, 
       dbo.tbVisFakturaUnderlag.decNettoBelopp, dbo.tbVisFakturaUnderlag.decMomsBelopp, dbo.tbVisFakturaUnderlag.decBruttoBelopp, 
       dbo.tbVisFakturaUnderlag.bolSkickadEkonomiSystem, dbo.tbVisFakturaUnderlag.recEnstakaFakturaMottagareID, dbo.tbVisEnstakaFakturamottagare.intIdNummer, dbo.tbVisFakturaUnderlag.datSkapadDatum,
       dbo.tbVisEnstakaFakturamottagare.strExterntIdNummer, dbo.tbVisEnstakaFakturamottagare.bolIntern, dbo.tbVisEnstakaFakturamottagare.strSkanningskod, 
       dbo.tbVisEnstakaFakturamottagare.strMotpartKoncernkod, dbo.tbVisEnstakaFakturamottagare.strGLN, dbo.tbVisEnstakaFakturamottagare.strKommun, 
       dbo.tbVisEnstakaFakturamottagare.strReferensnummer, dbo.tbVisEnstakaFakturamottagare.strIntBokfoeringsKonto, 
       dbo.tbVisEnstakaKontakt.strOrginisationPersonnummer, dbo.tbVisEnstakaKontakt.strVisasSom, dbo.tbVisEnstakaKontakt.strGatuadress, 
       dbo.tbVisEnstakaKontakt.strCoadress, dbo.tbVisEnstakaKontakt.strPostnummer, dbo.tbVisEnstakaKontakt.strPostort, dbo.tbVisEnstakaKontakt.strLand, 
       CASE WHEN (SELECT COUNT(*) FROM tbVisFakturaFilFakturaUnderlag
         WHERE recFakturaUnderlagID = dbo.tbVisFakturaUnderlag.recFakturaUnderlagID) > 0 
         THEN CAST('1' AS BIT) 
         ELSE CAST('0' AS bit) 
       END AS 'bolSkrivenTillFakturaFil',

       CASE 
       WHEN (strKontaktTyp = 'Person' AND ISNULL(strFoeretag, '') <> '')
         THEN (dbo.tbVisEnstakaKontakt.strEfternamn + ', ' + dbo.tbVisEnstakaKontakt.strFoernamn) + ' (' + dbo.tbVisEnstakaKontakt.strFoeretag + ')'
       WHEN (strKontaktTyp = 'Person' AND ISNULL(strFoeretag, '') = '')
         THEN (dbo.tbVisEnstakaKontakt.strEfternamn + ', ' + dbo.tbVisEnstakaKontakt.strFoernamn)
       WHEN (strKontaktTyp = 'Företag' AND ((strFoernamn + strEfternamn) IS NOT NULL AND (strFoernamn + strEfternamn) <> ''))
         THEN dbo.tbVisEnstakaKontakt.strFoeretag + ' (' + dbo.tbVisEnstakaKontakt.strEfternamn + ', ' + dbo.tbVisEnstakaKontakt.strFoernamn  + ')'
       WHEN (strKontaktTyp = 'Företag' AND ((strFoernamn + strEfternamn) IS NULL OR (strFoernamn + strEfternamn) = ''))
         THEN (dbo.tbVisEnstakaKontakt.strFoeretag)
       ELSE
                       strVisasSom
       END as strVisasSomEfternamnFoerst,

       CASE 
       WHEN strKontaktTyp = 'Person' 
         THEN ISNULL(dbo.tbVisEnstakaKontakt.strEfternamn, '') + ISNULL(', ' + dbo.tbVisEnstakaKontakt.strFoernamn, '')
       WHEN strKontaktTyp = 'Företag'
         THEN dbo.tbVisEnstakaKontakt.strFoeretag 
       ELSE
         strVisasSom
       END AS strEfternamnFoernamn,

       CASE 
       WHEN strKontaktTyp = 'Person' 
         THEN ISNULL(dbo.tbVisEnstakaKontakt.strFoernamn + ' ', '') + ISNULL(dbo.tbVisEnstakaKontakt.strEfternamn, '')
       WHEN strKontaktTyp = 'Företag'
         THEN dbo.tbVisEnstakaKontakt.strFoeretag 
       ELSE
         strVisasSom
       END AS strFoernamnEfternamn,
       strKontaktTyp,
       strFoernamn,
       strEfternamn,
       strFoeretag 

FROM dbo.tbVisFakturaUnderlag 
LEFT OUTER JOIN dbo.tbVisEnstakaFakturamottagare 
  ON dbo.tbVisEnstakaFakturamottagare.recEnstakaFakturamottagareID = dbo.tbVisFakturaUnderlag.recEnstakaFakturaMottagareID 
LEFT OUTER JOIN dbo.tbVisEnstakaKontakt 
  ON dbo.tbVisEnstakaKontakt.recEnstakaKontaktID = dbo.tbVisEnstakaFakturamottagare.recEnstakaKontaktID



go

