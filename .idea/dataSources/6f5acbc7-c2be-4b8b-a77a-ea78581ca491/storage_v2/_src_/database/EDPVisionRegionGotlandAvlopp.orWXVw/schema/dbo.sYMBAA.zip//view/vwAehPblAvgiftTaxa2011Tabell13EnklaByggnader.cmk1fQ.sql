
CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell13EnklaByggnader]
AS
SELECT     
recPblAvgiftTaxa2011Tabell13ID, 
recPblAvgiftTaxa2011Tabell13EnklaByggnaderID as 'intRecnum', 
recPblAvgiftTaxa2011Tabell13EnklaByggnaderID,
strObjekt,
strBeskrivning,
intOf,
intHF1,
intHF2
FROM dbo.tbAehPblAvgiftTaxa2011Tabell13EnklaByggnader



go

