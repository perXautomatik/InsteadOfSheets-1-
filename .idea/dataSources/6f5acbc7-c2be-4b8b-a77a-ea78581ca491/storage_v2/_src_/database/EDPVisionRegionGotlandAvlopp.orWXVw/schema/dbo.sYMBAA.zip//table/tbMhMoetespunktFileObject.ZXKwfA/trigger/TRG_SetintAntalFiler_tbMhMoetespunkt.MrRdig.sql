
        CREATE TRIGGER TRG_SetintAntalFiler_tbMhMoetespunkt ON tbMhMoetespunktFileObject
        AFTER INSERT, DELETE
        AS
        BEGIN

        IF @@ROWCOUNT = 0
        RETURN


            UPDATE tbMhMoetespunkt
            SET tbMhMoetespunkt.intAntalFiler = (SELECT COUNT(recMoetespunktFileObjectID)
                                                        FROM tbMhMoetespunktFileObject
                                                        WHERE recMoetespunktID = tbMhMoetespunkt.recMoetespunktID)
            WHERE  tbMhMoetespunkt.recMoetespunktID IN (SELECT recMoetespunktID FROM INSERTED UNION ALL SELECT recMoetespunktID FROM DELETED)

        END
        go

