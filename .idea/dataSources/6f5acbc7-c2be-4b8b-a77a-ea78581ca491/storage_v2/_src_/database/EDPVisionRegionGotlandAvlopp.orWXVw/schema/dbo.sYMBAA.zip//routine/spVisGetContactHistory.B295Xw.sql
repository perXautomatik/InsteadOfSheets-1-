CREATE PROCEDURE [dbo].[spVisGetContactHistory] (
	@id INTEGER = NULL
)
AS
  -- ERROR HANDLING
  IF @id IS NULL
    BEGIN
      PRINT 'ERROR: First param "id" must be specified and can not be NULL.'
      RETURN(1)
    END
  -- NO ERROR
  BEGIN
    -- SAVE TIME
	SET NOCOUNT ON;
		
		SELECT	recKontaktHistorik,
				intMainTableID,
				datSkapad AS datDatum, strAnledning,
				strFoernamn, strEfternamn,
				strOrgPersNr,
				strTitel,
				strAdress,
				strCoadress,
				strPostnr,
				strPostort,
				strLand,
				strSignature,
				strAnteckning
		FROM tbVisKontaktHistorik
		WHERE intMainTableID = @id
		ORDER BY datSkapad DESC;

    RETURN(0)
  END
go

