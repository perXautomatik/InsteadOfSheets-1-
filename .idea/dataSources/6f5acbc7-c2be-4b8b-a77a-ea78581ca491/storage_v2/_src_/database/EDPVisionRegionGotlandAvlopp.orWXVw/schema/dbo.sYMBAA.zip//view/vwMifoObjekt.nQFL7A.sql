CREATE VIEW dbo.vwMifoObjekt
AS
SELECT     dbo.tbMifoObjekt.strInvNamn, dbo.tbMifoObjekt.strDossiernr, dbo.tbMifoObjekt.intRiskklass1, dbo.tbMifoObjekt.strMotivering1,
                      dbo.tbMifoObjekt.strIntryck1, dbo.tbMifoObjekt.intRiskklass2, dbo.tbMifoObjekt.strMotivering2, dbo.tbMifoObjekt.strIntryck2,
                      dbo.tbMifoObjekt.recObjektID AS intRecnum, dbo.tbMifoObjekt.recObjektID, dbo.tbMifoObjekt.strObjektId, dbo.tbMifoObjekt.strKommunNamn,
                      dbo.tbMifoObjekt.strLaensNamn, dbo.tbMifoObjekt.strObjektNamn, dbo.tbMifoKommunicering.bolRedovisadTillAegare,
                      dbo.tbMifoKommunicering.strRedovisadTillAegareAdressat, dbo.tbMifoKommunicering.datRedovisadTillAegare,
                      dbo.tbMifoKommunicering.strRedovisningAegareKommentar, dbo.tbMifoKommunicering.bolRedovisadTillReferensGrupp,
                      dbo.tbMifoKommunicering.strRedovisadTillReferensGruppAdressat, dbo.tbMifoKommunicering.datRedovisadTillReferensGrupp,
                      dbo.tbMifoKommunicering.strRedovisningReferensGruppSynpunkter, dbo.tbMifoFastighet.strFastighetsBetCFD, dbo.tbMifoFastighet.strFixpunkt,
                      dbo.tbMifoFastighet.intXKoordinat, dbo.tbMifoFastighet.intYKoordinat, dbo.tbMifoFastighet.strZKoordinat, dbo.tbMifoFastighet.strTopografiskKarta,
                      dbo.tbMifoFastighet.strEkonomiskKarta, dbo.tbMifoFastighet.strFastighetStorlek, dbo.tbMifoFastighet.strNuvarandeFastAegare,
                      dbo.tbMifoObjektsinfo.strObjektadress, dbo.tbMifoObjektsinfo.strNuvarandeAnlaeggningsaegare, dbo.tbMifoObjektsinfo.strAdress,
                      dbo.tbMifoObjektsinfo.strPostnr, dbo.tbMifoObjektsinfo.strPostort, dbo.tbMifoObjektsinfo.bolBrunnar, dbo.tbMifoObjektsinfo.strBrunnarBeskrivning,
                      dbo.tbMifoObjektsinfo.strTidigareAnlaeggningsaegare, dbo.tbMifoObjektsinfo.strKontaktperson, dbo.tbMifoObjektsinfo.bolUtredning,
                      dbo.tbMifoObjektsinfo.strUtredningBeskrivning, dbo.tbMifoObjektsinfo.strByggnaderAnlaeggningarNuvarandeTidigare,
                      dbo.tbMifoObjektsinfo.bolAndraKaellor, dbo.tbMifoObjektsinfo.strAndraKaellorBeskrivning, dbo.tbMifoVerksamheter.strFaeltbesoekNamn1,
                      dbo.tbMifoVerksamheter.datFaeltbesoekDatum1, dbo.tbMifoVerksamheter.strFaeltbesoekNamn2, dbo.tbMifoVerksamheter.datFaeltbesoekDatum2,
                      dbo.tbMifoVerksamheter.strAnlaeggningsstatus, dbo.tbMifoVerksamheter.strAnlaeggningsomraadetsTillgaenglighet,
                      dbo.tbMifoVerksamheter.strVerksamhetstid, dbo.tbMifoVerksamheter.strDriftstart, dbo.tbMifoVerksamheter.strDriftslut,
                      dbo.tbMifoVerksamheter.strAntalMiljoeFoerstoerandeVerksamhetsaar, dbo.tbMifoVerksamheter.strIProcessernaHanteradeKemikalier,
                      dbo.tbMifoVerksamheter.strRestprodukterFraanProcesserna, dbo.tbMifoVerksamheter.strProduktion,
                      dbo.tbMifoVerksamheter.strBeskrivningNuvarandeProcesserna, dbo.tbMifoVerksamheter.strBeskrivningTidigareProcesser,
                      dbo.tbMifoVerksamheter.strEfterbehandlingsaatgaerderGenomfoerda, dbo.tbMifoVerksamheter.strTypAvGenomfoerdaAatgaerder,
                      dbo.tbMifoVerksamheter.strKonflikter, dbo.tbMifoVerksamheter.strAvloppsvattenFraanProcessernaNuvarandeHantering,
                      dbo.tbMifoVerksamheter.strAvloppsvattenFraanProcessernaTidigareHantering, dbo.tbMifoVerksamheter.strTypAvPlaneradeAatgaerder,
                      dbo.tbMifoVerksamheter.bolEfterbehandlingsaatgaerderPlanerade, dbo.tbMifoOmgivning.strMarkanvObjekt,
                      dbo.tbMifoOmgivning.strMarkanvPaaverkansOmr, dbo.tbMifoOmgivning.strAvstaandBostadsomr, dbo.tbMifoOmgivning.strVegetationsskadaObjekt,
                      dbo.tbMifoOmgivning.strVegetationsskadaPaaverkansOmr, dbo.tbMifoOmgivning.strJordartTyp, dbo.tbMifoOmgivning.strTopografi,
                      dbo.tbMifoOmgivning.strRecipientNamn, dbo.tbMifoOmgivning.strRecipientTyp, dbo.tbMifoOmgivning.strRecipientAvstaand,
                      dbo.tbMifoOmgivning.intMifoAvrinningId, dbo.tbMifoOmgivning.strByggnader, dbo.tbMifoOmgivning.strDagvattenDraeneringTyp,
                      dbo.tbMifoOmgivning.strDagvattenRecipientTyp, dbo.tbMifoOmgivning.strOevrigt, dbo.tbMifoSpridning.strByggFoeroreningar,
                      dbo.tbMifoSpridning.strByggSpridningssaett, dbo.tbMifoSpridning.strByggKonstateradHist, dbo.tbMifoSpridning.strByggOevrigt,
                      dbo.tbMifoSpridning.strByggUtlakning, dbo.tbMifoSpridning.strMarkFoeroreningar, dbo.tbMifoSpridning.strMarkGenomsMark,
                      dbo.tbMifoSpridning.strMarkGenomsBygg, dbo.tbMifoSpridning.strMarkOevrigt, dbo.tbMifoSpridning.strMarkKonstateradHist,
                      dbo.tbMifoSpridning.strMarkGasintraengning, dbo.tbMifoSpridning.strFoeroreningLokalisering, dbo.tbMifoSpridning.strGrundFoeroreningar,
                      dbo.tbMifoSpridning.strGrundGenomsMark, dbo.tbMifoSpridning.strGrundLutning, dbo.tbMifoSpridning.strGrundStroemning,
                      dbo.tbMifoSpridning.strGrundNedbrytbara, dbo.tbMifoSpridning.strGrundNedbrytHast, dbo.tbMifoSpridning.strGrundFoeroreningarMark,
                      dbo.tbMifoSpridning.strGrundOrganisktKol, dbo.tbMifoSpridning.strGrundAndraBind, dbo.tbMifoSpridning.strGrundNaturTransport,
                      dbo.tbMifoSpridning.strGrundAntropogenaTransport, dbo.tbMifoSpridning.strGrundKonstateradHist, dbo.tbMifoSpridning.strGrundOevrigt,
                      dbo.tbMifoSpridning.strGrundSpridningsHast, dbo.tbMifoSpridning.strDammFoeroreningar, dbo.tbMifoSpridning.strDammTorrhet,
                      dbo.tbMifoSpridning.strDammVegetation, dbo.tbMifoSpridning.strDammVind, dbo.tbMifoSpridning.strDammKonstateradHist,
                      dbo.tbMifoSpridning.strDammSpridningsHast, dbo.tbMifoSpridning.strDammOevrigt, dbo.tbMifoSpridning.strFasFoeroreningar,
                      dbo.tbMifoSpridning.strFasGenomsMark, dbo.tbMifoSpridning.strFasViskositet, dbo.tbMifoSpridning.strFasKonstateraddHist,
                      dbo.tbMifoSpridning.strFasSpridningHast, dbo.tbMifoSpridning.strFasOevrigt, dbo.tbMifoSpridning.strMaGvKonstateradHist,
                      dbo.tbMifoSpridning.strMaGvHotadeYtvatten, dbo.tbMifoSpridning.strMaGvFoeroreningsHast, dbo.tbMifoSpridning.strMaGvAvstaandYtvatten,
                      dbo.tbMifoSpridning.strMaGvYtavrinning, dbo.tbMifoSpridning.strMaGvVarierandeNivaaer, dbo.tbMifoSpridning.strMaGvOevrigt,
                      dbo.tbMifoSpridning.strMaGvSpridningstid, dbo.tbMifoSpridning.strYtVaFoeroreningar, dbo.tbMifoSpridning.strYtVaTransportHast,
                      dbo.tbMifoSpridning.strYtVaUtspaedning, dbo.tbMifoSpridning.strYtVaOjaemnSpridning, dbo.tbMifoSpridning.strYtVaKonstateradHist,
                      dbo.tbMifoSpridning.strYtVaSpridningsHast, dbo.tbMifoSpridning.strYtVaOevrigt, dbo.tbMifoSpridning.strSedKonstateradHist,
                      dbo.tbMifoSpridning.strSedFoeroreningarVatten, dbo.tbMifoSpridning.strSedSedimentation, dbo.tbMifoSpridning.strSedBaattrafik,
                      dbo.tbMifoSpridning.strSedMuddring, dbo.tbMifoSpridning.strSedVaagor, dbo.tbMifoSpridning.strSedGasbildning,
                      dbo.tbMifoSpridning.strSedFoeroreningar, dbo.tbMifoSpridning.strSedJaemnUtbredning, dbo.tbMifoSpridning.strSedOjaemnUtbredning,
                      dbo.tbMifoSpridning.strSedOevrigt, dbo.tbMifoSamladRiskbedoemning.strVerksamhetBransch,
                      dbo.tbMifoSamladRiskbedoemning.strFoeroreningsfarlighetLaag, dbo.tbMifoSamladRiskbedoemning.strFoeroreningsfarlighetMaattlig,
                      dbo.tbMifoSamladRiskbedoemning.strFoeroreningsfarlighetHoeg, dbo.tbMifoSamladRiskbedoemning.strFoeroreningsfarlighetMycketHoeg,
                      dbo.tbMifoExponering.strKbedoemningKS, dbo.tbMifoExponering.strKMarkanvaendning, dbo.tbMifoExponering.strKKortBeskrivning,
                      dbo.tbMifoExponering.strAndraPrioGrunder, dbo.tbMifoExponering.strFoeroreningExponeringSaett, dbo.tbMifoExponering.strAndraRecipHot,
                      dbo.tbMifoExponering.strAndraSammaVerksamhet, dbo.tbMifoExponering.strExponeringOevrigt
FROM         dbo.tbMifoObjekt LEFT OUTER JOIN
                      dbo.tbMifoExponering ON dbo.tbMifoObjekt.recObjektID = dbo.tbMifoExponering.recObjektID LEFT OUTER JOIN
                      dbo.tbMifoSamladRiskbedoemning ON dbo.tbMifoObjekt.recObjektID = dbo.tbMifoSamladRiskbedoemning.recObjektID LEFT OUTER JOIN
                      dbo.tbMifoSpridning ON dbo.tbMifoObjekt.recObjektID = dbo.tbMifoSpridning.recObjektID LEFT OUTER JOIN
                      dbo.tbMifoOmgivning ON dbo.tbMifoObjekt.recObjektID = dbo.tbMifoOmgivning.recObjektID LEFT OUTER JOIN
                      dbo.tbMifoVerksamheter ON dbo.tbMifoObjekt.recObjektID = dbo.tbMifoVerksamheter.recObjektID LEFT OUTER JOIN
                      dbo.tbMifoObjektsinfo ON dbo.tbMifoObjekt.recObjektID = dbo.tbMifoObjektsinfo.recObjektID LEFT OUTER JOIN
                      dbo.tbMifoFastighet ON dbo.tbMifoObjekt.recObjektID = dbo.tbMifoFastighet.recObjektID LEFT OUTER JOIN
                      dbo.tbMifoKommunicering ON dbo.tbMifoObjekt.recObjektID = dbo.tbMifoKommunicering.recObjektID
go

