

CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell15Anmaelan]
AS
SELECT     tbAehPblTaxa2011Tabell15Anmaelan.recTabell15ID, 
           recAnmaelanID as 'intRecnum', 
		   recAnmaelanID,
		   strObjekt,
		   recTaxa2011ID,
		   strBeskrivning,
		   intHF
FROM         dbo.tbAehPblTaxa2011Tabell15Anmaelan
LEFT OUTER JOIN vwAehPblTaxa2011Tabell15 
ON vwAehPblTaxa2011Tabell15.recTabell15ID = tbAehPblTaxa2011Tabell15Anmaelan.recTabell15ID


go

