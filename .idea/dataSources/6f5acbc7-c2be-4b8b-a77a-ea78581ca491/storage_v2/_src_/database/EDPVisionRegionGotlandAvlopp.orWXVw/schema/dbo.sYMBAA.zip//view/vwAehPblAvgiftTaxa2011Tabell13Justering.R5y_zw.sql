

CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell13Justering]
AS
SELECT		recPblAvgiftTaxa2011Tabell13ID, 
			recPblAvgiftTaxa2011Tabell13JusteringID as 'intRecnum',
			recPblAvgiftTaxa2011Tabell13JusteringID,
			strAatgaerd,
			strBeskrivning,
			decHF1,
			decHF2,
			decOF
FROM         dbo.tbAehPblAvgiftTaxa2011Tabell13Justering

go

