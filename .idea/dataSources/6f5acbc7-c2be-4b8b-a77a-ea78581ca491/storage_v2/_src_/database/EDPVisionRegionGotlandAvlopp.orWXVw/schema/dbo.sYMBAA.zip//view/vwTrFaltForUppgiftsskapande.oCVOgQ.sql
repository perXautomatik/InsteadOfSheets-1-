CREATE VIEW [dbo].[vwTrFältFörUppgiftsskapande]
AS
SELECT 'Köldmedia - Nästa kontroll' as alternativ, 1 as intRecnum
UNION
SELECT 'Brandfarliga varor - Nästa kontroll' as alternativ, 2 as intRecnum
UNION
SELECT 'Enskilda avlopp - Nästa service' as alternativ, 3 as intRecnum
UNION
SELECT 'Enskilda avlopp - Dispens t.o.m.' as alternativ, 4 as intRecnum
UNION
SELECT 'Hissar - Nästa besiktning' as alternativ, 5 as intRecnum
UNION
SELECT 'Hissar - Ombesiktning' as alternativ, 6 as intRecnum
UNION
SELECT 'Ventilationsaggregat - Ombesiktning' as alternativ, 7 as intRecnum
UNION
SELECT 'Ventilationsaggregat - Nästa besiktning' as alternativ, 8 as intRecnum
go

