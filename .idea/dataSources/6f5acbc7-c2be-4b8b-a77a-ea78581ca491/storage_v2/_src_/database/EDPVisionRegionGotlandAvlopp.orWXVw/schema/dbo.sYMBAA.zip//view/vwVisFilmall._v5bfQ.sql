
CREATE VIEW [dbo].[vwVisFilmall]
AS
WITH versionNR AS
  (SELECT recFileObjectID,
     MAX(intFileVersion) AS intFileVersion
   FROM tbEDPFileVersion
   GROUP BY recFileObjectID)
SELECT tbVisFilmall.recFilmallID,
       tbVisFilmall.recFileObjectID,
       tbVisFilmall.strMallnamn,
       tbVisFilmall.strFilmallTyp,
       tbVisFilmall.strKategori,
       tbVisFilmall.strFilnamnsmall,
       tbVisFilmall.bolEjAktuell,
       tbVisFilmall.recFilmallID AS intRecnum,
       tbEDPFileUnmanagedFiles.recUnmanagedfileID, 
       tbEDPFileUnmanagedFiles.datDatum AS datEjInlagrad, 
       tbEDPFileVersion.datFileVersionDate as datLastFileVersionDate,
       tbEDPFileVersion.strFiletype,
       CASE
       WHEN tbEDPFileObjectLocked.datCheckOutDateTime IS NOT NULL THEN
            (SELECT strSignature
             FROM tbEDPUser
             WHERE intUserID = tbEDPFileObjectLocked.intUserID)
       WHEN tbEDPFileObject.recFileObjectID IS NULL
          AND tbEDPFileUnmanagedFiles.datDatum IS NOT NULL THEN
            (SELECT strSignature
             FROM tbEDPUser
             WHERE intUserID = tbEDPFileUnmanagedFiles.intUserID)
       END AS 'strUtcheckadAv',
       CASE
       WHEN tbEDPFileObjectLocked.datCheckOutDateTime IS NOT NULL THEN tbEDPFileObjectLocked.datCheckOutDateTime
       WHEN tbEDPFileObject.recFileObjectID IS NULL
          AND tbEDPFileUnmanagedFiles.datDatum IS NOT NULL THEN tbEDPFileUnmanagedFiles.datDatum
       END AS datUtcheckad,
       CASE
       WHEN tbEDPFileObjectLocked.datCheckOutDateTime IS NOT NULL THEN tbEDPFileObjectLocked.strCheckedOutFileName
       WHEN tbEDPFileObject.recFileObjectID IS NULL
          AND tbEDPFileUnmanagedFiles.datDatum IS NOT NULL THEN tbEDPFileUnmanagedFiles.strFullFilePath
       END AS strCheckedOutFileName,
       CASE
       WHEN tbEDPFileObjectLocked.datCheckOutDateTime IS NOT NULL THEN 'Utcheckad'
       WHEN tbEDPFileObject.recFileObjectID IS NULL
          AND tbEDPFileUnmanagedFiles.datDatum IS NOT NULL THEN 'Ej inlagrad'
       END AS strStatus
FROM tbVisFilmall
LEFT OUTER JOIN tbEDPFileObject 
  ON tbEDPFileObject.recFileObjectID = tbVisFilmall.recFileObjectID
LEFT OUTER JOIN tbEDPFileObjectLocked 
  ON tbEDPFileObjectLocked.recFileObjectID = tbVisFilmall.recFileObjectID
LEFT OUTER JOIN tbEDPFileUnmanagedFiles 
  ON tbEDPFileUnmanagedFiles.recFilmallID = tbVisFilmall.recFilmallID
LEFT OUTER JOIN versionNR 
  ON versionNR.recFileObjectID = tbVisFilmall.recFileObjectID
LEFT OUTER JOIN tbEDPFileVersion 
  ON tbEDPFileVersion.recFileObjectID = versionNR.recFileObjectID
  AND tbEDPFileVersion.intFileVersion = versionNR.intFileVersion

go

