


CREATE VIEW [dbo].[vwVisRubrikRegister]
AS
SELECT		recRubrikRegisterID, 
			recRubrikID, 
			strRegister
													
FROM         tbVisRubrikRegister



go

