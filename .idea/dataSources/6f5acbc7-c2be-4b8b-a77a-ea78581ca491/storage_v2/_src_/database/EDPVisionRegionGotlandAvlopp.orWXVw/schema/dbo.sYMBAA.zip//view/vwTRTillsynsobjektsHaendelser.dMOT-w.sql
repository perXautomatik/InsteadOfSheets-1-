CREATE VIEW vwTRTillsynsobjektsHaendelser
AS
--- Fuskvy för att kunna skapa GridID, data hämtas inifrån programmet
SELECT NULL AS datAllmaenHandling,
         '' AS strDiarienummer,
         '' AS strRiktning,
         '' AS strHaendelsekategori,
         '' AS strRubrik,
         '' AS strHuvudhandlaeggare,
          0 AS intAntalFiler
go

