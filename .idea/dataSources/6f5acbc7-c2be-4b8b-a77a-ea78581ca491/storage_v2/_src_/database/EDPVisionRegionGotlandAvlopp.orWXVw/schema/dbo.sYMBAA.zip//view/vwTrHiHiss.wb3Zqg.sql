


CREATE VIEW [dbo].[vwTrHiHiss]
AS

SELECT		tbTrHiHiss.recHissID,
			tbTrHiHiss.recHissID AS intRecNum,
			tbTrHiHiss.recTillsynsobjektID,
			tbTrHiHiss.strRegistreringsnummer,
			tbTrHiHiss.strUppstaellningsplats,
			tbTrHiHiss.strStatus,
			tbTrHiHiss.datStatusdatum,
			tbTrHiHiss.strHisstyp,
			tbTrHiHiss.intMaxLast,
			tbTrHiHiss.intMaxAntalPersoner,
			tbTrHiHiss.strAnteckningar,
			tbTrHiHiss.intBesiktningsintervallMaanader,
			tbTrHiHiss.datFoeregaaendeBesiktning,
			tbTrHiHiss.datOmbesiktning,
			tbTrHiHiss.datNaestaBesiktning,
			
			tbTrTillsynsobjekt.strObjektsNamn,
			tbTrTillsynsobjekt.recTillsynsobjektTypID,
			
			tbVisDeladFastighet.strFnrID,
			tbVisDeladFastighet.strFastighetsbeteckning
			
FROM		tbTrHiHiss 

LEFT JOIN	tbTrTillsynsobjekt 
	ON		tbTrTillsynsobjekt.recTillsynsobjektID = tbTrHiHiss.recTillsynsobjektID
	
LEFT JOIN	tbTrHiHissFastighet
	ON		tbTrHiHissFastighet.recHissID = tbTrHiHiss.recHissID 
	AND		tbTrHiHissFastighet.bolHuvudfastighet = 1

LEFT JOIN	tbVisDeladFastighet
		ON	tbVisDeladFastighet.strFnrID = tbTrHiHissFastighet.strFnrID



go

