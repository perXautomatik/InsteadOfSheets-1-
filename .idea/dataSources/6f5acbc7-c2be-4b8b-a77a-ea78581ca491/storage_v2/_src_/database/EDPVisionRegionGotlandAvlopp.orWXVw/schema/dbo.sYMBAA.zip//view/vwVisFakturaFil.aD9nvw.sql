

CREATE VIEW [dbo].[vwVisFakturaFil]
AS
SELECT     recFakturaFilID,
           intFakturaFilNr,
           datSkapad,
           (SELECT     COUNT(fffu.recFakturaUnderlagID) AS Expr1
					  FROM          dbo.tbVisFakturaFilFakturaUnderlag AS fffu
					  WHERE      (fffu.recFakturaFilID = ff.recFakturaFilID)) AS intAntFakturaUnderlag,

          (SELECT     COUNT(d.recDebiteringID) AS Expr1
                      FROM          dbo.tbVisDebitering AS d
                      INNER JOIN dbo.tbVisFakturaFilFakturaUnderlag AS fffu
                      ON d.recFakturaUnderlagID = fffu.recFakturaUnderlagID
                      WHERE      (fffu.recFakturaFilID = ff.recFakturaFilID)) AS intAntDebiteringsPoster,

           bolInlaestEkonomiSystem,
           strFilterFakturaUnderlag,
           strFilterFakturaDatum,
           strFilterUtskriftsDatum,
           strFilterKundNr,
           strFilterFoervaltning,
           strFilterAvdelning,
           strFilterEnhet,
           strFilterHandlaeggare,
           bolFilterInternaFakturor,
           bolFilterExternaFakturor,
           bolFilterEjUtskrivna,
           bolFilterRedanUtskrivna,
           binFilter
FROM       dbo.tbVisFakturaFil AS ff
go

