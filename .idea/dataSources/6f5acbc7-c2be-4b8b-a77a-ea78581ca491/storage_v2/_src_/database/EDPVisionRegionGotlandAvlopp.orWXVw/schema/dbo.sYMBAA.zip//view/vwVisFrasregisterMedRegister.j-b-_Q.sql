

CREATE VIEW [dbo].[vwVisFrasregisterMedRegister]
AS

SELECT		tbVisFrasregister.recFrasregisterID,
			tbVisFrasregister.recFrasregisterID AS intRecNum,
			tbVisFrasregister.strFraskod,
			tbVisFrasregister.strText,
			tbVisFrasregisterRegister.recFrasregisterRegisterID, 
			tbVisFrasregisterRegister.strRegister
FROM		tbVisFrasregister
LEFT JOIN	tbVisFrasregisterRegister	
	ON		tbVisFrasregisterRegister.recFrasregisterID = tbVisFrasregister.recFrasregisterID


go

