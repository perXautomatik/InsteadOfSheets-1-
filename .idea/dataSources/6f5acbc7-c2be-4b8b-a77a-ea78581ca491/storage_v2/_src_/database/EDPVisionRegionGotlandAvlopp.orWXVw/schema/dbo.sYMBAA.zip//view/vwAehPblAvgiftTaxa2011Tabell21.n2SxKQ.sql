
CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell21]
AS
SELECT
  dbo.tbAehPblAvgiftTaxa2011Tabell21.recAehPblAvgiftTaxa2011Tabell21ID, 
  dbo.tbAehPblAvgiftTaxa2011Tabell21.recAehPblAvgiftTaxa2011Tabell21ID AS intRecnum, 
  dbo.tbAehPblAvgiftTaxa2011Tabell21.bolDebiterad, 
  dbo.tbAehPblAvgiftTaxa2011Tabell21.decAvgift, 
  dbo.tbAehPblAvgiftTaxa2011Tabell21.intHF, 
  dbo.tbAehPblAvgiftTaxa2011Tabell21.decmPBB, 
  dbo.tbAehPblAvgiftTaxa2011Tabell21.decN, 
  dbo.tbAehPblAvgiftTaxa2011Tabell21.recAvgiftID
FROM dbo.tbAehPblAvgiftTaxa2011Tabell21

go

