
CREATE PROCEDURE [dbo].[spAehAerendeDataUpdate]
  @recAerendeID INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

  UPDATE dbo.tbAehAerendeData SET
    recDiarieSerieID = dbo.tbAehDiarieAarsSerie.recDiarieSerieID, 
    intDiarieAar = dbo.tbAehDiarieAarsSerie.intDiarieAar,
    intSerieStartVaerde = dbo.tbAehDiarieAarsSerie.intSerieStartVaerde,
    strDiarieSerieKod = dbo.tbAehDiarieSerie.strDiarieSerieKod,
    strDiarienummer = dbo.tbAehAerende.strDiarienummerSerie 
      + '-' + CAST((dbo.tbAehDiarieAarsSerie.intDiarieAar) AS varchar(4)) 
      + '-' + CAST(dbo.tbAehAerende.intDiarienummerLoepNummer AS varchar(6))
  FROM dbo.tbAehAerendeData
  LEFT OUTER JOIN dbo.tbAehAerende
    ON dbo.tbAehAerende.recAerendeID = dbo.tbAehAerendeData.recAerendeID
  LEFT OUTER JOIN dbo.tbAehDiarieAarsSerie
    ON dbo.tbAehDiarieAarsSerie.recDiarieAarsSerieID = dbo.tbAehAerende.recDiarieAarsSerieID
  LEFT OUTER JOIN dbo.tbAehDiarieSerie 
    ON dbo.tbAehDiarieAarsSerie.recDiarieSerieID = dbo.tbAehDiarieSerie.recDiarieSerieID 
  WHERE dbo.tbAehAerendeData.recAerendeID = @recAerendeID

END
go

