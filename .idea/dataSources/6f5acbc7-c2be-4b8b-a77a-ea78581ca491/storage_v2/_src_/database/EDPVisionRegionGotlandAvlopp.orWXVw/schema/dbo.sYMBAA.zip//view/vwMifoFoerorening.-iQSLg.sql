CREATE VIEW dbo.vwMifoFoerorening
AS
SELECT     dbo.tbMifoFoerorening.recFoeroreningID, dbo.tbMifoFoerorening.recObjektID, dbo.tbMifoFoerorening.strLokalisering, dbo.tbMifoFoerorening.strVolym,
                      dbo.tbMifoFoerorening.strUtbredning, dbo.tbMifoFoerorening.strFoerorening, dbo.tbMifoFoerorening.intXKoordinat,
                      dbo.tbMifoFoerorening.intYKoordinat, dbo.tbMifoFoerorening.strZKoordinat, dbo.tbMifoObjekt.strObjektId, dbo.tbMifoObjekt.strObjektNamn,
                      dbo.tbMifoFoerorening.recFoeroreningID AS intRecnum, dbo.tbMifoFoerorening.strMedium
FROM         dbo.tbMifoFoerorening LEFT OUTER JOIN
                      dbo.tbMifoObjekt ON dbo.tbMifoFoerorening.recObjektID = dbo.tbMifoObjekt.recObjektID
go

