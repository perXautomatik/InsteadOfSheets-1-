

CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell26DigitalGeografiskInformation]
AS
SELECT	recDigitalGeografiskInformationID,
		recDigitalGeografiskInformationID as 'intRecnum', 
		tbAehPblTaxa2011Tabell26DigitalGeografiskInformation.recTabell26ID, 
		strInformationstyp, 
		strAatgaerd, 
		strBeskrivning, 
		recTaxa2011ID,
		decKF

FROM	dbo.tbAehPblTaxa2011Tabell26DigitalGeografiskInformation
LEFT OUTER JOIN vwAehPblTaxa2011Tabell26 
ON vwAehPblTaxa2011Tabell26.recTabell26ID = tbAehPblTaxa2011Tabell26DigitalGeografiskInformation.recTabell26ID

go

