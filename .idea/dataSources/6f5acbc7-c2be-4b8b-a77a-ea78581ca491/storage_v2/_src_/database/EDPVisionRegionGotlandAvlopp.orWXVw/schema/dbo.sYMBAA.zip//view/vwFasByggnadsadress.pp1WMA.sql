CREATE VIEW dbo.vwFasByggnadsadress
AS
SELECT     strADROMRADE, strKOMDELLAGE, MAX(recADRPL) AS intRecNum, strFNRID
FROM         dbo.tbFasADRPL
GROUP BY strADROMRADE, strKOMDELLAGE, strFNRID
go

