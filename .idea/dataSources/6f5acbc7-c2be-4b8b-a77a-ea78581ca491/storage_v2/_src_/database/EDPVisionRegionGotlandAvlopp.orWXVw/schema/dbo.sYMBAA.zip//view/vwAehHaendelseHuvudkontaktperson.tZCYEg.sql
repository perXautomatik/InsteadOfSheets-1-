


CREATE VIEW [dbo].[vwAehHaendelseHuvudkontaktperson]
AS

SELECT 
	tbAehHaendelseEnstakaKontakt.recHaendelseID
	, tbAehHaendelseEnstakaKontakt.strRoll
	, vwVisEnstakaKontakt.* 
FROM tbAehHaendelseEnstakaKontakt 
INNER JOIN vwVisEnstakaKontakt ON vwVisEnstakaKontakt.recEnstakaKontaktID = tbAehHaendelseEnstakaKontakt.recEnstakaKontaktID
WHERE bolHuvudkontakt = 1
go

