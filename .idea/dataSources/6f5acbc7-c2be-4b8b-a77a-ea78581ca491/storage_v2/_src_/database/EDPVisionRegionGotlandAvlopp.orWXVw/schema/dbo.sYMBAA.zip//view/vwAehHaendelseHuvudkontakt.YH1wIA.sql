CREATE VIEW [dbo].[vwAehHaendelseHuvudkontakt]
AS

SELECT tbAehHaendelseEnstakaKontakt.recHaendelseID,
  tbAehHaendelseEnstakaKontakt.recEnstakaKontaktID,
  tbAehHaendelseEnstakaKontakt.strRoll,
  tbVisEnstakaKontakt.strFoernamn,
  tbVisEnstakaKontakt.strEfternamn,
  tbVisEnstakaKontakt.strFoeretag,
  tbVisEnstakaKontakt.strOrginisationPersonnummer AS strOrganisationsPersonnummer,
  tbVisEnstakaKontakt.strTitel,
  tbVisEnstakaKontakt.strKontakttyp,
  tbVisEnstakaKontakt.strGatuadress,
  tbVisEnstakaKontakt.strCoadress,
  tbVisEnstakaKontakt.strPostnummer,
  tbVisEnstakaKontakt.strPostort,
  tbVisEnstakaKontakt.strLand,
  LTRIM(tbVisEnstakaKontakt.strFoernamn + ' ' + tbVisEnstakaKontakt.strEfternamn) AS strNamn,
  tbVisEnstakaKontakt.strVisasSom,
  tbVisEnstakaKontakt.strSammanslagenAdress,
  vwVisEnstakaKontaktGrid.strKommunikationssaett,
  (SELECT REPLACE(((SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett 
    INNER JOIN tbVisEnstakaKontaktKommunikationssaett
      ON tbVisEnstakaKontaktKommunikationssaett.recKommunikationssaettID = tbVisKommunikationssaett.recKommunikationssaettID
    WHERE recEnstakaKontaktID = tbVisEnstakaKontakt.recEnstakaKontaktID 
      AND strKommunikationsaettTyp = 'E-Post'
    FOR XML PATH(''))
    + '...'), ', ...', '') 
    FROM tbVisEnstakaKontakt
    WHERE recEnstakaKontaktID = tbAehHaendelseEnstakaKontakt.recEnstakaKontaktID) AS strEpost,
  (SELECT REPLACE(((SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett 
    INNER JOIN tbVisEnstakaKontaktKommunikationssaett
      ON tbVisEnstakaKontaktKommunikationssaett.recKommunikationssaettID = tbVisKommunikationssaett.recKommunikationssaettID
    WHERE recEnstakaKontaktID = tbVisEnstakaKontakt.recEnstakaKontaktID 
      AND strKommunikationsaettTyp = 'Fax'
    FOR XML PATH(''))
    + '...'), ', ...', '') 
    FROM tbVisEnstakaKontakt
    WHERE recEnstakaKontaktID = tbAehHaendelseEnstakaKontakt.recEnstakaKontaktID) AS strFax,
  (SELECT REPLACE(((SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett 
    INNER JOIN tbVisEnstakaKontaktKommunikationssaett
      ON tbVisEnstakaKontaktKommunikationssaett.recKommunikationssaettID = tbVisKommunikationssaett.recKommunikationssaettID
    WHERE recEnstakaKontaktID = tbVisEnstakaKontakt.recEnstakaKontaktID 
      AND strKommunikationsaettTyp = 'Telefon'
    FOR XML PATH(''))
    + '...'), ', ...', '') 
    FROM tbVisEnstakaKontakt
    WHERE recEnstakaKontaktID = tbAehHaendelseEnstakaKontakt.recEnstakaKontaktID) AS strTelefon,
  (SELECT REPLACE(((SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett 
    INNER JOIN tbVisEnstakaKontaktKommunikationssaett
      ON tbVisEnstakaKontaktKommunikationssaett.recKommunikationssaettID = tbVisKommunikationssaett.recKommunikationssaettID
    WHERE recEnstakaKontaktID = tbVisEnstakaKontakt.recEnstakaKontaktID 
      AND strKommunikationsaettTyp = 'Mobil'
    FOR XML PATH(''))
    + '...'), ', ...', '') 
    FROM tbVisEnstakaKontakt
    WHERE recEnstakaKontaktID = tbAehHaendelseEnstakaKontakt.recEnstakaKontaktID) AS strMobil
FROM vwVisEnstakaKontaktGrid 
INNER JOIN tbAehHaendelseEnstakaKontakt
ON tbAehHaendelseEnstakaKontakt.recEnstakaKontaktID = vwVisEnstakaKontaktGrid.recEnstakaKontaktID
AND tbAehHaendelseEnstakaKontakt.bolHuvudkontakt = 1
INNER JOIN tbVisEnstakaKontakt
ON tbVisEnstakaKontakt.recEnstakaKontaktID = tbAehHaendelseEnstakaKontakt.recEnstakaKontaktID
go

