
            CREATE PROCEDURE [dbo].[spWriteHistoryLogRow]
            @gGuid as uniqueidentifier,
            @idColumnValue as int,
            @userID as int,
            @datChanged as datetime,
            @tableName varchar(150),
            @logType varchar(10),
            @columnName varchar(150),
            @columnValue varchar(max)

            AS
            BEGIN
            insert into tbHistoryLog 
	            (guidLogTicket, strLogType, strTableName, strColumnName, value, intFrameworkID, intUserID, datChanged) 
	            values
	            (@gGuid, @logType, @tableName, @columnName, @columnValue, @idColumnValue, @userID, @datChanged)

            END

            go

