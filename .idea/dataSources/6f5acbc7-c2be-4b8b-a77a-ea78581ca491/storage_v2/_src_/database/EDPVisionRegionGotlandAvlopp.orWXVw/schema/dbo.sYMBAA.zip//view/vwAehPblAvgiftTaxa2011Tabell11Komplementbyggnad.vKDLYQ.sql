


CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell11Komplementbyggnad]
AS
SELECT     recPblAvgiftTaxa2011Tabell11ID, recPblAvgiftTaxa2011Tabell11ID as 'intRecnum', recPblAvgiftTaxa2011Tabell11KomplementbyggnadID,strObjekt,strBeskrivning,intOf,intHF1,intHF2
FROM dbo.tbAehPblAvgiftTaxa2011Tabell11Komplementbyggnad

go

