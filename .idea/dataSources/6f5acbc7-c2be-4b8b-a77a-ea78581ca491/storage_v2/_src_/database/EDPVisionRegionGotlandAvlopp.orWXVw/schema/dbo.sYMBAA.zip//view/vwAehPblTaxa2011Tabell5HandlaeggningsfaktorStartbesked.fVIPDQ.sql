


CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell5HandlaeggningsfaktorStartbesked]
AS
SELECT     tbAehPblTaxa2011Tabell5HandlaeggningsfaktorStartbesked.recTabell5ID, 
           recHandlaeggningsfaktorStartID as 'intRecnum', 
		   recHandlaeggningsfaktorStartID,
		   strAatgaerd,
		   strBeskrivning,
		   recTaxa2011ID,
		   intHF2
FROM         dbo.tbAehPblTaxa2011Tabell5HandlaeggningsfaktorStartbesked
LEFT OUTER JOIN vwAehPblTaxa2011Tabell5
ON vwAehPblTaxa2011Tabell5.recTabell5ID = tbAehPblTaxa2011Tabell5HandlaeggningsfaktorStartbesked.recTabell5ID

go

