
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
Create PROCEDURE [dbo].[spEDPGetSubParameterBySubParameterID] 
  @intSubParameterID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

  SELECT intSubParameterID, strSubParameterName, strSubParameterDescription, intSubParameterSearchMethodID, strSubParameterValueLookUpID, intSubParameterValueTypeID, intSubParameterValueLength, strSearchMethodName, strValueTypeName
    FROM tbEDPSubParameter INNER JOIN tbEDPValueType 
      ON tbEDPSubParameter.intSubParameterValueTypeID = tbEDPValueType.intValueTypeID 
        INNER JOIN tbEDPSearchMethod 
          ON tbEDPSubParameter.intSubParameterSearchMethodID = tbEDPSearchMethod.intSearchMethodID
    WHERE intSubParameterID = @intSubParameterID
END

go

