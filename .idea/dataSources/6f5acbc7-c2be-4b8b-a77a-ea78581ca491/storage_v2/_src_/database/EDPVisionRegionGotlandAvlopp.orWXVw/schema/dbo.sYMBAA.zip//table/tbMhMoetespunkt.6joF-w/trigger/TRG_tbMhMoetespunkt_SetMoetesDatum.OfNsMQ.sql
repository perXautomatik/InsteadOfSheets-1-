
        CREATE TRIGGER TRG_tbMhMoetespunkt_SetMoetesDatum ON tbMhMoetespunkt
        AFTER  UPDATE,DELETE

        AS
BEGIN
        DECLARE moetespunktID_cursor CURSOR FAST_FORWARD
        FOR
            SELECT recMoetespunktID FROM INSERTED UNION SELECT recMoetespunktID FROM DELETED
        OPEN moetespunktID_cursor
        DECLARE @moetespunktID as INT
        FETCH NEXT FROM moetespunktID_cursor INTO @moetespunktID
        WHILE (@@fetch_status = 0)
        BEGIN

            DECLARE	aerendeid_cursor CURSOR FAST_FORWARD
            FOR
                SELECT recAerendeID FROM dbo.fnGetAerendeIdFromMoetespunkt(@moetespunktID)
            OPEN aerendeid_cursor
            DECLARE @aerendeId as INT
            FETCH NEXT FROM aerendeid_cursor INTO @aerendeId
            WHILE (@@fetch_status = 0)
            BEGIN
                UPDATE tbAehAerende SET datMoetesDatum = dbo.FnAehAerendeMoetesDatum(@aerendeId)
                WHERE recAerendeID = @aerendeId
            FETCH NEXT FROM aerendeid_cursor INTO @aerendeId
            END
            CLOSE aerendeid_cursor
            DEALLOCATE aerendeid_cursor

        FETCH NEXT FROM moetespunktID_cursor INTO @moetespunktID
        END

        CLOSE moetespunktID_cursor
		DEALLOCATE moetespunktID_cursor
END
        go

