
CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell21]
AS
SELECT     

recTabell21ID, 
recTaxa2011ID, 
recTabell21ID as 'intRecnum', 
dbo.tbAehPblTaxa2011Tabell21.recTjaenstID,
dbo.tbAehPblTaxa2011Tabell21.recFakturatextID,
strFritext,
decMoms,
	dbo.tbVisTjaenst.strTjaenstKod,
	dbo.tbVisTjaenst.strTjaenst,
	dbo.tbVisFakturatext.strFakturatextkod
	
FROM dbo.tbAehPblTaxa2011Tabell21

	LEFT OUTER JOIN dbo.tbVisFakturatext
	ON dbo.tbVisFakturatext.recFakturatextID = dbo.tbAehPblTaxa2011Tabell21.recFakturatextID
	
	LEFT OUTER JOIN dbo.tbVisTjaenst
	ON dbo.tbVisTjaenst.recTjaenstID = dbo.tbAehPblTaxa2011Tabell21.recTjaenstID


go

