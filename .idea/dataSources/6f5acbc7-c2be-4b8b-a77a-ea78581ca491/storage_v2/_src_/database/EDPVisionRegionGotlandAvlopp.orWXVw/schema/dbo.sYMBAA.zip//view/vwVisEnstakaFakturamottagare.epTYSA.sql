
CREATE VIEW [dbo].[vwVisEnstakaFakturamottagare]
AS

WITH KontaktKommunikationssaett AS (
SELECT recEnstakaFakturamottagareID, 
   

  (REPLACE( (SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett
    WHERE strKommunikationsaettTyp = 'Telefon' AND tbVisKommunikationssaett.recKommunikationssaettID IN 
      (SELECT recKommunikationssaettID FROM tbVisEnstakaKontaktKommunikationssaett 
        WHERE recEnstakaKontaktID =  tbVisEnstakaFakturamottagare.recEnstakaKontaktID
        
      )
    FOR XML PATH('')) + '...', ', ...','') 
  ) AS strTelefon,


  (REPLACE( (SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett
    WHERE strKommunikationsaettTyp = 'Mobil' AND tbVisKommunikationssaett.recKommunikationssaettID IN 
      (SELECT recKommunikationssaettID FROM tbVisEnstakaKontaktKommunikationssaett 
        WHERE recEnstakaKontaktID =  tbVisEnstakaFakturamottagare.recEnstakaKontaktID
        
      )
    FOR XML PATH('')) + '...', ', ...','') 
  ) AS strMobil	,

  (REPLACE( (SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett
    WHERE strKommunikationsaettTyp = 'Fax' AND tbVisKommunikationssaett.recKommunikationssaettID IN 
      (SELECT recKommunikationssaettID FROM tbVisEnstakaKontaktKommunikationssaett 
        WHERE recEnstakaKontaktID =  tbVisEnstakaFakturamottagare.recEnstakaKontaktID
        
      )
    FOR XML PATH('')) + '...', ', ...','') 
  ) AS strFax,	

  (REPLACE( (SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett
    WHERE strKommunikationsaettTyp = 'E-post' AND tbVisKommunikationssaett.recKommunikationssaettID IN 
      (SELECT recKommunikationssaettID FROM tbVisEnstakaKontaktKommunikationssaett 
        WHERE recEnstakaKontaktID =  tbVisEnstakaFakturamottagare.recEnstakaKontaktID
        
      )
    FOR XML PATH('')) + '...', ', ...','') 
  ) AS strEpost	


FROM tbVisEnstakaFakturamottagare
)



SELECT    dbo.tbVisEnstakaFakturamottagare.recEnstakaFakturamottagareID
		, dbo.tbVisEnstakaKontakt.strFoernamn
		, dbo.tbVisEnstakaKontakt.strEfternamn
		, dbo.tbVisEnstakaKontakt.strFoeretag
		, dbo.tbVisEnstakaKontakt.strOrginisationPersonnummer
		, dbo.tbVisEnstakaKontakt.strTitel
		, dbo.tbVisEnstakaKontakt.strKontaktTyp
		, dbo.tbVisEnstakaKontakt.strGatuadress
		, dbo.tbVisEnstakaKontakt.strCoadress
		, dbo.tbVisEnstakaKontakt.strPostnummer
		, dbo.tbVisEnstakaKontakt.strPostort
		, dbo.tbVisEnstakaKontakt.strLand
		, dbo.tbVisEnstakaKontakt.strVisasSom
		, dbo.tbVisEnstakaKontakt.strSammanslagenAdress
		, dbo.tbVisEnstakaFakturamottagare.recEnstakaFakturamottagareID AS intRecnum
		, dbo.tbVisEnstakaFakturamottagare.recEnstakaKontaktID
		, dbo.tbVisEnstakaFakturamottagare.bolLaast
		, dbo.tbVisEnstakaFakturamottagare.intIdNummer
		, dbo.tbVisEnstakaFakturamottagare.strExterntIdNummer
		, dbo.tbVisEnstakaFakturamottagare.bolIntern
		, dbo.tbVisEnstakaFakturamottagare.strSkanningskod
		, dbo.tbVisEnstakaFakturamottagare.strMotpartKoncernkod
		, dbo.tbVisEnstakaFakturamottagare.strFoerklaring
		, dbo.tbVisEnstakaFakturamottagare.strGLN
		, dbo.tbVisEnstakaFakturamottagare.strKommun
		, dbo.tbVisEnstakaFakturamottagare.strReferensnummer
		, dbo.tbVisEnstakaFakturamottagare.strIntBokfoeringsKonto
		, dbo.tbAehAerende.recAerendeID, dbo.tbVisDebitering.recDebiteringID,
	CASE WHEN(dbo.tbAehAerende.recAerendeID IS NOT NULL) THEN
		'Ärende: ' + dbo.tbAehAerendeData.strDiarienummer
	WHEN(dbo.tbVisDebitering.recDebiteringID IS NOT NULL) THEN
		'Debitering: ' + 
		CASE
			WHEN (dbo.tbVisDebitering.recAerendeID IS NOT NULL) 
			THEN 
				dbo.tbAehAerendeData.strDiarienummer + '/' + REPLACE(CONVERT(VARCHAR,dbo.tbVisDebitering.datSkapad, 102), '.', '-')
			WHEN (dbo.tbVisDebitering.recTillsynsobjektID IS NOT NULL)
			THEN
				CAST(dbo.tbVisDebitering.recTillsynsobjektID AS NVARCHAR(10)) + '/' + REPLACE(CONVERT(VARCHAR,dbo.tbVisDebitering.datSkapad, 102), '.', '-')
			ELSE
				REPLACE(CONVERT(VARCHAR,dbo.tbVisDebitering.datSkapad, 102), '.', '-')
		END 
	ELSE
		NULL
	END as strKoppladTill,
				KontaktKommunikationssaett.strTelefon,
				KontaktKommunikationssaett.strMobil,
				KontaktKommunikationssaett.strFax,
				KontaktKommunikationssaett.strEpost


FROM         dbo.tbVisEnstakaFakturamottagare INNER JOIN
             dbo.tbVisEnstakaKontakt ON dbo.tbVisEnstakaFakturamottagare.recEnstakaKontaktID = dbo.tbVisEnstakaKontakt.recEnstakaKontaktID
LEFT JOIN	 dbo.tbAehAerende
	ON		 dbo.tbVisEnstakaFakturamottagare.recEnstakaFakturamottagareID = dbo.tbAehAerende.recEnstakaFakturamottagareID
LEFT JOIN	 dbo.tbAehAerendeData
	ON		 dbo.tbAehAerende.recAerendeID = dbo.tbAehAerendeData.recAerendeID
LEFT JOIN	 dbo.tbVisDebitering
	ON	     dbo.tbVisEnstakaFakturamottagare.recEnstakaFakturamottagareID = dbo.tbVisDebitering.recEnstakaFakturamottagareID
LEFT OUTER JOIN KontaktKommunikationssaett
  ON KontaktKommunikationssaett.recEnstakaFakturamottagareID = tbVisEnstakaFakturamottagare.recEnstakaFakturamottagareID
go

