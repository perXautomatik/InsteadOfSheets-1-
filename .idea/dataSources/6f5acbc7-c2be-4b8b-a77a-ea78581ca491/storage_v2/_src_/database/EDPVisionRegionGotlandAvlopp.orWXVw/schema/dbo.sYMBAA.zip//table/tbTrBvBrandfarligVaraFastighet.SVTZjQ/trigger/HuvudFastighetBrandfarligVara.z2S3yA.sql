
        CREATE TRIGGER HuvudFastighetBrandfarligVara ON tbTrBvBrandfarligVaraFastighet
        AFTER INSERT
        AS
        BEGIN
        -- SET NOCOUNT ON; added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;

        DECLARE insert_cursor CURSOR FAST_FORWARD
        FOR
        SELECT recBrandfarligVaraID FROM INSERTED
        OPEN insert_cursor
        DECLARE @recBrandfarligVaraID as INT
        FETCH NEXT FROM insert_cursor INTO @recBrandfarligVaraID
        WHILE (@@fetch_status = 0)
        BEGIN
            IF (SELECT COUNT(recBrandfarligVaraFastighetID) FROM tbTrBvBrandfarligVaraFastighet WHERE recBrandfarligVaraID = @recBrandfarligVaraID ) = 1
            UPDATE tbTrBvBrandfarligVaraFastighet SET bolHuvudfastighet = 1 WHERE recBrandfarligVaraID = @recBrandfarligVaraID

            FETCH NEXT FROM insert_cursor INTO @recBrandfarligVaraID
        END
        CLOSE insert_cursor
        DEALLOCATE insert_cursor
        END
        go

