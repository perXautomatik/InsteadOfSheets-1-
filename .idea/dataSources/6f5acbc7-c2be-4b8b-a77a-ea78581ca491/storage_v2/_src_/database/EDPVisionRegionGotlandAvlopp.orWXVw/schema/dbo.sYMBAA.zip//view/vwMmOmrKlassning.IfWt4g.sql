CREATE VIEW [dbo].[vwMmOmrKlassning]
AS
SELECT     dbo.tbMmOmrKlassning.recOmrKlassningID AS intRecnum, dbo.tbMmOmrKlassning.recOmrID, dbo.tbMmOmrKlassning.recKlassningID,
                      dbo.tbMmOmrKlassning.bolHuvudklassning, dbo.tbMmKlassning.strKlassningNamn, dbo.tbMmOmrKlassning.recOmrKlassningID,
                      dbo.tbMmOmrKlassning.recKlassningvaerdeID, dbo.tbMmKlassningvaerde.strKlassningvaerde, dbo.tbMmKlassningvaerde.strKlassningvaerdeKommentar,
                      dbo.tbMmOmrKlassning.recDeladKontaktID, dbo.tbVisDeladKontakt.strVisasSom, dbo.tbMmOmrKlassning.strMotivering, dbo.tbMmOmraade.strRegKod,
                      dbo.tbMmOmraade.strOmrNr, dbo.tbMmOmraade.strLopNr, dbo.tbMmOmraade.strOmrNamn,
                      dbo.tbMmOmraade.strRegKod + '-' + dbo.tbMmOmraade.strOmrNr + '-' + dbo.tbMmOmraade.strLopNr AS strOmraadeKod
FROM         dbo.tbMmOmrKlassning LEFT OUTER JOIN
                      dbo.tbMmOmraade ON dbo.tbMmOmrKlassning.recOmrID = dbo.tbMmOmraade.recOmrID LEFT OUTER JOIN
                      dbo.tbVisDeladKontakt ON dbo.tbMmOmrKlassning.recDeladKontaktID = dbo.tbVisDeladKontakt.recDeladKontaktID LEFT OUTER JOIN
                      dbo.tbMmKlassningvaerde ON dbo.tbMmOmrKlassning.recKlassningvaerdeID = dbo.tbMmKlassningvaerde.recKlassningvaerdeID LEFT OUTER JOIN
                      dbo.tbMmKlassning ON dbo.tbMmOmrKlassning.recKlassningID = dbo.tbMmKlassning.recKlassningID
go

