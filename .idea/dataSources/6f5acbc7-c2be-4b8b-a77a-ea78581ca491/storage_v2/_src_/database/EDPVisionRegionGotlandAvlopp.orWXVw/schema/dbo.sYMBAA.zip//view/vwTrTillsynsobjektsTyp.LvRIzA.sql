
CREATE VIEW [dbo].[vwTrTillsynsobjektsTyp]
AS
SELECT  dbo.tbTrTillsynsobjektsTyp.recTillsynsobjektTypID AS intRecnum,
		dbo.tbTrTillsynsobjektsTyp.recTillsynsobjektTypID,
        dbo.tbTrTillsynsobjektsTyp.strTillsynsobjektsTypNamn,
        dbo.tbTrTillsynsobjektsTyp.strTillsynsTabellnamn,
        dbo.tbTrTillsynsobjektsTyp.bolEgendefinierat,
        dbo.tbTrTillsynsobjektsTyp.strAvgiftsflik,
        dbo.tbTrTillsynsobjektsTyp.recTimavgiftTjaenstID,
        dbo.tbVisTjaenst.strTjaenstKod AS strTimavgiftTjaenstKod,
        dbo.tbVisTjaenst.strTjaenst AS strTimavgiftTjaenst,
        dbo.tbTrTillsynsobjektsTyp.strAvgiftsberaekningsmodell,
        dbo.tbTrTillsynsobjektsTyp.bolEjAktuell
FROM         dbo.tbTrTillsynsobjektsTyp LEFT OUTER JOIN
                      dbo.tbVisTjaenst ON dbo.tbTrTillsynsobjektsTyp.recTimavgiftTjaenstID = dbo.tbVisTjaenst.recTjaenstID
go

