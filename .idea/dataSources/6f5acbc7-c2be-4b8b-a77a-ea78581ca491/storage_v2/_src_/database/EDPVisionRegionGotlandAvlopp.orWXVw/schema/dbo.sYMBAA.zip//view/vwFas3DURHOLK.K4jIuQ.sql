CREATE VIEW dbo.vwFas3DURHOLK
AS
SELECT     dbo.tbFas3DURHOLK.rec3DURHOLK, dbo.tbFas3DURHOLK.strOTYP, dbo.tbFas3DURHOLK.strDATUMLOP, dbo.tbFas3DURHOLK.strFNRID, 
                      dbo.tbFas3DURHOLK.intOMRNRID, dbo.tbFas3DURHOLK.strURHOLKFNRID, dbo.tbFas3DURHOLK.strSTATUS, 
                      dbo.vwFasFastighet.strFastighetsbeteckning, dbo.vwFasFastighet.strKOMMUN, dbo.tbFas3DURHOLK.rec3DURHOLK AS intRecnum
FROM         dbo.vwFasFastighet RIGHT OUTER JOIN
                      dbo.tbFas3DURHOLK ON dbo.vwFasFastighet.strFNRID = dbo.tbFas3DURHOLK.strURHOLKFNRID
go

