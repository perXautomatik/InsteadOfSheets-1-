CREATE VIEW [dbo].[vwFasLagfarenAegare]
AS
SELECT     recLagfarenAegare_Adress, strOTYP, strDATUMLOP, strFNRID, strDBNRID, strFANG, strFANGDATUM, intKOPSUM, strKOPTYP, strINSKDATUM, 
                      strANDEL, strPERSONNR, strNAMN, strTNMARK, strFNAMN, strMNAMN, strENAMN, strKORTNAMN, strFAL_CO, strFAL_UTADR1, strFAL_UTADR2, 
                      strFAL_POSTNR, strFAL_POSTORT, strSAL_CO, strSAL_UTADR1, strSAL_UTADR2, strSAL_POSTNR, strSAL_POSTORT, strUA_UTADR1, strUA_UTADR2, 
                      strUA_UTADR3, strUA_UTADR4, strUA_LAND, strLAGFANM, guidUUID, strORGADR_CO, strORGUTAADR1, strORGUTAADR2, strORGPOSTNR, 
                      strORGPOSTORT, strORGLAND, strCO, strAdress, strAdress1, strPOSTNR, strPOSTORT, strLand, strLANKOD, strKOMKOD, strKOMMUN, 
                      recLagfarenAegare_Adress AS intRecnum
FROM         dbo.tbFasLagfarenAegare_Adress

go

