

CREATE VIEW [dbo].[vwMhPersonOrgan]
AS
SELECT		dbo.tbMhPersonOrgan.recPersonOrganID,
			dbo.tbMhPersonOrgan.recPersonID,
			dbo.vwMhPerson.strNamn,
			dbo.tbMhPersonOrgan.recOrganID,
            dbo.vwMhOrgan.strOrgannamn, dbo.tbMhPersonOrgan.strUppdrag, dbo.tbMhPersonOrgan.recErsaettareID, vwMhPerson_1.strNamn AS strErsaettare,
                      dbo.tbMhPersonOrgan.datStart, dbo.tbMhPersonOrgan.datSlut, dbo.tbMhPersonOrgan.strAnteckning, dbo.tbMhPersonOrgan.strStandardMoetesRoll,
                      dbo.tbMhPersonOrgan.recPersonOrganID AS intRecnum, dbo.vwMhPerson.strPartifoerkortning, dbo.vwMhPerson.strPartinamn,
                      vwMhPerson_1.strPartifoerkortning AS strErsaettarePartifoerkortning, vwMhPerson_1.strPartinamn AS strErsaettarePartinamn,
                      dbo.vwMhPerson.bolEjAktuell, dbo.vwMhPerson.strEfternamn,
 vwMhPerson_1.strNamn + ' (' + vwMhPerson_1.strPartifoerkortning + ') ' As strErsaettareNameOchPartifoerkortning
FROM         dbo.tbMhPersonOrgan LEFT OUTER JOIN
                      dbo.vwMhPerson AS vwMhPerson_1 ON dbo.tbMhPersonOrgan.recErsaettareId = vwMhPerson_1.recPersonID LEFT OUTER JOIN
                      dbo.vwMhPerson ON dbo.tbMhPersonOrgan.recPersonID = dbo.vwMhPerson.recPersonID LEFT OUTER JOIN
                      dbo.vwMhOrgan ON dbo.tbMhPersonOrgan.recOrganID = dbo.vwMhOrgan.recOrganID
go

