


CREATE VIEW [dbo].[vwVisFrasregisterRegister]
AS

SELECT			recFrasregisterRegisterID,
				recFrasregisterID,
				strRegister
FROM			tbVisFrasregisterRegister


go

