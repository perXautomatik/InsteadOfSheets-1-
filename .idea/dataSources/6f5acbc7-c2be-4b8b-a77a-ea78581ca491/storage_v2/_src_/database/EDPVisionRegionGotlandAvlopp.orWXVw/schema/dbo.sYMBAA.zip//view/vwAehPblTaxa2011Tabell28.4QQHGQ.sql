
CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell28]
AS
SELECT     

recTabell28ID, 
recTaxa2011ID, 
recTabell28ID as 'intRecnum', 
dbo.tbAehPblTaxa2011Tabell28.recTjaenstID,
dbo.tbAehPblTaxa2011Tabell28.recFakturatextID,
strFritext,
decMoms,
	dbo.tbVisTjaenst.strTjaenstKod,
	dbo.tbVisTjaenst.strTjaenst,
	dbo.tbVisFakturatext.strFakturatextkod
	
FROM dbo.tbAehPblTaxa2011Tabell28

	LEFT OUTER JOIN dbo.tbVisFakturatext
	ON dbo.tbVisFakturatext.recFakturatextID = dbo.tbAehPblTaxa2011Tabell28.recFakturatextID
	
	LEFT OUTER JOIN dbo.tbVisTjaenst
	ON dbo.tbVisTjaenst.recTjaenstID = dbo.tbAehPblTaxa2011Tabell28.recTjaenstID


go

