
        create function [dbo].[_rowtext_tnm] (
  @parname varchar(200),
  @defaultval varchar(200),
  @val varchar(200)
)
returns varchar(300)
as
begin
  declare @strRet varchar(300)
  if len(@val) > 0 and @val not like '%[^0-9]%'
    set @strRet = dbo._rowtext_num(@parname, @defaultval, @val)
  else
    set @strRet = dbo._rowtext_txt(@parname, @defaultval, @val)
  return @strRet
end
        go

