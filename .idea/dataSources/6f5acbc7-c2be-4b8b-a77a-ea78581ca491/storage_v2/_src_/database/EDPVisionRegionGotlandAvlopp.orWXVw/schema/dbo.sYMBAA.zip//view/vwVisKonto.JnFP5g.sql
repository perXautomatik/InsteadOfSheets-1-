
CREATE VIEW [dbo].[vwVisKonto]
AS
SELECT    dbo.tbVisKonto.recKontoID
		, dbo.tbVisKonto.recKontoID AS intRecnum
		, dbo.tbVisKonto.strKontokod
		, dbo.tbVisKonto.strKontotext
		, dbo.tbVisKonto.strBeskrivning
		, dbo.tbVisKonto.recFoervaltningID
		, dbo.tbVisKonto.recAvdelningID
		, dbo.tbVisKonto.recEnhetID
		, dbo.tbVisKonto.bolEjAktuell
		, dbo.tbVisEnhet.strEnhetKod
		, dbo.tbVisEnhet.strEnhetNamn
		, dbo.tbVisAvdelning.strAvdelningKod
		, dbo.tbVisAvdelning.strAvdelningNamn
		, dbo.tbVisFoervaltning.strFoervaltningKod
		, dbo.tbVisFoervaltning.strFoervaltningNamn
		, dbo.tbVisKonto.strKontoStraeng
FROM dbo.tbVisKonto 
LEFT OUTER JOIN dbo.tbVisEnhet ON dbo.tbVisKonto.recEnhetID = dbo.tbVisEnhet.recEnhetID 
LEFT OUTER JOIN dbo.tbVisAvdelning ON dbo.tbVisKonto.recAvdelningID = dbo.tbVisAvdelning.recAvdelningID 
LEFT OUTER JOIN dbo.tbVisFoervaltning ON dbo.tbVisKonto.recFoervaltningID = dbo.tbVisFoervaltning.recFoervaltningID

go

