



CREATE VIEW [dbo].[vwTrSakkunnigCertifieringLookUp]
AS
SELECT    DISTINCT dbo.tbTrSakkunnig.recSakkunnigID,  dbo.tbTrSakkunnig.recSakkunnigID AS intRecnum, dbo.tbVisEnstakaKontakt.strVisasSom, dbo.tbVisEnstakaKontakt.strSammanslagenAdress, 
                      dbo.tbTrCertifiering.strCertifieringsTyp
FROM         dbo.tbTrSakkunnig INNER JOIN
                      dbo.tbTrCertifieringSakkunnig ON dbo.tbTrSakkunnig.recSakkunnigID = dbo.tbTrCertifieringSakkunnig.recSakkunnigID INNER JOIN
                      dbo.tbTrCertifiering ON dbo.tbTrCertifieringSakkunnig.recCertifieringID = dbo.tbTrCertifiering.recCertifieringID 
                    and ((dbo.tbTrCertifiering.datCertifieradFraanOchMed IS NULL OR dbo.tbTrCertifiering.datCertifieradFraanOchMed <= GETDATE()) and (dbo.tbTrCertifiering.datCertifieradTillOchMed IS NULL OR dbo.tbTrCertifiering.datCertifieradTillOchMed >= GETDATE())) 
                      INNER JOIN
                      dbo.tbVisEnstakaKontakt ON dbo.tbTrSakkunnig.recEnstakaKontaktID = dbo.tbVisEnstakaKontakt.recEnstakaKontaktID

WHERE dbo.tbTrSakkunnig.bolEjAktuell = 0


go

