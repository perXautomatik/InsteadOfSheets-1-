CREATE PROCEDURE [dbo].[spEDPAddParameterDefaultValue]
	-- Add the parameters for the stored procedure here
  @intParameterID int,
  @strParameterValueDefault varchar(200)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
  
  
IF EXISTS(SELECT intParameterID FROM tbEDPParameterDefaultValue WHERE intParameterID=@intParameterID)
	BEGIN
		UPDATE tbEDPParameterDefaultValue SET
		strParameterDefaultValue=@strParameterValueDefault
		WHERE intParameterID=@intParameterID
	END

ELSE

	BEGIN  
	  INSERT INTO tbEDPParameterDefaultValue 
	  (
		  strParameterDefaultValue,
		  intParameterID
	  )
	  VALUES (
		  @strParameterValueDefault,
		  @intParameterID)
	END
END
go

