

CREATE VIEW [dbo].[vwVisRubrik]
AS
SELECT  dbo.tbVisRubrik.recRubrikID,
		dbo.tbVisRubrik.recRubrikID as intRecnum,
		dbo.tbVisRubrik.strRubrik, 
		dbo.tbVisRubrik.strKommentar,
		
			STUFF((SELECT ',' + Rubrik.strRegister 
			FROM tbVisRubrikRegister as Rubrik
				WHERE  tbVisRubrik.recRubrikID = Rubrik.recRubrikID
				FOR XML PATH('')
				), 1, 1, '') as strRegister		
		
FROM    dbo.tbVisRubrik


go

