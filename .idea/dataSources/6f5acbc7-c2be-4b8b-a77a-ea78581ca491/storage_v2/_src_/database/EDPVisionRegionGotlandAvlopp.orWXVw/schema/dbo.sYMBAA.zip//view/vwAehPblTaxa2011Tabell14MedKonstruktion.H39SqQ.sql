
CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell14MedKonstruktion]
AS
SELECT     tbAehPblTaxa2011Tabell14MedKonstruktion.recTabell14ID, 
           recMedKonstruktionID as 'intRecnum', 
	       recMedKonstruktionID,
		   strObjekt,
		   strBeskrivning, 
		   intHF, 
		   recTaxa2011ID
FROM         dbo.tbAehPblTaxa2011Tabell14MedKonstruktion
LEFT OUTER JOIN tbAehPblTaxa2011Tabell14 
ON tbAehPblTaxa2011Tabell14MedKonstruktion.recTabell14ID = tbAehPblTaxa2011Tabell14.recTabell14ID


go

