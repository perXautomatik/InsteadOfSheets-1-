CREATE VIEW dbo.vwMmFoerorening
AS
SELECT     dbo.tbMmFoerorening.recFoeroreningID, dbo.tbMmFoerorening.recOmrID, dbo.tbMmFoerorening.recMediumID,
                      dbo.tbMmFoerorening.strRegKod + '-' + LTRIM(STR(dbo.tbMmFoerorening.intFoeroreningNr)) AS strFoeroreningKod, dbo.tbMmFoerorening.strRegKod,
                      dbo.tbMmFoerorening.intFoeroreningNr, dbo.tbMmFoerorening.strKaenslighet, dbo.tbMmFoerorening.intProvantal,
                      dbo.tbMmFoerorening.intProvpunkter, dbo.tbMmFoerorening.strBeskrivning, dbo.tbMmMedium.strMediumNamn,
                      dbo.tbMmFoerorening.recFoeroreningID AS intRecnum, dbo.vwMmOmraade.strOmraadeKod, dbo.vwMmOmraade.strOmrNamn,
                      dbo.tbMmFoerorening.strFoeroreningNamn, dbo.tbMmMedium.strLocalizationCode
FROM         dbo.tbMmFoerorening LEFT OUTER JOIN
                      dbo.vwMmOmraade ON dbo.tbMmFoerorening.recOmrID = dbo.vwMmOmraade.recOmrID LEFT OUTER JOIN
                      dbo.tbMmMedium ON dbo.tbMmFoerorening.recMediumID = dbo.tbMmMedium.recMediumID
go

