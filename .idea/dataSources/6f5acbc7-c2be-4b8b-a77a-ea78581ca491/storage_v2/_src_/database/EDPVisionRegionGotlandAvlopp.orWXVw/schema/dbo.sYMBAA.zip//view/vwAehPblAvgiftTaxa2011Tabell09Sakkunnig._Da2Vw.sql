



CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell09Sakkunnig]
AS
SELECT     recAehPblAvgiftTaxa2011Tabell09SakkunnigID,recAehPblAvgiftTaxa2011Tabell09SakkunnigID as intRecnum, strAatgaerd, strBeskrivning, intHF, recAehPblAvgiftTaxa2011Tabell09ID
FROM         dbo.tbAehPblAvgiftTaxa2011Tabell09Sakkunnig

go

