CREATE VIEW dbo.vwFasPersonOrg
AS
SELECT     strORGNRID AS strPersonnr, strORGNAMN AS strORGKORTNAMN, strORGADR_CO AS strCO, strORGUTAADR2 AS strAdress, 
                      strORGUTAADR1 AS strAdress1, strPOSTNR, strPOSTORT, strLAND AS strLand
FROM         dbo.tbFasORG
UNION
SELECT     strPERSONNRID AS strPersonnr, strKORTNAMN AS strORGKORTNAMN, strFAL_CO AS strCO, strFAL_UTADR2 AS strAdress, 
                      strFAL_UTADR1 AS strAdress1, strFAL_POSTNR AS strPostNr, strFAL_POSTORT AS strPostOrt, strUA_LAND AS strLand
FROM         dbo.tbFasPERSON
go

