
CREATE VIEW [dbo].[vwTrTillsynsobjektetsFakturamottagare]
AS
SELECT tbTrTillsynsobjekt.recTillsynsobjektID,
  tbTrTillsynsobjekt.recTillsynsobjektID AS intRecnum,
  vwVisDeladFakturamottagare.recDeladFakturamottagareID, 
  vwVisDeladFakturamottagare.strFoernamn, 
  vwVisDeladFakturamottagare.strEfternamn, 
  vwVisDeladFakturamottagare.strFoeretag, 
  vwVisDeladFakturamottagare.strTitel, 
  vwVisDeladFakturamottagare.strKontaktTyp, 
  vwVisDeladFakturamottagare.strGatuadress, 
  vwVisDeladFakturamottagare.strCoadress, 
  vwVisDeladFakturamottagare.strPostnummer, 
  vwVisDeladFakturamottagare.strPostort, 
  vwVisDeladFakturamottagare.strLand, 
  LTRIM(vwVisDeladFakturamottagare.strFoernamn + ' ' + vwVisDeladFakturamottagare.strEfternamn) AS strNamn, 
  vwVisDeladFakturamottagare.strVisasSom, 
  vwVisDeladFakturamottagare.strSammanslagenAdress, 
  vwVisDeladFakturamottagare.intIdNummer, 
  vwVisDeladFakturamottagare.strExterntIdNummer, 
  vwVisDeladFakturamottagare.strMotpartKoncernkod, 
  vwVisDeladFakturamottagare.strSkanningskod, 
  vwVisDeladFakturamottagare.bolIntern, 
  vwVisDeladFakturamottagare.strGLN,
  vwVisDeladFakturamottagare.strKommun, 
  vwVisDeladFakturamottagare.strReferensnummer, 
  vwVisDeladFakturamottagare.strOrginisationPersonnummer, 
  vwVisDeladFakturamottagare.strIntBokfoeringsKonto, 
  vwVisDeladFakturamottagare.recEnstakaKontaktID,
  (SELECT REPLACE(((SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett 
    INNER JOIN tbVisEnstakaKontaktKommunikationssaett
      ON tbVisEnstakaKontaktKommunikationssaett.recKommunikationssaettID = tbVisKommunikationssaett.recKommunikationssaettID
    WHERE recEnstakaKontaktID = tbVisEnstakaKontakt.recEnstakaKontaktID 
      AND strKommunikationsaettTyp = 'E-Post'
    FOR XML PATH(''))
    + '...'), ', ...', '') 
    FROM tbVisEnstakaKontakt
    WHERE recEnstakaKontaktID = vwVisDeladFakturamottagare.recEnstakaKontaktID) AS strEpost,
  (SELECT REPLACE(((SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett 
    INNER JOIN tbVisEnstakaKontaktKommunikationssaett
      ON tbVisEnstakaKontaktKommunikationssaett.recKommunikationssaettID = tbVisKommunikationssaett.recKommunikationssaettID
    WHERE recEnstakaKontaktID = tbVisEnstakaKontakt.recEnstakaKontaktID 
      AND strKommunikationsaettTyp = 'Fax'
    FOR XML PATH(''))
    + '...'), ', ...', '') 
    FROM tbVisEnstakaKontakt
    WHERE recEnstakaKontaktID = vwVisDeladFakturamottagare.recEnstakaKontaktID) AS strFax,
  (SELECT REPLACE(((SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett 
    INNER JOIN tbVisEnstakaKontaktKommunikationssaett
      ON tbVisEnstakaKontaktKommunikationssaett.recKommunikationssaettID = tbVisKommunikationssaett.recKommunikationssaettID
    WHERE recEnstakaKontaktID = tbVisEnstakaKontakt.recEnstakaKontaktID 
      AND strKommunikationsaettTyp = 'Telefon'
    FOR XML PATH(''))
    + '...'), ', ...', '') 
    FROM tbVisEnstakaKontakt
    WHERE recEnstakaKontaktID = vwVisDeladFakturamottagare.recEnstakaKontaktID) AS strTelefon,
  (SELECT REPLACE(((SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett 
    INNER JOIN tbVisEnstakaKontaktKommunikationssaett
      ON tbVisEnstakaKontaktKommunikationssaett.recKommunikationssaettID = tbVisKommunikationssaett.recKommunikationssaettID
    WHERE recEnstakaKontaktID = tbVisEnstakaKontakt.recEnstakaKontaktID 
      AND strKommunikationsaettTyp = 'Mobil'
    FOR XML PATH(''))
    + '...'), ', ...', '') 
    FROM tbVisEnstakaKontakt
    WHERE recEnstakaKontaktID = vwVisDeladFakturamottagare.recEnstakaKontaktID) AS strMobil
FROM tbTrTillsynsobjekt
LEFT OUTER JOIN vwVisDeladFakturamottagare
  ON vwVisDeladFakturamottagare.recDeladFakturamottagareID = tbTrTillsynsobjekt.recDeladFakturamottagareID

go

