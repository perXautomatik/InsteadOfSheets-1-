CREATE VIEW dbo.vwFasINSGI
AS
SELECT     dbo.tbFasINSGI.recINSGI, dbo.tbFasINSGI.strOTYP, dbo.tbFasINSGI.strDATUMLOP, dbo.tbFasINSGI.strFNRID, dbo.tbFasINSGI.strDBNRID, 
                      dbo.tbFasINSGI.strIFNRID, dbo.tbFasINSGI.strGALLER, dbo.tbFasINSGI.strAVSER, dbo.vwFasFastighet.strKOMMUN, 
                      dbo.vwFasFastighet.strFastighetsbeteckning, dbo.tbFasINSGI.recINSGI AS intRecnum
FROM         dbo.vwFasFastighet RIGHT OUTER JOIN
                      dbo.tbFasINSGI ON dbo.vwFasFastighet.strFNRID = dbo.tbFasINSGI.strIFNRID
go

