


CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell08Planavgift]
AS
SELECT        recPblAvgiftTaxa2011Tabell08ID
			, recPblAvgiftTaxa2011Tabell08ID as 'intRecnum'
			, strObjekt
			, strBeskrivning
			, intPF
			, recPblAvgiftTaxa2011Tabell08PlanavgiftID

FROM         dbo.tbAehPblAvgiftTaxa2011Tabell08Planavgift
go

