
-- 20 kolumner

CREATE VIEW [dbo].[vwTrLiMyndighetsuppgifterPerAarUnion]
AS
SELECT recMyndighetsuppgifterPerAar2010ID AS recMyndighetsuppgifterPerAar,
		recMyndighetsuppgifterID,
		intAar,
		'tbTrLiMyndighetsuppgifterPerAar2010' AS TableName    
FROM tbTrLiMyndighetsuppgifterPerAar2010
	UNION
SELECT recMyndighetsuppgifterPerAar2014ID AS recMyndighetsuppgifterPerAar,
		recMyndighetsuppgifterID,
		intAar, 
		'tbTrLiMyndighetsuppgifterPerAar2014' AS TableName 
FROM tbTrLiMyndighetsuppgifterPerAar2014



go

