

CREATE VIEW [dbo].[vwVISFileObject]
AS
WITH FilVy 
AS (
SELECT DISTINCT 
	dbo.tbEDPFileObject.recFileObjectID,
	dbo.tbEDPFileObject.strDescription, 
	dbo.tbEDPFileObject.strFileName, 
	dbo.tbEDPFileObjectLocked.recFileObjectLockedID, 
	dbo.tbEDPFileObjectLocked.strCheckedOutFileName, 
	dbo.tbEDPFileObjectLocked.datCheckOutDateTime, 
	dbo.tbEDPFileObjectLocked.intUserID, 
	dbo.tbEDPUser.strSignature,	
	dbo.tbEDPFileVersion.strFiletype,  			
	dbo.tbEDPFileObject.recFileObjectID AS intRecnum,
	dbo.tbEDPFileVersion.intFileVersion AS intMaxFileVersion,
	dbo.tbEDPFileVersion.datFileVersionDate AS datLastFileVersionDate,
	dbo.tbEDPFileObject.bolWriteProtected,
	dbo.tbEDPFileObject.bolKanInnehaallaPersonuppgifter, 
	dbo.tbEDPFileVersion.lngFileSize,
	
	CASE 
		WHEN dbo.tbEDPFileObjectLocked.datCheckOutDateTime IS NOT NULL 
			THEN CAST(1 AS BIT) 
		ELSE
			CAST(0 AS BIT)
    END AS bolCheckedOut, 

	CASE 
		WHEN tbEDPMailTemplate.recFileObjectID IS NOT NULL 
			THEN CAST(1 AS BIT) 
		WHEN tbEDPDocumentTemplate.recFileObjectID IS NOT NULL 
			THEN CAST(1 AS BIT) 
		ELSE 
			CAST(0 AS BIT)
	END AS isTemp,
	
	CASE 
		WHEN datCheckOutDateTime IS NOT NULL 
			THEN 'Utcheckad'
		WHEN datCheckOutDateTime IS NULL 
			THEN ''
    END AS strStatus,
	
	CASE 
		WHEN dbo.tbAehArkiveringFiler.recFileObjectID IS NULL 
			THEN CAST(0 AS BIT)
		ELSE 
			CAST(1 AS BIT)
	END AS bolArkiverad
	
FROM dbo.tbEDPFileObject
  INNER JOIN dbo.tbEDPFileVersion 
    ON dbo.tbEDPFileObject.recFileObjectID = dbo.tbEDPFileVersion .recFileObjectID
    AND dbo.tbEDPFileVersion.recFileVersionID = 
      (SELECT TOP 1 recFileVersionID FROM tbEDPFileVersion
        WHERE tbEDPFileVersion.recFileObjectID = tbEDPFileObject.recFileObjectID
        ORDER BY recFileVersionID DESC)

  LEFT JOIN dbo.tbEDPFileObjectLocked ON dbo.tbEDPFileObjectLocked.recFileObjectID = dbo.tbEDPFileObject.recFileObjectID
  LEFT JOIN dbo.tbEDPUser ON dbo.tbEDPUser.intUserID = dbo.tbEDPFileObjectLocked.intUserID
  LEFT JOIN tbEDPDocumentTemplate ON tbEDPDocumentTemplate.recFileObjectID = tbEDPFileObject.recFileObjectID
  LEFT JOIN tbEDPMailTemplate  ON tbEDPMailTemplate.recFileObjectID = tbEDPFileObject.recFileObjectID
  LEFT JOIN dbo.tbVisFilmall  ON dbo.tbVisFilmall.recFileObjectID = dbo.tbEDPFileObject.recFileObjectID
  LEFT JOIN dbo.tbAehArkiveringFiler ON dbo.tbAehArkiveringFiler.recFileObjectID = dbo.tbEDPFileObject.recFileObjectID
WHERE 
	NOT EXISTS (SELECT recFileObjectID FROM dbo.tbVisFilmall WHERE dbo.tbVisFilmall.recFileObjectID = dbo.tbEDPFileObject.recFileObjectID) AND 
	NOT EXISTS (SELECT recFileObjectID FROM dbo.tbEDPDocumentTemplate WHERE dbo.tbEDPDocumentTemplate.recFileObjectID = dbo.tbEDPFileObject.recFileObjectID) AND 
	NOT EXISTS (SELECT recFileObjectID FROM dbo.tbEDPMailTemplate WHERE dbo.tbEDPMailTemplate.recFileObjectID = dbo.tbEDPFileObject.recFileObjectID)
)

SELECT 
	Filvy.recFileObjectID,
	Filvy.strDescription, 
	Filvy.strFileName, 
	Filvy.recFileObjectLockedID, 
	Filvy.strCheckedOutFileName, 
	Filvy.datCheckOutDateTime, 
	Filvy.intUserID, 
	Filvy.strSignature,	
	Filvy.strFiletype,  			
	Filvy.intRecnum,
	Filvy.intMaxFileVersion,
	Filvy.datLastFileVersionDate,
	Filvy.bolWriteProtected,
	Filvy.bolKanInnehaallaPersonuppgifter, 
	Filvy.lngFileSize,
	Filvy.bolCheckedOut, 
	Filvy.strStatus,
	Filvy.bolArkiverad, 
	Filvy.strStatus + ', ' + Filvy.strSignature + ', ' + convert(varchar(10), Filvy.datCheckOutDateTime, 20)  AS strUtcheckningStatus,
	CASE 
		WHEN FilVy.isTemp = 1
			THEN 
				CAST(1 AS BIT) 
		ELSE
			CASE 
				WHEN FilVy.recFileObjectID IS NOT NULL	
				THEN 
					CAST(1 AS BIT) 
				ELSE 
					CAST(0 AS BIT)  
			END
    END AS isTemplate
FROM FilVy

go

