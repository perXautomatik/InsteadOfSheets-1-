
CREATE VIEW [dbo].[vwTrTillsynsbesoekHuvudKontakt]
AS
SELECT
  tbTrTillsynsbesoekEnstakaKontakt.recTillsynsbesoekEnstakaKontaktID,
  tbTrTillsynsbesoekEnstakaKontakt.recTillsynsbesoekID,
  tbTrTillsynsbesoekEnstakaKontakt.strRoll,
  tbVisEnstakaKontakt.*,
  LTRIM(tbVisEnstakaKontakt.strFoernamn + ' ' + tbVisEnstakaKontakt.strEfternamn) AS strNamn,
  (SELECT REPLACE(((SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett 
    INNER JOIN tbVisEnstakaKontaktKommunikationssaett
      ON tbVisEnstakaKontaktKommunikationssaett.recKommunikationssaettID = tbVisKommunikationssaett.recKommunikationssaettID
    WHERE recEnstakaKontaktID = tbVisEnstakaKontakt.recEnstakaKontaktID 
      AND strKommunikationsaettTyp = 'E-Post'
    FOR XML PATH(''))
    + '...'), ', ...', '') 
    FROM tbVisEnstakaKontakt
    WHERE recEnstakaKontaktID = tbTrTillsynsbesoekEnstakaKontakt.recEnstakaKontaktID) AS strEpost,
  (SELECT REPLACE(((SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett 
    INNER JOIN tbVisEnstakaKontaktKommunikationssaett
      ON tbVisEnstakaKontaktKommunikationssaett.recKommunikationssaettID = tbVisKommunikationssaett.recKommunikationssaettID
    WHERE recEnstakaKontaktID = tbVisEnstakaKontakt.recEnstakaKontaktID 
      AND strKommunikationsaettTyp = 'Fax'
    FOR XML PATH(''))
    + '...'), ', ...', '') 
    FROM tbVisEnstakaKontakt
    WHERE recEnstakaKontaktID = tbTrTillsynsbesoekEnstakaKontakt.recEnstakaKontaktID) AS strFax,
  (SELECT REPLACE(((SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett 
    INNER JOIN tbVisEnstakaKontaktKommunikationssaett
      ON tbVisEnstakaKontaktKommunikationssaett.recKommunikationssaettID = tbVisKommunikationssaett.recKommunikationssaettID
    WHERE recEnstakaKontaktID = tbVisEnstakaKontakt.recEnstakaKontaktID 
      AND strKommunikationsaettTyp = 'Telefon'
    FOR XML PATH(''))
    + '...'), ', ...', '') 
    FROM tbVisEnstakaKontakt
    WHERE recEnstakaKontaktID = tbTrTillsynsbesoekEnstakaKontakt.recEnstakaKontaktID) AS strTelefon,
  (SELECT REPLACE(((SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett 
    INNER JOIN tbVisEnstakaKontaktKommunikationssaett
      ON tbVisEnstakaKontaktKommunikationssaett.recKommunikationssaettID = tbVisKommunikationssaett.recKommunikationssaettID
    WHERE recEnstakaKontaktID = tbVisEnstakaKontakt.recEnstakaKontaktID 
      AND strKommunikationsaettTyp = 'Mobil'
    FOR XML PATH(''))
    + '...'), ', ...', '') 
    FROM tbVisEnstakaKontakt
    WHERE recEnstakaKontaktID = tbTrTillsynsbesoekEnstakaKontakt.recEnstakaKontaktID) AS strMobil 
FROM tbTrTillsynsbesoekEnstakaKontakt
LEFT OUTER JOIN tbVisEnstakaKontakt
ON tbVisEnstakaKontakt.recEnstakaKontaktID = tbTrTillsynsbesoekEnstakaKontakt.recEnstakaKontaktID
WHERE tbTrTillsynsbesoekEnstakaKontakt.bolHuvudkontakt = 1

go

