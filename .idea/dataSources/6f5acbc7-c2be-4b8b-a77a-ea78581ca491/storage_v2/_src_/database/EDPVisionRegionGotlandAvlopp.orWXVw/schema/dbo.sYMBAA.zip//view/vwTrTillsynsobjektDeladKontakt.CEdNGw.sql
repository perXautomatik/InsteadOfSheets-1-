
CREATE VIEW [dbo].[vwTrTillsynsobjektDeladKontakt] 
AS
SELECT 
  recTillsynsobjektDeladKontaktID,
  recTillsynsobjektID,
  recDeladKontaktID,
  strRoll,
  bolHuvudkontaktperson,
  bolHuvudverksamhetsutoevare,
  recTillsynsobjektDeladKontaktID AS intRecnum

FROM tbTrTillsynsobjektDeladKontakt

go

