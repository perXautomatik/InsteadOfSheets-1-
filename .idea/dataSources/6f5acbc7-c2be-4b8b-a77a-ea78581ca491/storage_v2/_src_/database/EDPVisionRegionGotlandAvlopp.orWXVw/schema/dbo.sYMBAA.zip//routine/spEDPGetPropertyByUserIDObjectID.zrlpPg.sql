


CREATE PROCEDURE dbo.spEDPGetPropertyByUserIDObjectID
		@intUserID int,
		@intObjectID int
AS
	
	SELECT     tbEDPObject.strObjectName, tbEDPPropertyTemplate.strPropertyTemplateName, tbEDPProperty.strPropertyValue
	FROM         (SELECT     MIN(tbEDPRoleUser.intPriority) AS intPriority, tbEDPRoleObjectProperty.intObjectID, tbEDPPropertyTemplate.intPropertyTemplateID
	              FROM         tbEDPRoleUser INNER JOIN
	                                    tbEDPRole ON tbEDPRoleUser.intRoleID = tbEDPRole.intRoleID INNER JOIN
	                                    tbEDPRoleObjectProperty ON tbEDPRole.intRoleID = tbEDPRoleObjectProperty.intRoleID INNER JOIN
	                                    tbEDPProperty ON tbEDPRoleObjectProperty.intPropertyID = tbEDPProperty.intPropertyID INNER JOIN
	                                    tbEDPPropertyTemplate ON tbEDPProperty.intPropertyTemplateID = tbEDPPropertyTemplate.intPropertyTemplateID INNER JOIN
	                                    tbEDPObject ON tbEDPRoleObjectProperty.intObjectID = tbEDPObject.intObjectID
	              WHERE     (tbEDPRoleUser.intUserID = @intUserID) AND (tbEDPObject.intObjectID = @intObjectID)
	              GROUP BY tbEDPRoleObjectProperty.intObjectID, tbEDPPropertyTemplate.intPropertyTemplateID) HighestPriority INNER JOIN
	                      tbEDPPropertyTemplate ON HighestPriority.intPropertyTemplateID = tbEDPPropertyTemplate.intPropertyTemplateID INNER JOIN
	                      tbEDPProperty ON tbEDPPropertyTemplate.intPropertyTemplateID = tbEDPProperty.intPropertyTemplateID INNER JOIN
	                      tbEDPRoleObjectProperty ON tbEDPProperty.intPropertyID = tbEDPRoleObjectProperty.intPropertyID INNER JOIN
	                      tbEDPRoleUser ON tbEDPRoleObjectProperty.intRoleID = tbEDPRoleUser.intRoleID AND 
	                      HighestPriority.intPriority = tbEDPRoleUser.intPriority INNER JOIN
	                      tbEDPObject ON tbEDPRoleObjectProperty.intObjectID = tbEDPObject.intObjectID
	
	
	RETURN



go

