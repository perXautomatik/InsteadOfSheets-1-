

CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell4HF1]
AS
SELECT     tbAehPblTaxa2011Tabell4HF1.recTabell4ID, 
           recHF1ID as 'intRecnum',
		   recHF1ID, 
		   strAatgaerd,
		   strBeskrivning,
		   recTaxa2011ID,
		   intHF1
FROM         dbo.tbAehPblTaxa2011Tabell4HF1
LEFT OUTER JOIN vwAehPblTaxa2011Tabell4
ON vwAehPblTaxa2011Tabell4.recTabell4ID = tbAehPblTaxa2011Tabell4HF1.recTabell4ID

go

