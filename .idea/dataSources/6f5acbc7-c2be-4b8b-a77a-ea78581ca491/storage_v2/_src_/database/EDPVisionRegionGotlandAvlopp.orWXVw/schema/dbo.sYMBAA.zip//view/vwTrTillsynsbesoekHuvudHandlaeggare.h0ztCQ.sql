--SELECT * FROM vwTrTillsynsbesoekHuvudHandlaeggare

CREATE VIEW vwTrTillsynsbesoekHuvudHandlaeggare
AS
SELECT tbTrTillsynsbesoekUser.recTillsynsbesoekUserID,
  tbTrTillsynsbesoekUser.recTillsynsbesoekID,
  tbTrTillsynsbesoekUser.intUserID,
  vwVisHandlaeggareEDPUser.intRecnum,
  vwVisHandlaeggareEDPUser.strUserWindowsAccount,
  vwVisHandlaeggareEDPUser.strSignature,
  vwVisHandlaeggareEDPUser.strUserSurName,
  vwVisHandlaeggareEDPUser.strUserFirstName,
  vwVisHandlaeggareEDPUser.strFullName,
  vwVisHandlaeggareEDPUser.strEmail,
  vwVisHandlaeggareEDPUser.strTelephone,
  vwVisHandlaeggareEDPUser.strTelephone2,
  vwVisHandlaeggareEDPUser.strBefattning

FROM tbTrTillsynsbesoekUser 
LEFT OUTER JOIN vwVisHandlaeggareEDPUser
ON vwVisHandlaeggareEDPUser.intUserID = tbTrTillsynsbesoekUser.intUserID
WHERE tbTrTillsynsbesoekUser.bolHuvudhandlaeggare = 1
go

