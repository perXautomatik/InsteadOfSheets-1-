CREATE VIEW [dbo].[vwTrTillsynsobjektAvgiftskod]
AS
SELECT tbTrTillsynsobjektAvgiftskod.recTillsynsobjektAvgiftskodID
  , tbTrTillsynsobjektAvgiftskod.recTillsynsobjektAvgiftskodID AS intRecnum
  , tbTrTillsynsobjektAvgiftskod.recTillsynsobjektID
  , tbTrTillsynsobjektAvgiftskod.recAvgiftskodID 
  , tbTrTillsynsobjektAvgiftskod.decProcent 
  , tbTrTillsynsobjektAvgiftskod.bolHuvud
  , tbTrTillsynsobjektAvgiftskod.intAvgiftVidInkoppling
  , tbTrAvgiftskod.strAvgiftskod
  , tbTrAvgiftskod.strUnderrubrik
  , tbTrAvgiftskod.strHuvudrubrik
  , tbTrAvgiftskod.strBeskrivning
  , tbTrAvgiftskod.recBranschkodID
FROM tbTrTillsynsobjektAvgiftskod
INNER JOIN tbTrAvgiftskod 
ON tbTrAvgiftskod.recAvgiftskodID = tbTrTillsynsobjektAvgiftskod.recAvgiftskodID


go

