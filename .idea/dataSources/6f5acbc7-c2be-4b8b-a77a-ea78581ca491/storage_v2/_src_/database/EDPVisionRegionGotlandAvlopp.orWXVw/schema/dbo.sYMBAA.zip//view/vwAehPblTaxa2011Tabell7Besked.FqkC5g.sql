

CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell7Besked]
AS
SELECT     tbAehPblTaxa2011Tabell7Besked.recTabell7ID, 
           recBeskedID AS 'intRecnum', 
		   recBeskedID, 
		   strTypAvBesked, 
		   strBeskrivning, 
		   decAntalmPBB, 
		   recTaxa2011ID,
		   bolAnvaendN
FROM         dbo.tbAehPblTaxa2011Tabell7Besked
LEFT OUTER JOIN vwAehPblTaxa2011Tabell7
ON vwAehPblTaxa2011Tabell7.recTabell7ID = tbAehPblTaxa2011Tabell7Besked.recTabell7ID

go

