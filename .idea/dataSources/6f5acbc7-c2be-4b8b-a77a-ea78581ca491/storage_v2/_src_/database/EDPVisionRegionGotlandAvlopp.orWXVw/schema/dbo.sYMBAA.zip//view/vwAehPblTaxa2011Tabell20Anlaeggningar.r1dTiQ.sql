CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell20Anlaeggningar]
AS
SELECT recAnlaeggningarID, 
		   recAnlaeggningarID AS intRecnum,
		   tbAehPblTaxa2011Tabell20Anlaeggningar.recTabell20ID,
		   strObjekt, 
		   strBeskrivning,
		   intOF, 
		   intHF1, 
		   recTaxa2011ID,
		   intHF2
FROM dbo.tbAehPblTaxa2011Tabell20Anlaeggningar
LEFT OUTER JOIN vwAehPblTaxa2011Tabell20 
ON vwAehPblTaxa2011Tabell20.recTabell20ID = tbAehPblTaxa2011Tabell20Anlaeggningar.recTabell20ID
go

