CREATE VIEW dbo.vwMmByggnad
AS
SELECT     dbo.tbMmByggnad.recByggnadID, dbo.tbMmByggnad.recSaneringID, dbo.tbMmByggnad.strStatus, dbo.tbMmByggnad.strKommentar,
                      dbo.tbMmByggnad.strByggnadNamn, dbo.tbMmSanering.strProjektNamn, dbo.tbMmSanering.strProjektID,
                      dbo.tbMmByggnad.recByggnadID AS intRecnum, dbo.vwMmOmraade.strOmraadeKod, dbo.vwMmOmraade.strOmrNamn,
                      dbo.tbMmSanering.recOmrID
FROM         dbo.vwMmOmraade INNER JOIN
                      dbo.tbMmSanering ON dbo.vwMmOmraade.recOmrID = dbo.tbMmSanering.recOmrID RIGHT OUTER JOIN
                      dbo.tbMmByggnad ON dbo.tbMmSanering.recSaneringID = dbo.tbMmByggnad.recSaneringID
go

