


CREATE VIEW [dbo].[vwVisDeladKontaktGrid]

--Lite komplex SQL här, använder oss av två stycken common table expressions, den första 
-- 'kommunikationSaett' används tillsammans med 'LTRIM stycket' för att slå ihop alla kommunikationsätt 
-- i en kommaseparerad lista. Den andra CTE  'kommunikationSaettUtanSistaKomma' används enbart för att kunna
-- ta bort det sista kommat för kommunikationssätt..  fick inte något smartare sätt att fungera.
As
WITH kommunikationSaett AS (
  SELECT strVisasSom, strPostnummer, strGatuadress, strPostort, strOrginisationPersonnummer, strSammanslagenAdress, strKommunikationsaettTyp, strVaerde, tbVisDeladKontakt.recDeladKontaktID, tbVisDeladKontakt.recDeladKontaktID as intRecnum, strCoadress
	
  FROM tbVisDeladKontakt 
	LEFT OUTER JOIN dbo.tbVisDeladKontaktKommunikationssaett
	ON dbo.tbVisDeladKontaktKommunikationssaett.recDeladKontaktID = tbVisDeladKontakt.recDeladKontaktID
	LEFT OUTER JOIN dbo.tbVisKommunikationssaett
	ON dbo.tbVisDeladKontaktKommunikationssaett.recKommunikationssaettID = dbo.tbVisKommunikationssaett.recKommunikationssaettID
)
,
kommunikationSaettUtanSistaKomma as (SELECT strVisasSom, strPostnummer, strGatuadress, strPostort, strOrginisationPersonnummer, strSammanslagenAdress, recDeladKontaktID, strCoadress, intRecnum,
 LTRIM((SELECT ' ' + strKommunikationsaettTyp + ' - ' + strVaerde + ','
  FROM kommunikationSaett AS K2
  WHERE K2.recDeladKontaktID = K1.recDeladKontaktID
  FOR XML PATH('')))  AS strKommunikationssaett 
FROM kommunikationSaett AS K1
GROUP BY strOrginisationPersonnummer, strVisasSom, strSammanslagenAdress, recDeladKontaktID, strPostnummer, strGatuadress, strPostort, strCoadress, intRecnum
)

Select strVisasSom, strPostnummer, strGatuadress, strPostort, strOrginisationPersonnummer, strSammanslagenAdress, recDeladKontaktID, strCoadress, intRecnum,
	CASE strKommunikationssaett	 
		WHEN '' then NULL
		ELSE LEFT( strKommunikationssaett ,  LEN(strKommunikationssaett) - 1 )
	END as strKommunikationssaett
FROM kommunikationSaettUtanSistaKomma



go

