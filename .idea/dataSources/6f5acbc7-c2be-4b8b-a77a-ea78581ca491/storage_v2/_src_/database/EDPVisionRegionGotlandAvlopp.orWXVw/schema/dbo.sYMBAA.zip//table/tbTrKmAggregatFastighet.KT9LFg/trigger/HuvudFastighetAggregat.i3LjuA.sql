
        CREATE TRIGGER HuvudFastighetAggregat ON tbTrKmAggregatFastighet
        AFTER INSERT
        AS
        BEGIN
        -- SET NOCOUNT ON; added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;

        DECLARE insert_cursor CURSOR FAST_FORWARD
        FOR
        SELECT recAggregatID FROM INSERTED
        OPEN insert_cursor
        DECLARE @recAggregatID as INT
        FETCH NEXT FROM insert_cursor INTO @recAggregatID
        WHILE (@@fetch_status = 0)
        BEGIN
            IF (SELECT COUNT(recAggregatFastighetID) FROM tbTrKmAggregatFastighet WHERE recAggregatID = @recAggregatID) = 1
            UPDATE tbTrKmAggregatFastighet SET bolHuvudfastighet = 1 WHERE recAggregatID = @recAggregatID

            FETCH NEXT FROM insert_cursor INTO @recAggregatID
        END
        CLOSE insert_cursor
        DEALLOCATE insert_cursor

        END
        go

