
CREATE VIEW [dbo].[vwTrHiBesiktning]
AS

SELECT		tbTrHiBesiktning.recBesiktningID, 
			tbTrHiBesiktning.recBesiktningID AS intRecNum, 
			tbTrHiBesiktning.datBesiktningsdatum, 
			tbTrHiBesiktning.strBesiktningstyp, 
			tbTrHiBesiktning.strGodkaend, 
			tbTrHiBesiktning.datOmbesiktning, 
			tbTrHiBesiktning.recSakkunnigID,
            tbTrHiBesiktning.recHissID,

			tbTrTillsynsobjekt.recTillsynsobjektID,
			tbTrTillsynsobjekt.strObjektsNamn,

			tbTrHiHiss.strRegistreringsnummer,

			tbVisEnstakaKontakt.strVisasSom AS strBesiktningsmanVisasSom

FROM		tbTrHiBesiktning

LEFT JOIN	tbTrHiHiss
	ON		tbTrHiHiss.recHissID = tbTrHiBesiktning.recHissID

LEFT JOIN	tbTrTillsynsobjekt 
	ON		tbTrTillsynsobjekt.recTillsynsobjektID = tbTrHiHiss.recTillsynsobjektID

LEFT JOIN	tbTrSakkunnig 
	ON		tbTrSakkunnig.recSakkunnigID = tbTrHiBesiktning.recSakkunnigID

LEFT JOIN	tbVisEnstakaKontakt 
	ON		tbVisEnstakaKontakt.recEnstakaKontaktID = tbTrSakkunnig.recEnstakaKontaktID

go

