
CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell11]
AS
SELECT
  dbo.tbAehPblAvgiftTaxa2011Tabell11.recPblAvgiftTaxa2011Tabell11ID, 
  dbo.tbAehPblAvgiftTaxa2011Tabell11.recAvgiftID, 
  dbo.tbAehPblAvgiftTaxa2011Tabell11.recPblAvgiftTaxa2011Tabell11ID AS intRecnum, 
  dbo.tbAehPblAvgiftTaxa2011Tabell11.bolByggnaderOchAnlaeggningar,
  dbo.tbAehPblAvgiftTaxa2011Tabell11.bolKomplementbyggnad,
  dbo.tbAehPblAvgiftTaxa2011Tabell11.bolTidsersaettning,
  dbo.tbAehPblAvgiftTaxa2011Tabell11.bolHandlaeggningsfaktor,
  dbo.tbAehPblAvgiftTaxa2011Tabell11.bolHaemtaHf1,
  dbo.tbAehPblAvgiftTaxa2011Tabell11.bolHaemtaHf2,
  dbo.tbAehPblAvgiftTaxa2011Tabell11.decAvgift,
  dbo.tbAehPblAvgiftTaxa2011Tabell11.decHF,
  dbo.tbAehPblAvgiftTaxa2011Tabell11.decHF2,
  dbo.tbAehPblAvgiftTaxa2011Tabell11.decOF,
  dbo.tbAehPblAvgiftTaxa2011Tabell11.decmPBB,
  dbo.tbAehPblAvgiftTaxa2011Tabell11.decN,
  dbo.tbAehPblAvgiftTaxa2011Tabell11.decHF1Justering,
  dbo.tbAehPblAvgiftTaxa2011Tabell11.decHF2Justering,
  dbo.tbAehPblAvgiftTaxa2011Tabell11.decOFJustering,
  dbo.tbAehPblAvgiftTaxa2011Tabell11.bolDebiterad
FROM dbo.tbAehPblAvgiftTaxa2011Tabell11

go

