

CREATE VIEW [dbo].[vwTrChecklistamallVersion]
AS
SELECT     
recChecklistaVersionID, 
recChecklistaVersionID as intRecnum,
tbTrChecklistamallVersion.recChecklistamallID, 
strFilversion,
strNamn, 
datDatum, 
strKommentar, 
intUserID
FROM         dbo.tbTrChecklistamallVersion
LEFT OUTER JOIN dbo.tbTrChecklistamall
      ON dbo.tbTrChecklistamallVersion.recChecklistamallID = dbo.tbTrChecklistamall.recChecklistamallID


go

