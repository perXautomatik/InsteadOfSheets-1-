
CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell8Objektsfaktorer]
AS
SELECT     tbAehPblTaxa2011Tabell8Objektsfaktorer.recTabell8ID, 
           recObjektsfaktorerID as 'intRecnum', 
		   recObjektsfaktorerID, 
		   intFraanYta,
		   intTillYta, 
		   recTaxa2011ID,
			intOF
FROM         dbo.tbAehPblTaxa2011Tabell8Objektsfaktorer
LEFT OUTER JOIN vwAehPblTaxa2011Tabell8
ON vwAehPblTaxa2011Tabell8.recTabell8ID = tbAehPblTaxa2011Tabell8Objektsfaktorer.recTabell8ID

go

