

CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell25Laegeskontroll]
AS
SELECT  recPblAvgiftTaxa2011Tabell25LaegeskontrollID, 
		recPblAvgiftTaxa2011Tabell25LaegeskontrollID as 'intRecnum',
		recPblAvgiftTaxa2011Tabell25ID,
		strObjekt, 
		intMF, 
		strBeskrivning
		
FROM    dbo.tbAehPblAvgiftTaxa2011Tabell25Laegeskontroll


go

