
CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell12]
AS
SELECT     

recTabell12ID, 
recTaxa2011ID, 
recTabell12ID as 'intRecnum', 
dbo.tbAehPblTaxa2011Tabell12.recTjaenstID,
dbo.tbAehPblTaxa2011Tabell12.recFakturatextID,
strFritext,
decMoms,
	dbo.tbVisTjaenst.strTjaenstKod,
	dbo.tbVisTjaenst.strTjaenst,
	dbo.tbVisFakturatext.strFakturatextkod
	
FROM dbo.tbAehPblTaxa2011Tabell12

	LEFT OUTER JOIN dbo.tbVisFakturatext
	ON dbo.tbVisFakturatext.recFakturatextID = dbo.tbAehPblTaxa2011Tabell12.recFakturatextID
	
	LEFT OUTER JOIN dbo.tbVisTjaenst
	ON dbo.tbVisTjaenst.recTjaenstID = dbo.tbAehPblTaxa2011Tabell12.recTjaenstID


go

