
CREATE VIEW [dbo].[vwVisMeddelandemall]
AS
SELECT 
  recMeddelandemallID,
  recMeddelandemallID AS intRecnum,
	strMallnamn,
	strTjaenst,
	strRegistreringshaendelse,
	strTjaensteaktivitet,
	strRubrik,
	strText,
	bolEjAktuell,
	bolRegistreraFoervalt,
	strETjaenstnamn
FROM dbo.tbVisMeddelandemall


go

