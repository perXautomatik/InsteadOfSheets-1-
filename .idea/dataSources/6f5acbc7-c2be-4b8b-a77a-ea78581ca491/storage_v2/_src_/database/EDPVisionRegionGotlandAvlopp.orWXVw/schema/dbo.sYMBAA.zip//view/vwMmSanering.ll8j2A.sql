CREATE VIEW dbo.vwMmSanering
AS
SELECT     dbo.tbMmSanering.recSaneringID, dbo.tbMmSanering.recOmrID, dbo.tbMmSanering.strProjektNamn,
                      dbo.tbMmSanering.strRegKod + '-' + LTRIM(STR(dbo.tbMmSanering.intSaneringNr)) AS strSaneringKod, dbo.tbMmSanering.strRegKod,
                      dbo.tbMmSanering.intSaneringNr, dbo.tbMmSanering.strProjektID, dbo.tbMmSanering.datPlaneradStart, dbo.tbMmSanering.datPlaneratSlut,
                      dbo.tbMmSanering.datVerkligStart, dbo.tbMmSanering.datVerkligtSlut, dbo.tbMmSanering.strBeskrivning,
                      dbo.tbMmSanering.recSaneringID AS intRecnum, dbo.tbMmSanering.intYta, dbo.vwMmOmraade.strOmraadeKod,
                      dbo.vwMmOmraade.strOmrNamn
FROM         dbo.vwMmOmraade RIGHT OUTER JOIN
                      dbo.tbMmSanering ON dbo.vwMmOmraade.recOmrID = dbo.tbMmSanering.recOmrID
go

