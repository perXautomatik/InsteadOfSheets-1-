



CREATE VIEW [dbo].[vwVisMallkontakt]
AS

WITH KontaktKommunikationssaett AS (
SELECT recMallkontaktID, 
   
    (REPLACE( (SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett
    WHERE strKommunikationsaettTyp = 'Telefon' AND recKommunikationssaettID IN 
      (SELECT recKommunikationssaettID FROM tbVisMallkontaktKommunikationssaett 
       WHERE  dbo.tbVisMallkontakt.recMallkontaktID = dbo.tbVisMallkontaktKommunikationssaett.recMallkontaktID)
    FOR XML PATH('')) + '...', ', ...','') 
  ) AS strTelefon,

    (REPLACE( (SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett
    WHERE strKommunikationsaettTyp = 'Mobil' AND recKommunikationssaettID IN 
      (SELECT recKommunikationssaettID FROM tbVisMallkontaktKommunikationssaett 
       WHERE  dbo.tbVisMallkontakt.recMallkontaktID = dbo.tbVisMallkontaktKommunikationssaett.recMallkontaktID)
    FOR XML PATH('')) + '...', ', ...','') 
  ) AS strMobil	,

    (REPLACE( (SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett
    WHERE strKommunikationsaettTyp = 'Fax' AND recKommunikationssaettID IN 
      (SELECT recKommunikationssaettID FROM tbVisMallkontaktKommunikationssaett 
       WHERE  dbo.tbVisMallkontakt.recMallkontaktID = dbo.tbVisMallkontaktKommunikationssaett.recMallkontaktID)
    FOR XML PATH('')) + '...', ', ...','') 
  ) AS strFax,	

    (REPLACE( (SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett
    WHERE strKommunikationsaettTyp = 'E-post' AND recKommunikationssaettID IN 
      (SELECT recKommunikationssaettID FROM tbVisMallkontaktKommunikationssaett 
       WHERE  dbo.tbVisMallkontakt.recMallkontaktID = dbo.tbVisMallkontaktKommunikationssaett.recMallkontaktID)
    FOR XML PATH('')) + '...', ', ...','') 
  ) AS strEpost	


FROM tbVisMallkontakt
)


SELECT     

	dbo.tbVisMallkontakt.recMallkontaktID, 
	dbo.tbVisMallkontakt.strFoernamn, 
	dbo.tbVisMallkontakt.strEfternamn, 
	dbo.tbVisMallkontakt.strFoeretag, 
	dbo.tbVisMallkontakt.strOrginisationPersonnummer, 
	dbo.tbVisMallkontakt.strTitel, 
	dbo.tbVisMallkontakt.strKontaktTyp, 
	dbo.tbVisMallkontakt.strGatuadress, 
	dbo.tbVisMallkontakt.strCoadress, 
	dbo.tbVisMallkontakt.strPostnummer, 
	dbo.tbVisMallkontakt.strPostort, 
	dbo.tbVisMallkontakt.strLand, 
	dbo.tbVisMallkontakt.recAdressbokID, 
	dbo.tbVisMallkontakt.strVisasSom,
	dbo.tbVisMallkontakt.strSammanslagenAdress,
	dbo.tbVisMallkontakt.recMallkontaktID as intRecnum,	
	
	dbo.tbVisAdressbok.strNamn as strAdressboksnamn,
		KontaktKommunikationssaett.strTelefon,
		KontaktKommunikationssaett.strMobil,
		KontaktKommunikationssaett.strFax,
		KontaktKommunikationssaett.strEpost
FROM
	dbo.tbVisMallkontakt 

LEFT OUTER JOIN
	dbo.tbVisAdressbok 
	ON dbo.tbVisMallkontakt.recAdressbokID = dbo.tbVisAdressbok.recAdressbokID

LEFT OUTER JOIN KontaktKommunikationssaett
  ON KontaktKommunikationssaett.recMallkontaktID = tbVisMallkontakt.recMallkontaktID


go

