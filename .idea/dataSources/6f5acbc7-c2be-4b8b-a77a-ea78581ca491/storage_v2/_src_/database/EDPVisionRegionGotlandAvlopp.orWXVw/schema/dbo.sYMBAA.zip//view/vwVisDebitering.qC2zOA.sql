

CREATE VIEW [dbo].[vwVisDebitering]
AS
SELECT
	dbo.tbVisDebitering.recDebiteringID,
	dbo.tbVisDebitering.recDebiteringID AS intRecnum,

	dbo.tbVisDebitering.datUtfoerandeFraan,
	dbo.tbVisDebitering.datUtfoerandeTill,
	dbo.tbVisDebitering.strFritext,
	dbo.tbVisDebitering.decAntal,
	dbo.tbVisDebitering.decRabattProcent,
	dbo.tbVisDebitering.decMomsProcent,
	dbo.tbVisDebitering.datSkapad,
	dbo.tbVisDebitering.datGodkaend,
	dbo.tbVisDebitering.datFakturaunderlagSkapad,
	dbo.tbVisDebitering.bolFakturerasEj,
	dbo.tbVisDebitering.bolSeparatFaktura,
	dbo.tbVisDebitering.bolSkickadTillEkonomisystem,
	dbo.tbVisDebitering.decPris,
	dbo.tbVisDebitering.decSumma,
	dbo.tbVisDebitering.decMomsKr,
	dbo.tbVisDebitering.decTotal,
	dbo.tbVisDebitering.strGenereradFakturatext,
	dbo.tbVisDebitering.recAvgiftID,

	dbo.tbVisDebitering.recTillsynsobjektID,
	dbo.tbTrTillsynsobjekt.strObjektsNamn,
	ISNULL(dbo.tbTrVerksamhet.strVerksamhetNamn, '')+' / '+ISNULL(dbo.tbTrTillsynsobjekt.strObjektsNamn,'') AS strObjektsNamnKlartext,
	dbo.tbTrTillsynsobjektsTyp.strTillsynsobjektsTypNamn,

	dbo.tbVisDebitering.recAerendeID,
	dbo.tbAehAerendeData.strDiarienummer,

	dbo.tbVisDebitering.recHaendelseID,
	dbo.vwAehHaendelseidentifiering.strHaendelseIdentifiering,

	dbo.tbVisDebitering.recTjaenstID,
	dbo.tbVisTjaenst.strTjaenstKod,
	dbo.tbVisTjaenst.strTjaenst,

	dbo.tbVisKonto.recKontoID,
	dbo.tbVisKonto.strKontoStraeng,

	dbo.tbVisDebitering.recFakturatextID,
	dbo.tbVisFakturatext.strFakturatextkod,
	dbo.tbVisFakturatext.strFoerklaring,

	dbo.tbVisDebitering.intUserID,
	handlaeggare.strSignature as handlaeggareSignatur,
	(ISNULL(handlaeggare.strUserFirstname + ' ','') + handlaeggare.strUserSurName) as handlaeggareNamn,

	(select strEkonomikod from tbVisHandlaeggare where tbVisHandlaeggare.intUserID = dbo.tbVisDebitering.intUserID) as handlaeggareEkonomikod,

	dbo.tbVisDebitering.intSkapadAv,
	skapadAv.strSignature as skapadAvSignatur,
	(ISNULL(skapadAv.strUserFirstname + ' ','') + skapadAv.strUserSurName) as skapadAvNamn,

	dbo.tbVisDebitering.intGodkaendAv,
	godkaendAv.strSignature as godkaendAvSignatur,
	(ISNULL(godkaendAv.strUserFirstname + ' ','') + godkaendAv.strUserSurName) as godkaendAvNamn,

	dbo.tbVisDebitering.intFakturaunderlagSkapadAv,
	fakturaunderlagSkapadAv.strSignature as fakturaunderlagSkapadAvSignatur,
	(ISNULL(fakturaunderlagSkapadAv.strUserFirstname + ' ','') + fakturaunderlagSkapadAv.strUserSurName) as fakturaunderlagSkapadAvNamn,

	dbo.tbVisDebitering.recFakturaUnderlagID,
	dbo.tbVisFakturaUnderlag.intFakturaNr,

	dbo.tbVisDebitering.recAvdelningID,
	dbo.tbVisAvdelning.strAvdelningKod,
	dbo.tbVisAvdelning.strAvdelningNamn,

	dbo.tbVisDebitering.recFoervaltningID,
	dbo.tbVisFoervaltning.strFoervaltningKod,
	dbo.tbVisFoervaltning.strFoervaltningNamn,

	dbo.tbVisDebitering.recEnhetID,
	dbo.tbVisEnhet.strEnhetKod,
	dbo.tbVisEnhet.strEnhetNamn,

	dbo.tbVisDebitering.recFastighetID,
	dbo.tbVisEnstakaFastighet.strFastighetsbeteckning,

	dbo.tbVisDebitering.recEnstakaFakturamottagareID,

	dbo.tbVisDebitering.strFakturamottagareInkoppladVia,

    debiteringFakturamottagare.strMotpartKoncernkod,

    CAST(
		(
			CASE
				WHEN intGodkaendAv IS NULL THEN 0
				ELSE 1
			END
		)
		AS BIT
	) AS bolGodkaend,

	CAST(
		(
			CASE
				WHEN intFakturaunderlagSkapadAv IS NULL THEN 0
				ELSE 1
			END
		)
		AS BIT
	) AS bolFakturerad,

	CASE dbo.tbVisDebitering.strFakturamottagareInkoppladVia
		WHEN 'Ärende' THEN
			aerendeFakturamottagare.intIdNummer
		WHEN 'Debitering' THEN
			debiteringFakturamottagare.intIdNummer
		WHEN 'Tillsynsobjekt' THEN
			tillsynsobjektFakturamottagare.intIdNummer
	END as fakturamottagareKundnummer,

	CASE dbo.tbVisDebitering.strFakturamottagareInkoppladVia
		WHEN 'Ärende' THEN
			aerendeEnstakaFakturaKontakt.strVisasSom
		WHEN 'Debitering' THEN
			debiteringEnstakaFakturaKontakt.strVisasSom
		WHEN 'Tillsynsobjekt' THEN
			tillsynsobjektDeladFakturaKontakt.strVisasSom
	END as fakturamottagareNamn,

	CASE dbo.tbVisDebitering.strFakturamottagareInkoppladVia
		WHEN 'Ärende' THEN
			aerendeEnstakaFakturaKontakt.strGatuadress
		WHEN 'Debitering' THEN
			debiteringEnstakaFakturaKontakt.strGatuadress
		WHEN 'Tillsynsobjekt' THEN
			tillsynsobjektDeladFakturaKontakt.strGatuadress
	END as fakturamottagareGatuAdress,

	CASE dbo.tbVisDebitering.strFakturamottagareInkoppladVia
		WHEN 'Ärende' THEN
			aerendeEnstakaFakturaKontakt.strPostnummer
		WHEN 'Debitering' THEN
			debiteringEnstakaFakturaKontakt.strPostnummer
		WHEN 'Tillsynsobjekt' THEN
			tillsynsobjektDeladFakturaKontakt.strPostnummer
	END as fakturamottagarePostnummer,

	CASE dbo.tbVisDebitering.strFakturamottagareInkoppladVia
		WHEN 'Ärende' THEN
			aerendeEnstakaFakturaKontakt.strPostort
		WHEN 'Debitering' THEN
			debiteringEnstakaFakturaKontakt.strPostort
		WHEN 'Tillsynsobjekt' THEN
			tillsynsobjektDeladFakturaKontakt.strPostort
	END as fakturamottagarePostort,

	CASE dbo.tbVisDebitering.strFakturamottagareInkoppladVia
		WHEN 'Ärende' THEN
			aerendeEnstakaFakturaKontakt.strOrginisationPersonnummer
		WHEN 'Debitering' THEN
			debiteringEnstakaFakturaKontakt.strOrginisationPersonnummer
		WHEN 'Tillsynsobjekt' THEN
			tillsynsobjektDeladFakturaKontakt.strOrginisationPersonnummer
	END as fakturamottagareOrginisationPersonnummer,

	CASE dbo.tbVisDebitering.strFakturamottagareInkoppladVia
		WHEN 'Ärende' THEN
			aerendeEnstakaFakturaKontakt.strCoadress
		WHEN 'Debitering' THEN
			debiteringEnstakaFakturaKontakt.strCoadress
		WHEN 'Tillsynsobjekt' THEN
			tillsynsobjektDeladFakturaKontakt.strCoadress
	END as fakturamottagareCoadress,

	CASE dbo.tbVisDebitering.strFakturamottagareInkoppladVia
		WHEN 'Ärende' THEN
			aerendeEnstakaFakturaKontakt.strLand
		WHEN 'Debitering' THEN
			debiteringEnstakaFakturaKontakt.strLand
		WHEN 'Tillsynsobjekt' THEN
			tillsynsobjektDeladFakturaKontakt.strLand
	END as fakturamottagareLand,

	CASE dbo.tbVisDebitering.strFakturamottagareInkoppladVia
		WHEN 'Ärende' THEN
			aerendeFakturamottagare.bolIntern
		WHEN 'Debitering' THEN
			debiteringFakturamottagare.bolIntern
		WHEN 'Tillsynsobjekt' THEN
			tillsynsobjektFakturamottagare.bolIntern
	END as fakturamottagareIntern,

	CASE dbo.tbVisDebitering.strFakturamottagareInkoppladVia
		WHEN 'Ärende' THEN
			aerendeFakturamottagare.strKommun
		WHEN 'Debitering' THEN
			debiteringFakturamottagare.strKommun
		WHEN 'Tillsynsobjekt' THEN
			tillsynsobjektFakturamottagare.strKommun
	END as fakturamottagareKommun,

	CASE dbo.tbVisDebitering.strFakturamottagareInkoppladVia
		WHEN 'Ärende' THEN
			aerendeFakturamottagare.recEnstakaFakturaMottagareID
		WHEN 'Debitering' THEN
			debiteringFakturamottagare.recEnstakaFakturaMottagareID
		WHEN 'Tillsynsobjekt' THEN
			tillsynsobjektFakturamottagare.recDeladFakturaMottagareID
	END as fakturaMottagareID,

	CASE
		WHEN (dbo.tbVisDebitering.recAerendeID IS NOT NULL)
		THEN
			dbo.tbAehAerendeData.strDiarienummer + '/' + REPLACE(CONVERT(VARCHAR,dbo.tbVisDebitering.datSkapad, 102), '.', '-')
		WHEN (dbo.tbVisDebitering.recTillsynsobjektID IS NOT NULL)
		THEN
			CAST(dbo.tbVisDebitering.recTillsynsobjektID AS NVARCHAR(10)) + '/' + REPLACE(CONVERT(VARCHAR,dbo.tbVisDebitering.datSkapad, 102), '.', '-')
		ELSE
			REPLACE(CONVERT(VARCHAR,dbo.tbVisDebitering.datSkapad, 102), '.', '-')
	END AS strUFIC

FROM dbo.tbVisDebitering

LEFT OUTER JOIN dbo.tbTrTillsynsobjekt
	ON dbo.tbTrTillsynsobjekt.recTillsynsobjektID = dbo.tbVisDebitering.recTillsynsobjektID
LEFT OUTER JOIN dbo.tbTrTillsynsobjektsTyp
	ON dbo.tbTrTillsynsobjektsTyp.recTillsynsobjektTypID = dbo.tbTrTillsynsobjekt.recTillsynsobjektTypID

LEFT OUTER JOIN dbo.tbAehAerende
	ON dbo.tbAehAerende.recAerendeID = dbo.tbVisDebitering.recAerendeID
LEFT OUTER JOIN dbo.tbAehAerendeData
	ON dbo.tbAehAerendeData.recAerendeID = dbo.tbVisDebitering.recAerendeID

LEFT OUTER JOIN dbo.tbVisTjaenst
	ON dbo.tbVisTjaenst.recTjaenstID = dbo.tbVisDebitering.recTjaenstID
LEFT OUTER JOIN dbo.tbVisKonto
	ON dbo.tbVisKonto.recKontoID = dbo.tbVisTjaenst.recKontoID

LEFT OUTER JOIN tbVisFakturatext
	ON tbVisFakturatext.recFakturatextID = dbo.tbVisDebitering.recFakturatextID

LEFT OUTER JOIN tbEDPUser as skapadAv
	ON skapadAv.intUserID = dbo.tbVisDebitering.intSkapadAv

LEFT OUTER JOIN tbEDPUser as godkaendAv
	ON godkaendAv.intUserID = dbo.tbVisDebitering.intGodkaendAv

LEFT OUTER JOIN tbEDPUser as fakturaunderlagSkapadAv
	ON fakturaunderlagSkapadAv.intUserID = dbo.tbVisDebitering.intFakturaunderlagSkapadAv

LEFT OUTER JOIN dbo.tbVisFakturaUnderlag
	ON dbo.tbVisFakturaUnderlag.recFakturaUnderlagID = dbo.tbVisDebitering.recFakturaUnderlagID

LEFT OUTER JOIN tbEDPUser as handlaeggare
	ON handlaeggare.intUserID = dbo.tbVisDebitering.intUserID

LEFT OUTER JOIN dbo.tbVisAvdelning
	ON dbo.tbVisAvdelning.recAvdelningID = dbo.tbVisDebitering.recAvdelningID

LEFT OUTER JOIN dbo.tbVisEnhet
	ON dbo.tbVisEnhet.recEnhetID = dbo.tbVisDebitering.recEnhetID

LEFT OUTER JOIN dbo.tbVisFoervaltning
	ON dbo.tbVisFoervaltning.recFoervaltningID = dbo.tbVisDebitering.recFoervaltningID

LEFT OUTER JOIN dbo.tbVisEnstakaFakturamottagare as debiteringFakturamottagare
	ON debiteringFakturamottagare.recEnstakaFakturamottagareID = dbo.tbVisDebitering.recEnstakaFakturamottagareID
LEFt OUTER JOIN dbo.tbVisEnstakaKontakt as debiteringEnstakaFakturaKontakt
	ON debiteringEnstakaFakturaKontakt.recEnstakaKontaktID = debiteringFakturamottagare.recEnstakaKontaktID

LEFT OUTER JOIN dbo.tbVisEnstakaFakturamottagare as aerendeFakturamottagare
	ON aerendeFakturamottagare.recEnstakaFakturamottagareID = dbo.tbAehAerende.recEnstakaFakturamottagareID
LEFT OUTER JOIN dbo.tbVisEnstakaKontakt as aerendeEnstakaFakturaKontakt
	ON aerendeEnstakaFakturaKontakt.recEnstakaKontaktID = aerendeFakturamottagare.recEnstakaKontaktID

LEFT OUTER JOIN dbo.tbVisDeladFakturamottagare as tillsynsobjektFakturamottagare
	ON tillsynsobjektFakturamottagare.recDeladFakturamottagareID = dbo.tbTrTillsynsobjekt.recDeladFakturamottagareID
LEFT OUTER JOIN dbo.tbVisEnstakaKontakt as tillsynsobjektDeladFakturaKontakt
	ON tillsynsobjektDeladFakturaKontakt.recEnstakaKontaktID = tillsynsobjektFakturamottagare.recEnstakaKontaktID

LEFT OUTER JOIN dbo.tbVisEnstakaFastighet
	ON dbo.tbVisEnstakaFastighet.recFastighetID = dbo.tbVisDebitering.recFastighetID

LEFT OUTER JOIN	dbo.tbTrVerksamhet
	ON	dbo.tbTrVerksamhet.recVerksamhetID = dbo.tbTrTillsynsobjekt.recVerksamhetID

LEFT OUTER JOIN dbo.vwAehHaendelseidentifiering
  ON dbo.vwAehHaendelseidentifiering.recHaendelseID = tbVisDebitering.recHaendelseID
go

