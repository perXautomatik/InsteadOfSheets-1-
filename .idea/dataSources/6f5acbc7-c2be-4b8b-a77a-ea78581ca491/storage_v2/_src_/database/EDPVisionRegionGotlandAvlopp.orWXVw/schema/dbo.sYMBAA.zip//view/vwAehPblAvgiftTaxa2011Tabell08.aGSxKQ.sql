
CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell08]
AS
SELECT
  dbo.tbAehPblAvgiftTaxa2011Tabell08.recPblAvgiftTaxa2011Tabell08ID,
  dbo.tbAehPblAvgiftTaxa2011Tabell08.recPblAvgiftTaxa2011Tabell08ID AS intRecnum,
  dbo.tbAehPblAvgiftTaxa2011Tabell08.decAvgift,
  dbo.tbAehPblAvgiftTaxa2011Tabell08.decAvgiftOberoende,
  dbo.tbAehPblAvgiftTaxa2011Tabell08.decAvgiftTotalt,
  dbo.tbAehPblAvgiftTaxa2011Tabell08.bolPlanavgift,
  dbo.tbAehPblAvgiftTaxa2011Tabell08.bolPlanavgiftOberoende,
  dbo.tbAehPblAvgiftTaxa2011Tabell08.decPF,
  dbo.tbAehPblAvgiftTaxa2011Tabell08.decOF,
  dbo.tbAehPblAvgiftTaxa2011Tabell08.decPFOberoende,
  dbo.tbAehPblAvgiftTaxa2011Tabell08.decmPBB,
  dbo.tbAehPblAvgiftTaxa2011Tabell08.decN,
  dbo.tbAehPblAvgiftTaxa2011Tabell08.bolDebiterad,
  dbo.tbAehPblAvgiftTaxa2011Tabell08.strFoerskottsavgift,
  dbo.tbAehPblAvgiftTaxa2011Tabell08.intFoerskottsprocent,
  dbo.tbAehPblAvgiftTaxa2011Tabell08.recAvgiftID
FROM dbo.tbAehPblAvgiftTaxa2011Tabell08

go

