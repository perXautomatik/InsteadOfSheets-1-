



CREATE VIEW [dbo].[vwTrFtFolkoel]
AS
SELECT       recFolkoelID
			,recFolkoelID as intRecnum
			,recTillsynsobjektID
			,bolDetaljhandel
			,bolServering
			,datAnmaelningsdatum
			,datFoersaeljningsstart
			,datFoersaeljningUpphoert
			,bolFolkoelsobjekt
			,
			
			CASE 
				WHEN (SELECT TOP(1) strHuvudflik FROM tbTrTillsynsobjektHuvudflik 
						WHERE recTillsynsobjektID  = dbo.tbTrFtFolkoel.recTillsynsobjektID 
						ORDER BY recTillsynsobjektHuvudflikID ASC) = 'TRFolkoel' THEN 
					CAST(1 as bit)
				ELSE 
					CAST(0 as bit)
			END AS bolHuvudflik			
			
			
FROM            dbo.tbTrFtFolkoel



go

