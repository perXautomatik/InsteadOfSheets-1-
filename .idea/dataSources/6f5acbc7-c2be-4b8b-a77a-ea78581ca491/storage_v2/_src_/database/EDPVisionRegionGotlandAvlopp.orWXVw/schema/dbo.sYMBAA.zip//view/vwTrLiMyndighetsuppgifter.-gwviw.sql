




CREATE VIEW [dbo].[vwTrLiMyndighetsuppgifter]
AS
SELECT		tbTrLiMyndighetsuppgifter.recMyndighetsuppgifterID,
			tbTrLiMyndighetsuppgifter.recMyndighetsuppgifterID AS intRecNum,
			tbTrLiMyndighetsuppgifter.strEpost,
			tbTrLiMyndighetsuppgifter.strMyndighetstyp,
			tbTrLiMyndighetsuppgifter.strMyndighetsnamn,
			tbTrLiMyndighetsuppgifter.recLaenID,
			tbTrLiMyndighetsuppgifter.strMyndighetskod,
			tbTrLiMyndighetsuppgifter.strRiskklassning,
			'Vision' as strVerksamhetssystem, 
			tbVisLaen.strLaensNamn
FROM		tbTrLiMyndighetsuppgifter
LEFT JOIN	tbVisLaen ON tbVisLaen.recLaenID = tbTrLiMyndighetsuppgifter.recLaenID



go

