

CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell7]
AS
SELECT     

dbo.tbAehPblTaxa2011Tabell7.recTabell7ID, 
dbo.tbAehPblTaxa2011Tabell7.recTaxa2011ID, 
dbo.tbAehPblTaxa2011Tabell7.recTabell7ID as 'intRecnum', 
dbo.tbAehPblTaxa2011Tabell7.recTjaenstID,
dbo.tbAehPblTaxa2011Tabell7.recFakturatextID,
dbo.tbAehPblTaxa2011Tabell7.strFritext,
decMoms,
	dbo.tbVisTjaenst.strTjaenstKod,
	dbo.tbVisTjaenst.strTjaenst,
	dbo.tbVisFakturatext.strFakturatextkod
	
FROM dbo.tbAehPblTaxa2011Tabell7

	LEFT OUTER JOIN dbo.tbVisFakturatext
	ON dbo.tbVisFakturatext.recFakturatextID = dbo.tbAehPblTaxa2011Tabell7.recFakturatextID
	
	LEFT OUTER JOIN dbo.tbVisTjaenst
	ON dbo.tbVisTjaenst.recTjaenstID = dbo.tbAehPblTaxa2011Tabell7.recTjaenstID

go

