
        CREATE TRIGGER TRG_tbAehHaendelseStatusLog_INSERT_UPDATE_DELETE ON tbAehHaendelseStatusLog 
           AFTER INSERT, UPDATE, DELETE
        AS 
        BEGIN
          SET NOCOUNT ON;

          DECLARE status_cursor CURSOR FAST_FORWARD
          FOR
          SELECT recHaendelseID FROM INSERTED UNION SELECT recHaendelseID FROM DELETED
          OPEN status_cursor
          DECLARE @recHaendelseID INT
          FETCH NEXT FROM status_cursor INTO @recHaendelseID
          WHILE (@@fetch_status = 0)
          BEGIN
            EXEC spAehHaendelseUpdateStatuslog @recHaendelseID

            FETCH NEXT FROM status_cursor INTO @recHaendelseID
          END
          CLOSE status_cursor
          DEALLOCATE status_cursor
        END
        go

