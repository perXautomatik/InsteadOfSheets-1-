

CREATE VIEW [dbo].[vwTrVerksamhet]
AS
SELECT     dbo.tbTrVerksamhet.recVerksamhetID, dbo.tbTrVerksamhet.recVerksamhetID As intRecnum, dbo.tbTrVerksamhet.strVerksamhetNamn, dbo.tbTrVerksamhet.recLaenID, dbo.tbTrVerksamhet.recKommunID, 
                      dbo.tbVisLaen.strLaensNamn, dbo.tbVisLaen.strLaensKod, dbo.tbVisLaen.strLaensBokstav, dbo.tbVisKommun.strKommunNamn, 
                      dbo.tbVisKommun.strKommunKod, dbo.tbTrVerksamhet.strAnteckning, dbo.tbTrVerksamhet.strOrt,
					dbo.tbTrVerksamhet.strAdress, dbo.tbTrVerksamhet.strFnrID,dbo.tbTrVerksamhet.strPostnummer,
					dbo.vwVisDeladFastighet.strFastighetsbeteckning as strFastighetsbeteckning
FROM         dbo.tbTrVerksamhet LEFT OUTER JOIN
                      dbo.tbVisLaen ON dbo.tbTrVerksamhet.recLaenID = dbo.tbVisLaen.recLaenID LEFT OUTER JOIN
                      dbo.tbVisKommun ON dbo.tbTrVerksamhet.recKommunID = dbo.tbVisKommun.recKommunID LEFT OUTER JOIN
					 dbo.vwVisDeladFastighet ON dbo.vwVisDeladFastighet.strFnrID = dbo.tbTrVerksamhet.strFnrID


go

