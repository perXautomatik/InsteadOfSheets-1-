


CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell2Tidsersaettning]
AS
SELECT     

tbAehPblTaxa2011Tabell2Tidsersaettning.recTabell2ID, 
recTidsersaettningID as 'intRecnum', 
recTidsersaettningID,
strTabell,
strAatgaerd,
dbo.tbAehPblTaxa2011Tabell2Tidsersaettning.strBeskrivning,
intTimpris,
decmPBB,
tbAehPblTaxa2011Tabell2Tidsersaettning.strFritext,
tbAehPblTaxa2011Tabell2Tidsersaettning.decMoms,
recTaxa2011ID,
dbo.tbAehPblTaxa2011Tabell2Tidsersaettning.recTjaenstID,
dbo.tbAehPblTaxa2011Tabell2Tidsersaettning.recFakturatextID,

	dbo.tbVisTjaenst.strTjaenstKod,
	dbo.tbVisTjaenst.strTjaenst,
	dbo.tbVisFakturatext.strFakturatextkod
	
FROM dbo.tbAehPblTaxa2011Tabell2Tidsersaettning

LEFT OUTER JOIN vwAehPblTaxa2011Tabell2
ON vwAehPblTaxa2011Tabell2.recTabell2ID = tbAehPblTaxa2011Tabell2Tidsersaettning.recTabell2ID 

	LEFT OUTER JOIN dbo.tbVisFakturatext
	ON dbo.tbVisFakturatext.recFakturatextID = dbo.tbAehPblTaxa2011Tabell2Tidsersaettning.recFakturatextID
	
	LEFT OUTER JOIN dbo.tbVisTjaenst
	ON dbo.tbVisTjaenst.recTjaenstID = dbo.tbAehPblTaxa2011Tabell2Tidsersaettning.recTjaenstID



go

