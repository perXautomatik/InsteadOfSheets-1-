
CREATE PROCEDURE [dbo].[spGetHostInformation]
AS
BEGIN
DECLARE 
  @test varchar(20) ,
  @key varchar(100),
  @Domain NVARCHAR(100),
  @NUMBER_OF_PROCESSORS  varchar(20),
  @PROCESSOR_IDENTIFIER  varchar(100),
  @SystemManufacturer  varchar(20),
  @ProcessorNameString varchar (100),
  @CSDVersion varchar (50),
  @CurrentBuildNumber varchar (100),
  @ProductName varchar (100), 
  @SystemProductName varchar (100)

SELECT

@key = 'System\CurrentControlSet\Control\Session Manager\Environment'
EXEC master..xp_regread @rootkey='HKEY_LOCAL_MACHINE',
      @key=@key,@value_name='NUMBER_OF_PROCESSORS',
      @value=@NUMBER_OF_PROCESSORS 
      OUTPUT

set @key = 'SYSTEM\CurrentControlSet\services\Tcpip\Parameters'
EXEC master.dbo.xp_regread @rootkey='HKEY_LOCAL_MACHINE', 
       @key=@key,@value_name='Domain',
       @value=@Domain 
       OUTPUT

set @key = 'HARDWARE\DESCRIPTION\system\BIOS'
EXEC master..xp_regread @rootkey='HKEY_LOCAL_MACHINE',
      @key=@key,@value_name='SystemProductName',
      @value=@SystemProductName 
      OUTPUT

EXEC master..xp_regread @rootkey='HKEY_LOCAL_MACHINE',
      @key=@key,@value_name='SystemManufacturer',
      @value=@SystemManufacturer 
      OUTPUT

set @key = 'HARDWARE\DESCRIPTION\system\CentralProcessor\0'
EXEC master..xp_regread @rootkey='HKEY_LOCAL_MACHINE',
      @key=@key,@value_name='ProcessorNameString',
      @value=@ProcessorNameString 
      OUTPUT

set @key = 'SOFTWARE\Microsoft\Windows\CurrentVersion\OEMInformation'
EXEC master..xp_regread @rootkey='HKEY_LOCAL_MACHINE',
      @key=@key,@value_name='ProcessorNameString',
      @value=@ProcessorNameString 
      OUTPUT

set @key = 'SOFTWARE\Microsoft\Windows NT\CurrentVersion'
EXEC master..xp_regread @rootkey='HKEY_LOCAL_MACHINE',
      @key=@key,@value_name='CurrentBuildNumber',
      @value=@CurrentBuildNumber 
      OUTPUT

set @key = 'SOFTWARE\Microsoft\Windows NT\CurrentVersion'
EXEC master..xp_regread @rootkey='HKEY_LOCAL_MACHINE',
      @key=@key,@value_name='CSDVersion',
      @value=@CSDVersion 
      OUTPUT

set @key = 'SOFTWARE\Microsoft\Windows NT\CurrentVersion'
EXEC master..xp_regread @rootkey='HKEY_LOCAL_MACHINE',
      @key=@key,@value_name='ProductName',
      @value=@ProductName 
      OUTPUT
   
SELECT    
  CAST(Cast(SERVERPROPERTY('MachineName') as nvarchar) + '.' + @Domain AS varchar(255)) AS FQDN,
  CAST(SERVERPROPERTY('ComputerNamePhysicalNetBIOS') AS varchar(255)) AS [CurrentSQLNodeName],
  CAST(@@ServerName AS varchar(255)) as [SQL Instance Name],
  
  CASE 
  WHEN LEFT(CAST(serverproperty('productversion') as char), 1) = 8 THEN 'Microsoft SQL Server 2000'
  WHEN LEFT(CAST(serverproperty('productversion') as char), 1) = 9 THEN 'Microsoft SQL Server 2005'
  WHEN LEFT(CAST(serverproperty('productversion') as char), 2) = 10 THEN 'Microsoft SQL Server 2008'
  WHEN LEFT(CAST(serverproperty('productversion') as char), 4) = 10.50 THEN 'Microsoft SQL Server 2008 R2'
  WHEN LEFT(CAST(serverproperty('productversion') as char), 2) = 11 THEN 'Microsoft SQL Server 2012'
  WHEN LEFT(CAST(serverproperty('productversion') as char), 2) = 12 THEN 'Microsoft SQL Server 2014'
  WHEN LEFT(CAST(serverproperty('productversion') as char), 2) = 13 THEN 'Microsoft SQL Server 2016'
  END AS [SQL Server Product],

  CAST(SERVERPROPERTY ('edition') AS varchar(255)) AS [SQL Server Edition],
  CAST(SERVERPROPERTY ('productlevel') AS varchar(255)) AS [Service Pack], 
  CAST(SERVERPROPERTY('productversion') AS varchar(255)) AS [SQL Server Version],

  CAST(@ProductName AS varchar(255)) as [Operating System],
  CAST(@CSDVersion AS varchar(255)) as [OS SP Level] ,
  
  (SELECT CONVERT(date, create_date) AS InstallationDate
           FROM sys.server_principals
           WHERE sid = 0x010100000000000512000000) as [OS Installed Date],
  CAST(@CurrentBuildNumber AS varchar(255)) as OSBuildNumber,
  CAST(@SystemManufacturer AS varchar(255)) as SystemManufacturer,

  CAST(@ProcessorNameString AS varchar(255)) as [Processor Type],
  CAST(@SystemProductName AS varchar(255)) as [System Model],
  
  CAST([total_physical_memory_kb] / (1024000) AS varchar(255)) AS [Total RAM in GB],

  CAST((cpu_count / hyperthread_ratio ) AS varchar(255)) AS NumberOfPhysicalCPUs, 

           CASE
           WHEN hyperthread_ratio = cpu_count THEN cpu_count
           ELSE ( ( cpu_count - hyperthread_ratio ) / ( cpu_count / hyperthread_ratio ) )
           END AS NumberOfCoresInEachCPU, 
           CASE
           WHEN hyperthread_ratio = cpu_count THEN cpu_count
           ELSE ( cpu_count / hyperthread_ratio ) * ( ( cpu_count - hyperthread_ratio ) / ( cpu_count / hyperthread_ratio ) )
           END AS TotalNumberOfCores, 
           cpu_count AS NumberOfLogicalCPUs 

FROM
sys.dm_os_sys_memory, sys.dm_os_sys_info

END


go

