
CREATE VIEW [dbo].[vwVisMallKontaktGrid]


--Lite komplex SQL här, använder oss av två stycken common table expressions, den första 
-- 'kommunikationSaett' används tillsammans med 'LTRIM stycket' för att slå ihop alla kommunikationsätt 
-- i en kommaseparerad lista. Den andra CTE  'kommunikationSaettUtanSistaKomma' används enbart för att kunna
-- ta bort det sista kommat för kommunikationssätt..  fick inte något smartare sätt att fungera.
As
WITH kommunikationSaett AS (
  SELECT strVisasSom, strPostnummer, strGatuadress, strPostort, strOrginisationPersonnummer, 
         strSammanslagenAdress, strCoadress, strKommunikationsaettTyp, strVaerde, 
         tbVisMallKontakt.recMallKontaktID, tbVisMallKontakt.recAdressbokID,
         tbVisMallKontakt.recMallKontaktID as intRecnum
	
  FROM tbVisMallKontakt 
	LEFT OUTER JOIN dbo.tbVisMallKontaktKommunikationssaett
	ON dbo.tbVisMallKontaktKommunikationssaett.recMallKontaktID = tbVisMallKontakt.recMallKontaktID
	LEFT OUTER JOIN dbo.tbVisKommunikationssaett
	ON dbo.tbVisMallKontaktKommunikationssaett.recKommunikationssaettID = dbo.tbVisKommunikationssaett.recKommunikationssaettID
	LEFT OUTER JOIN dbo.tbVisAdressbok 
	ON dbo.tbVisMallkontakt.recAdressbokID = dbo.tbVisAdressbok.recAdressbokID

)
,
kommunikationSaettUtanSistaKomma as (SELECT strVisasSom, strPostnummer, strGatuadress, strCoadress, strPostort, strOrginisationPersonnummer, strSammanslagenAdress, recMallKontaktID, recAdressbokID,
 LTRIM((SELECT ' ' + strKommunikationsaettTyp + ' - ' + strVaerde + ',' 
  FROM kommunikationSaett AS K2
  WHERE K2.recMallKontaktID = K1.recMallKontaktID
  FOR XML PATH('')))  AS strKommunikationssaett 
FROM kommunikationSaett AS K1
GROUP BY strOrginisationPersonnummer, strVisasSom, strSammanslagenAdress, recMallKontaktID, recAdressbokID, strPostnummer, strGatuadress, strCoadress, strPostort
)
Select strVisasSom, strPostnummer, strGatuadress, strCoadress, strPostort, strOrginisationPersonnummer, strSammanslagenAdress,  recMallKontaktID, recAdressbokID,
	CASE strKommunikationssaett
		WHEN '' then NULL
		ELSE LEFT( strKommunikationssaett ,  LEN(strKommunikationssaett) - 1 )
	END as strKommunikationssaett
FROM kommunikationSaettUtanSistaKomma



go

