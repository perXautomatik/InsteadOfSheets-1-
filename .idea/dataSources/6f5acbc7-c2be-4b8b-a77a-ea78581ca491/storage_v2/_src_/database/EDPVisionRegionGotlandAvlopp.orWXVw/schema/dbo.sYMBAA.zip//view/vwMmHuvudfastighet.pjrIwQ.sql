
CREATE VIEW [dbo].[vwMmHuvudfastighet]
AS
SELECT     dbo.tbMmOmraadeDeladFastighet.recOmraadeDeladFastighetID, dbo.tbMmOmraadeDeladFastighet.recOmrID, dbo.tbMmOmraadeDeladFastighet.strFnrID,
                      dbo.tbMmOmraadeDeladFastighet.bolHuvudfastighet, dbo.tbVisDeladFastighet.strFastighetsbeteckning,
                      dbo.tbMmOmraadeDeladFastighet.recOmraadeDeladFastighetID AS intRecnum
FROM         dbo.tbMmOmraadeDeladFastighet INNER JOIN
                      dbo.tbVisDeladFastighet ON dbo.tbMmOmraadeDeladFastighet.strFnrID = dbo.tbVisDeladFastighet.strFnrID
WHERE     (dbo.tbMmOmraadeDeladFastighet.bolHuvudfastighet = 1)
go

