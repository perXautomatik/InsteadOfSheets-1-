
CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell10]
AS
SELECT 
  dbo.tbAehPblAvgiftTaxa2011Tabell10.recPblAvgiftTaxa2011Tabell10ID, 
  dbo.tbAehPblAvgiftTaxa2011Tabell10.recPblAvgiftTaxa2011Tabell10ID AS intRecnum,
  dbo.tbAehPblAvgiftTaxa2011Tabell10.decAvgift, 
  dbo.tbAehPblAvgiftTaxa2011Tabell10.intHF, 
  dbo.tbAehPblAvgiftTaxa2011Tabell10.decmPBB, 
  dbo.tbAehPblAvgiftTaxa2011Tabell10.decN, 
  dbo.tbAehPblAvgiftTaxa2011Tabell10.bolDebiterad, 
  dbo.tbAehPblAvgiftTaxa2011Tabell10.recAvgiftID
FROM dbo.tbAehPblAvgiftTaxa2011Tabell10

go

