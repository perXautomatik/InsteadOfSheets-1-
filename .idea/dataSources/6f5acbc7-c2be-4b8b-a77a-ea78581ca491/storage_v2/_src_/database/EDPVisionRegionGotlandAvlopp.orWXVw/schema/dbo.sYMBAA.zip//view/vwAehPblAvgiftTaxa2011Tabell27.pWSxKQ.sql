
CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell27]
AS
SELECT
  dbo.tbAehPblAvgiftTaxa2011Tabell27.recPblAvgiftTaxa2011Tabell27ID, 
  dbo.tbAehPblAvgiftTaxa2011Tabell27.recPblAvgiftTaxa2011Tabell27ID AS intRecnum,
  dbo.tbAehPblAvgiftTaxa2011Tabell27.recAvgiftID, 
  dbo.tbAehPblAvgiftTaxa2011Tabell27.decAvgift, 
  dbo.tbAehPblAvgiftTaxa2011Tabell27.intMF, 
  dbo.tbAehPblAvgiftTaxa2011Tabell27.decmPBB, 
  dbo.tbAehPblAvgiftTaxa2011Tabell27.decN, 
  dbo.tbAehPblAvgiftTaxa2011Tabell27.bolDebiterad
FROM dbo.tbAehPblAvgiftTaxa2011Tabell27

go

