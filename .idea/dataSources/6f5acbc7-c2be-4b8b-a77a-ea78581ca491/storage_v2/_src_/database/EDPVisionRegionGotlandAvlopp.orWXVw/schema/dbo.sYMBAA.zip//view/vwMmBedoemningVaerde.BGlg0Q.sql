CREATE VIEW dbo.vwMmBedoemningVaerde
AS
SELECT     dbo.tbMmBedoemningVaerde.recBedoemningVaerde, dbo.tbMmBedoemningVaerde.strBedoemningVaerde,
                      dbo.tbMmBedoemningVaerde.strBedoemningVaerdeFoerklaring, dbo.tbMmRiktvaerdetyp.strRiktvaerdetypNamn,
                      dbo.tbMmBedoemningVaerde.recBedoemningVaerde AS intRecnum, dbo.tbMmBedoemningVaerde.intBedoemningVaerdeFaergARGB,
                      dbo.tbMmBedoemningVaerde.guidRiktvaerdetypID, dbo.tbMmBedoemningVaerde.guidBedoemningVaerdeID
FROM         dbo.tbMmBedoemningVaerde LEFT OUTER JOIN
                      dbo.tbMmRiktvaerdetyp ON dbo.tbMmBedoemningVaerde.guidRiktvaerdetypID = dbo.tbMmRiktvaerdetyp.guidRiktvaerdetypID
go

