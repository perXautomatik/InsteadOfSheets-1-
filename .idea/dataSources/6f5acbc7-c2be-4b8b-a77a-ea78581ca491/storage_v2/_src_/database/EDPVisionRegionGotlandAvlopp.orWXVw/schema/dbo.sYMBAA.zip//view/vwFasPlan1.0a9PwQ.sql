CREATE VIEW [dbo].[vwFasPlan1]
AS
SELECT     TOP (100) PERCENT dbo.tbFasPLANBEROR.strBNKLID, dbo.tbFasFASTIGH.strKOMMUN, COUNT(*) AS Expr1, dbo.tbFasPLAN.recPLAN, 
                      dbo.tbFasPLAN.strOTYP, dbo.tbFasPLAN.strDATUMLOP, dbo.tbFasPLAN.strGRUPP, dbo.tbFasPLAN.strLMAKT, dbo.tbFasPLAN.strARKPL, 
                      dbo.tbFasPLAN.strPLNAMN, dbo.tbFasPLAN.strPLANFK, dbo.tbFasPLAN.strPSTAT, dbo.tbFasPLAN.strBDAT, dbo.tbFasPLAN.strGDATB, 
                      dbo.tbFasPLAN.strGDATU, dbo.tbFasPLAN.strGTILL, dbo.tbFasPLAN.strLDAT, dbo.tbFasPLAN.strSAJDAT, dbo.tbFasPLAN.strBMYND, 
                      dbo.tbFasPLAN.intMFLAGGA, dbo.tbFasPLAN.strONK, dbo.tbFasPLAN.strPLANANM
FROM         dbo.tbFasPLANBEROR INNER JOIN
                      dbo.tbFasFASTIGH ON dbo.tbFasPLANBEROR.strFNRID = dbo.tbFasFASTIGH.strFNRID RIGHT OUTER JOIN
                      dbo.tbFasPLAN ON dbo.tbFasPLANBEROR.strBNKLID = dbo.tbFasPLAN.strBNKLID
WHERE     (dbo.tbFasPLANBEROR.strBNKLID IN
                          (SELECT     strBNKLID
                            FROM          dbo.tbFasPLAN AS tbFasPLAN_1))
GROUP BY dbo.tbFasPLANBEROR.strBNKLID, dbo.tbFasFASTIGH.strKOMMUN, dbo.tbFasPLAN.recPLAN, dbo.tbFasPLAN.strOTYP, 
                      dbo.tbFasPLAN.strDATUMLOP, dbo.tbFasPLAN.strGRUPP, dbo.tbFasPLAN.strLMAKT, dbo.tbFasPLAN.strARKPL, dbo.tbFasPLAN.strPLNAMN, 
                      dbo.tbFasPLAN.strPLANFK, dbo.tbFasPLAN.strPSTAT, dbo.tbFasPLAN.strBDAT, dbo.tbFasPLAN.strGDATB, dbo.tbFasPLAN.strGDATU, 
                      dbo.tbFasPLAN.strGTILL, dbo.tbFasPLAN.strLDAT, dbo.tbFasPLAN.strSAJDAT, dbo.tbFasPLAN.strBMYND, dbo.tbFasPLAN.intMFLAGGA, 
                      dbo.tbFasPLAN.strONK, dbo.tbFasPLAN.strPLANANM
ORDER BY dbo.tbFasPLANBEROR.strBNKLID
go

