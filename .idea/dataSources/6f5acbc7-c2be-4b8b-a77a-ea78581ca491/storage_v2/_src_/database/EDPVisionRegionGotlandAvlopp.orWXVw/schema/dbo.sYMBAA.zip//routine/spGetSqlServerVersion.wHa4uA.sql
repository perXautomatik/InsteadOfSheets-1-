
CREATE PROCEDURE [dbo].[spGetSqlServerVersion]
AS
BEGIN

SELECT    
  CASE 
  WHEN LEFT(CAST(serverproperty('productversion') as char), 1) = 8 THEN 'Microsoft SQL Server 2000'
  WHEN LEFT(CAST(serverproperty('productversion') as char), 1) = 9 THEN 'Microsoft SQL Server 2005'
  WHEN LEFT(CAST(serverproperty('productversion') as char), 4) = 10.5 THEN 'Microsoft SQL Server 2008 R2'
  WHEN LEFT(CAST(serverproperty('productversion') as char), 2) = 10 THEN 'Microsoft SQL Server 2008'
  WHEN LEFT(CAST(serverproperty('productversion') as char), 2) = 11 THEN 'Microsoft SQL Server 2012'
  WHEN LEFT(CAST(serverproperty('productversion') as char), 2) = 12 THEN 'Microsoft SQL Server 2014'
  WHEN LEFT(CAST(serverproperty('productversion') as char), 2) = 13 THEN 'Microsoft SQL Server 2016'
  END AS [SQL Server Product]
END

go

