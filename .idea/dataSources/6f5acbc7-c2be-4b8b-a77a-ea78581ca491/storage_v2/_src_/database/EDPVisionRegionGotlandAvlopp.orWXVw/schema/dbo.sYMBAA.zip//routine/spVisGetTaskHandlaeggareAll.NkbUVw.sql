-- =============================================
-- Author:		Ola Rönnerup
-- Create date: 2009-02-24
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[spVisGetTaskHandlaeggareAll]
AS
  BEGIN
	SELECT * FROM dbo.tbEDPUser WHERE intUserID IN(SELECT intUserID FROM dbo.tbVisHandlaeggare WHERE bolHandlaeggare = 1 AND bolEjAktuell = 0)

    RETURN(0)
  END



go

