CREATE VIEW dbo.vwMmInSituOnSite
AS
SELECT     dbo.tbMmInSituOnSite.recInSituOnSiteID, dbo.tbMmInSituOnSite.recSaneringID, dbo.tbMmInSituOnSite.strMetodtyp,
                      dbo.tbMmInSituOnSite.strMetodnamn, dbo.tbMmInSituOnSite.intVolymFastMaterial, dbo.tbMmInSituOnSite.intVolymVatten,
                      dbo.tbMmSanering.strProjektNamn, dbo.vwMmOmraade.strOmrNamn, dbo.vwMmOmraade.strOmraadeKod, dbo.tbMmSanering.strProjektID,
                      dbo.tbMmInSituOnSite.recInSituOnSiteID AS intRecnum, dbo.tbMmInSituOnSite.strInSituOnSiteNamn, dbo.tbMmInSituOnSite.datVerkligtSlut,
                      dbo.tbMmInSituOnSite.datVerkligStart, dbo.tbMmSanering.recOmrID, dbo.tbMmInSituOnSite.strSaneringsTyp
FROM         dbo.tbMmSanering INNER JOIN
                      dbo.vwMmOmraade ON dbo.tbMmSanering.recOmrID = dbo.vwMmOmraade.recOmrID RIGHT OUTER JOIN
                      dbo.tbMmInSituOnSite ON dbo.tbMmSanering.recSaneringID = dbo.tbMmInSituOnSite.recSaneringID
go

