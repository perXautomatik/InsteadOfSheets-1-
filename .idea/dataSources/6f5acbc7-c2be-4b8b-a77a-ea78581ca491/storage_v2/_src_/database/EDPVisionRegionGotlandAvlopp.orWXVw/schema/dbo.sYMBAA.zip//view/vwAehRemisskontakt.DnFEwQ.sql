


CREATE VIEW [dbo].[vwAehRemisskontakt]
AS

WITH KontaktKommunikationssaett AS (
SELECT recAerendeID,
	recRemisskontaktID, 
   
    (REPLACE( (SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett
    WHERE strKommunikationsaettTyp = 'Telefon' AND tbVisKommunikationssaett.recKommunikationssaettID IN 
      (SELECT recKommunikationssaettID FROM tbVisEnstakaKontaktKommunikationssaett 
        WHERE tbAehRemisskontakt.recEnstakaKontaktID =  tbVisEnstakaKontaktKommunikationssaett.recEnstakaKontaktID
        )
    FOR XML PATH('')) + '...', ', ...','') 
  ) AS strTelefon,

  (REPLACE( (SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett
    WHERE strKommunikationsaettTyp = 'Mobil' AND tbVisKommunikationssaett.recKommunikationssaettID IN 
	  (SELECT recKommunikationssaettID FROM tbVisEnstakaKontaktKommunikationssaett 
        WHERE tbAehRemisskontakt.recEnstakaKontaktID =  tbVisEnstakaKontaktKommunikationssaett.recEnstakaKontaktID
        )
    FOR XML PATH('')) + '...', ', ...','') 
  ) AS strMobil,
  
  (REPLACE( (SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett
    WHERE strKommunikationsaettTyp = 'Fax' AND tbVisKommunikationssaett.recKommunikationssaettID IN 
      (SELECT recKommunikationssaettID FROM tbVisEnstakaKontaktKommunikationssaett 
        WHERE tbAehRemisskontakt.recEnstakaKontaktID =  tbVisEnstakaKontaktKommunikationssaett.recEnstakaKontaktID
        )
    FOR XML PATH('')) + '...', ', ...','') 
  ) AS strFax,
  
  (REPLACE( (SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett
    WHERE strKommunikationsaettTyp = 'E-post' AND tbVisKommunikationssaett.recKommunikationssaettID IN 
      (SELECT recKommunikationssaettID FROM tbVisEnstakaKontaktKommunikationssaett 
        WHERE tbAehRemisskontakt.recEnstakaKontaktID =  tbVisEnstakaKontaktKommunikationssaett.recEnstakaKontaktID
        )
    FOR XML PATH('')) + '...', ', ...','') 
  ) AS strEpost
FROM tbAehRemisskontakt
)

SELECT     

	dbo.tbAehRemisskontakt.recRemisskontaktID, 
	dbo.tbAehRemisskontakt.recRemisskontaktID AS intRecNum,
	dbo.tbAehRemisskontakt.recEnstakaKontaktID, 
	dbo.tbAehRemisskontakt.recAerendeID, 
    dbo.tbAehRemisskontakt.strRemisskontaktRoll, 
    dbo.tbAehRemisskontakt.recEnstakaFastighetID, 
    dbo.tbAehRemisskontakt.recEnstakaFastighetID as recFastighetid, --Behövs för att inte enstaka fastighets subrapport ska krascha
    
	dbo.tbVisEnstakaFastighet.strFnrID, 
	dbo.tbVisEnstakaFastighet.strTrakt, 
	dbo.tbVisEnstakaFastighet.strBlock, 
	dbo.tbVisEnstakaFastighet.strTkn, 
    dbo.tbVisEnstakaFastighet.intEnhet, 		
    dbo.tbVisEnstakaFastighet.strFastighetsbeteckning,
    dbo.tbVisEnstakaFastighet.recKommunID,
    dbo.tbVisKommun.strKommunNamn,

    dbo.tbVisEnstakaKontakt.strFoernamn, 
    dbo.tbVisEnstakaKontakt.strEfternamn, 
	dbo.tbVisEnstakaKontakt.strFoeretag, 
	dbo.tbVisEnstakaKontakt.strOrginisationPersonnummer, 
	dbo.tbVisEnstakaKontakt.strTitel,
    dbo.tbVisEnstakaKontakt.strKontaktTyp, 
	dbo.tbVisEnstakaKontakt.strGatuadress, 
	dbo.tbVisEnstakaKontakt.strCoadress, 
	dbo.tbVisEnstakaKontakt.strPostnummer, 
    dbo.tbVisEnstakaKontakt.strPostort, 
	dbo.tbVisEnstakaKontakt.strLand, 
	dbo.tbVisEnstakaKontakt.strVisasSom, 
	dbo.tbVisEnstakaKontakt.strSammanslagenAdress,
	
    dbo.tbAehAerendeData.strDiarienummer AS strAerendeDiarienummer,
	KontaktKommunikationssaett.strTelefon,
	KontaktKommunikationssaett.strMobil,
	KontaktKommunikationssaett.strFax,
	KontaktKommunikationssaett.strEpost
	
FROM dbo.tbAehRemisskontakt 

LEFT JOIN dbo.tbVisEnstakaKontakt 
	ON dbo.tbAehRemisskontakt.recEnstakaKontaktID = dbo.tbVisEnstakaKontakt.recEnstakaKontaktID

LEFT JOIN dbo.tbVisEnstakaFastighet 
	ON dbo.tbAehRemisskontakt.recEnstakaFastighetID = dbo.tbVisEnstakaFastighet.recFastighetID
	
LEFT JOIN dbo.tbVisKommun
	ON dbo.tbVisKommun.recKommunID = dbo.tbVisEnstakaFastighet.recKommunID

LEFT JOIN dbo.tbAehAerendeData
	ON dbo.tbAehRemisskontakt.recAerendeID = dbo.tbAehAerendeData.recAerendeID

LEFT OUTER JOIN KontaktKommunikationssaett
  ON KontaktKommunikationssaett.recRemisskontaktID = tbAehRemisskontakt.recRemisskontaktID

go

