
	CREATE PROCEDURE [dbo].[spEDPAddParameter]
		-- Add the parameters for the stored procedure here
		@strParameterName varchar(200),
		@strParameterDisplayName varchar(200),
		@intParameterTypeID int,
		@intParameterValueTypeID int,
		@intParentParameterID int,
		@strParameterDescription varchar(500),
		@strParameterValueLookupID varchar(50),
		@intParameterValueLength int,
		--@strParameterValueDefault varchar(200),
		@intParameterTypeDecimalCount int,
		@intParameterTypeFigureCount int,
		@bolPasswordMask bit,
		@intParameterID int output
	AS
	BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;

	IF EXISTS(SELECT strParameterName FROM tbEDPParameter WHERE strParameterName=@strParameterName)
		BEGIN
			UPDATE tbEDPParameter SET
				--strParameterValueDefault=@strParameterValueDefault,
				intParameterValueLength=@intParameterValueLength,
				strParameterValueLookupID=@strParameterValueLookupID,
				strParameterDescription=@strParameterDescription,
				strParameterName=@strParameterName, 
				strParameterDisplayName=@strParameterDisplayName,
				intParameterTypeID=@intParameterTypeID,
				intParameterValueTypeID=@intParameterValueTypeID,
				intParentParameterID=@intParentParameterID,
				intParameterTypeDecimalCount=@intParameterTypeDecimalCount,
				bolPasswordMask=@bolPasswordMask,
				intParameterTypeFigureCount=@intParameterTypeFigureCount
			WHERE strParameterName=@strParameterName
		END

	ELSE

		BEGIN
		  -- Insert statements for procedure here
		  INSERT INTO tbEDPParameter (
			  --strParameterValueDefault,
			  intParameterValueLength,
			  strParameterValueLookupID,
			  strParameterDescription,
			  strParameterName, 
				strParameterDisplayName,
			  intParameterTypeID,
			  intParameterValueTypeID,
			  intParentParameterID,
			  intParameterTypeDecimalCount,
			  bolPasswordMask,
			  intParameterTypeFigureCount )
		  VALUES (
			  --@strParameterValueDefault,
			  @intParameterValueLength,
			  @strParameterValueLookupID,
			  @strParameterDescription,
			  @strParameterName, 
			@strParameterDisplayName,
			  @intParameterTypeID,
			  @intParameterValueTypeID,
			  @intParentParameterID,
			  @intParameterTypeDecimalCount,
			  @bolPasswordMask,
			  @intParameterTypeFigureCount)
			SET @intParameterID = @@IDENTITY
		END
	END
    go

