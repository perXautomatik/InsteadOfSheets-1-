CREATE VIEW dbo.vwFasDatainlaesning
AS
SELECT     dbo.tbFasDatainlaesning.recDatainlaesningID, dbo.tbFasDatainlaesning.datDatum, dbo.tbFasDatainlaesning.strFilnamn, 
                      dbo.tbFasDatainlaesning.intLoepNr, dbo.tbFasDatainlaesning.intUserID, dbo.tbFasDatainlaesning.intAntalPoster, dbo.tbFasDatainlaesning.strFiltyp, 
                      dbo.tbFasDatainlaesning.bolGodkaend, dbo.tbFasDatainlaesning.strFoerstaRaden, dbo.tbEDPUser.strSignature, dbo.tbEDPUser.strUserFirstname, 
                      dbo.tbEDPUser.strUserSurName, dbo.tbFasDatainlaesning.recDatainlaesningID AS intRecnum, 
                      dbo.tbEDPUser.strUserFirstname + ' ' + dbo.tbEDPUser.strUserSurName AS strAnvaendare
FROM         dbo.tbFasDatainlaesning LEFT OUTER JOIN
                      dbo.tbEDPUser ON dbo.tbFasDatainlaesning.intUserID = dbo.tbEDPUser.intUserID
go

