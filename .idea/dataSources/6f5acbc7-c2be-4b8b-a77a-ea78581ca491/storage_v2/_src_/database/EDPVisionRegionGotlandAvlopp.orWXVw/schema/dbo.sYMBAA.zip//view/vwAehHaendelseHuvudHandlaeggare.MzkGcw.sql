
            CREATE VIEW [dbo].[vwAehHaendelseHuvudHandlaeggare]
            AS
            SELECT tbAehHaendelseUser.recHaendelseUserID
              ,tbAehHaendelseUser.recHaendelseID
              ,tbAehHaendelseUser.intUserID
              ,tbEDPUser.strUserWindowsAccount
              ,tbEDPUser.strUserSurName
              ,tbEDPUser.strUserFirstName
              ,tbEDPUser.strSignature
              ,tbEDPUser.strEmail
              ,tbEDPUser.strTelephone
              ,tbEDPUser.strTelephone2
              ,vwVisHandlaeggareEDPUser.bolHandlaeggare
              ,vwVisHandlaeggareEDPUser.bolEjAktuell
              ,vwVisHandlaeggareEDPUser.strBefattning
              ,dbo.FnKomplettNamn(tbEDPUser.strUserSurName, tbEDPUser.strUserFirstName) AS strKomplettNamn
              ,(SELECT TOP 1 strAvdelningNamn FROM tbVisAvdelning WHERE recAvdelningID = tbVisAvdelningUser.recAvdelningID) AS strAvdelningNamn 
            FROM  dbo.tbAehHaendelseUser 
            INNER JOIN dbo.tbEDPUser 
              ON dbo.tbAehHaendelseUser.intUserID = dbo.tbEDPUser.intUserID
            INNER JOIN dbo.vwVisHandlaeggareEDPUser 
              ON dbo.vwVisHandlaeggareEDPUser.intUserID = dbo.tbEDPUser.intUserID
            LEFT JOIN dbo.tbVisAvdelningUser
              ON dbo.tbVisAvdelningUser.intUserID = dbo.tbEDPUser.intUserID
              AND dbo.tbVisAvdelningUser.bolHuvudavdelning = 1
            WHERE tbAehHaendelseUser.bolHuvudhandlaeggare = 1
            go

