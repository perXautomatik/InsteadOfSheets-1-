
CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell14]
AS
SELECT
  dbo.tbAehPblAvgiftTaxa2011Tabell14.recPblAvgiftTaxa2011Tabell14ID,
  dbo.tbAehPblAvgiftTaxa2011Tabell14.recPblAvgiftTaxa2011Tabell14ID AS intRecnum,
  dbo.tbAehPblAvgiftTaxa2011Tabell14.recAvgiftID,
  dbo.tbAehPblAvgiftTaxa2011Tabell14.bolHaemtaHF1,
  dbo.tbAehPblAvgiftTaxa2011Tabell14.bolHaemtaHF2,
  dbo.tbAehPblAvgiftTaxa2011Tabell14.bolDebiterad,
  dbo.tbAehPblAvgiftTaxa2011Tabell14.bolTidsersaettningMedKonstruktion,
  dbo.tbAehPblAvgiftTaxa2011Tabell14.bolTidsersaettningUtanKonstruktion,
  dbo.tbAehPblAvgiftTaxa2011Tabell14.bolHandlaeggningsfaktorMedKonstruktion,
  dbo.tbAehPblAvgiftTaxa2011Tabell14.bolHandlaeggningsfaktorUtanKonstruktion,
  dbo.tbAehPblAvgiftTaxa2011Tabell14.decAvgiftUtanKonstruktion,
  dbo.tbAehPblAvgiftTaxa2011Tabell14.decAvgiftMedKonstruktion,
  dbo.tbAehPblAvgiftTaxa2011Tabell14.decOF,
  dbo.tbAehPblAvgiftTaxa2011Tabell14.intHF,
  dbo.tbAehPblAvgiftTaxa2011Tabell14.decHF1,
  dbo.tbAehPblAvgiftTaxa2011Tabell14.decHF2,
  dbo.tbAehPblAvgiftTaxa2011Tabell14.decmPBB,
  dbo.tbAehPblAvgiftTaxa2011Tabell14.decN,
  dbo.tbAehPblAvgiftTaxa2011Tabell14.decOFJustering,
  dbo.tbAehPblAvgiftTaxa2011Tabell14.decHF1Justering,
  dbo.tbAehPblAvgiftTaxa2011Tabell14.decHF2Justering,
  dbo.tbAehPblAvgiftTaxa2011Tabell14.bolMedKonstruktion,
  dbo.tbAehPblAvgiftTaxa2011Tabell14.bolUtanKonstruktion,
  dbo.tbAehPblAvgiftTaxa2011Tabell14.decAvgiftTotalt
FROM dbo.tbAehPblAvgiftTaxa2011Tabell14

go

