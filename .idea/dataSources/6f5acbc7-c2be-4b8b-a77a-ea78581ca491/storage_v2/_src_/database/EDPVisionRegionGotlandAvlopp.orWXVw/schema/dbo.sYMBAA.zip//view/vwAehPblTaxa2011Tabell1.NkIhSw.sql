
CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell1]
AS
SELECT     recTabell1ID, recTaxa2011ID, recTabell1ID as 'intRecnum'
FROM         dbo.tbAehPblTaxa2011Tabell1

go

