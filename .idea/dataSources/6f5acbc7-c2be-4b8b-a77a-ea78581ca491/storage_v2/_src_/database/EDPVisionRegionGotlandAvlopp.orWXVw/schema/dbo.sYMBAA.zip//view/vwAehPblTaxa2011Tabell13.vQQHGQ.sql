
CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell13]
AS
SELECT     

recTabell13ID, 
recTaxa2011ID, 
recTabell13ID as 'intRecnum', 
dbo.tbAehPblTaxa2011Tabell13.recTjaenstID,
dbo.tbAehPblTaxa2011Tabell13.recFakturatextID,
strFritext,
decMoms,
	dbo.tbVisTjaenst.strTjaenstKod,
	dbo.tbVisTjaenst.strTjaenst,
	dbo.tbVisFakturatext.strFakturatextkod
	
FROM dbo.tbAehPblTaxa2011Tabell13

	LEFT OUTER JOIN dbo.tbVisFakturatext
	ON dbo.tbVisFakturatext.recFakturatextID = dbo.tbAehPblTaxa2011Tabell13.recFakturatextID
	
	LEFT OUTER JOIN dbo.tbVisTjaenst
	ON dbo.tbVisTjaenst.recTjaenstID = dbo.tbAehPblTaxa2011Tabell13.recTjaenstID


go

