


CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell25Laegeskontroll]
AS
SELECT     

recLaegeskontrollID, 
tbAehPblTaxa2011Tabell25Laegeskontroll.recTabell25ID, 
recLaegeskontrollID as 'intRecnum', 
strObjekt,
strBeskrivning,
recTaxa2011ID,
intMF
	
FROM dbo.tbAehPblTaxa2011Tabell25Laegeskontroll
LEFT OUTER JOIN vwAehPblTaxa2011Tabell25 
ON vwAehPblTaxa2011Tabell25.recTabell25ID = tbAehPblTaxa2011Tabell25Laegeskontroll.recTabell25ID


go

