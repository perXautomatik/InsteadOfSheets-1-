

CREATE VIEW [dbo].[vwTrLiMyndighetsuppgifterKommun]
AS

SELECT		tbTrLiMyndighetsuppgifterKommun.recMyndighetsuppgifterKommunID,
			tbTrLiMyndighetsuppgifterKommun.recMyndighetsuppgifterKommunID AS intRecNum,
			tbTrLiMyndighetsuppgifterKommun.recMyndighetsuppgifterID,
			tbTrLiMyndighetsuppgifterKommun.recKommunID,
			tbVisKommun.strKommunNamn,
			tbVisKommun.strKommunkod
FROM		tbTrLiMyndighetsuppgifterKommun
JOIN		tbVisKommun
		ON	tbVisKommun.recKommunID = tbTrLiMyndighetsuppgifterKommun.recKommunID


go

