CREATE VIEW [dbo].[vwTrLiOeverskridande]
AS
SELECT     recOeverskridandeID, recOeverskridandeID as intRecnum, tbTrLiOeverskridande.recLivsmedelID, 
		   tbTrLiOeverskridande.strRapporteringsID, datHaendelseDatum,
           strTidsaatgaang, strParameter, strBedoemning, strOrsakOmraade, strOrsak,
		   strAatgaerderOmraade, strAatgaerder, strOevrigt, strObjektsNamn, tbTrTillsynsobjekt.recTillsynsobjektID

FROM         dbo.tbTrLiOeverskridande
LEFT OUTER JOIN dbo.tbTrLiLivsmedel
ON tbTrLiLivsmedel.recLivsmedelID = tbTrLiOeverskridande.recLivsmedelID
LEFT OUTER JOIN dbo.tbTrTillsynsobjekt
ON tbTrLiLivsmedel.recTillsynsobjektID = tbTrTillsynsobjekt.recTillsynsobjektID
go

