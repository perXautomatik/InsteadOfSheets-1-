
CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell05Justering]
AS
SELECT     recPblAvgiftTaxa2011Tabell05ID, recPblAvgiftTaxa2011Tabell05ID as 'intRecnum', recPblAvgiftTaxa2011Tabell05JusteringID,strAatgaerd,
			strBeskrivning,decOF, decHF2
FROM         dbo.tbAehPblAvgiftTaxa2011Tabell05Justering

go

