CREATE VIEW [dbo].[vwTrKmKontroll]
AS
SELECT
	dbo.tbTrKmKontroll.recKontrollID as intRecnum,
	dbo.tbTrKmKontroll.recKontrollID, 
	dbo.tbTrKmKontroll.recAggregatID, 
	dbo.tbTrKmKontroll.strKontrolltyp, 
	dbo.tbTrKmKontroll.datKontrolldatum, 
	dbo.tbTrKmKontroll.datRegistreringsdatum,
	dbo.tbTrKmKontroll.strKontrollGodkand,
	dbo.tbTrKmAggregat.strAggregatBeteckning,
	dbo.tbTrKmKontroll.recServiceFoeretagID,
	dbo.tbTrKmKontroll.recSakkunnigID,
	vwTrSakkunnig.strVisasSom as strSakkunnig,
	vwTrServiceFoeretag.strFoeretag as strFoeretag


FROM dbo.tbTrKmKontroll 

INNER JOIN dbo.tbTrKmAggregat 
	ON dbo.tbTrKmKontroll.recAggregatID = dbo.tbTrKmAggregat.recAggregatID
LEFT OUTER JOIN vwTrSakkunnig ON vwTrSakkunnig.recSakkunnigID = tbTrKmKontroll.recSakkunnigID
LEFT OUTER JOIN vwTrServiceFoeretag ON vwTrServiceFoeretag.recServiceFoeretagID = tbTrKmKontroll.recServiceFoeretagID
go

