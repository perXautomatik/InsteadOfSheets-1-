
CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell19]
AS
SELECT
  dbo.tbAehPblAvgiftTaxa2011Tabell19.recPblAvgiftTaxa2011Tabell19ID,
  dbo.tbAehPblAvgiftTaxa2011Tabell19.recPblAvgiftTaxa2011Tabell19ID AS intRecnum,
  dbo.tbAehPblAvgiftTaxa2011Tabell19.recAvgiftID,
  dbo.tbAehPblAvgiftTaxa2011Tabell19.bolHaemtaHF1,
  dbo.tbAehPblAvgiftTaxa2011Tabell19.bolHaemtaHF2,
  dbo.tbAehPblAvgiftTaxa2011Tabell19.bolDebiterad,
  dbo.tbAehPblAvgiftTaxa2011Tabell19.bolTidsersaettning,
  dbo.tbAehPblAvgiftTaxa2011Tabell19.bolHandlaeggningsfaktor,
  dbo.tbAehPblAvgiftTaxa2011Tabell19.decAvgift,
  dbo.tbAehPblAvgiftTaxa2011Tabell19.decHF1,
  dbo.tbAehPblAvgiftTaxa2011Tabell19.decHF2,
  dbo.tbAehPblAvgiftTaxa2011Tabell19.decmPBB,
  dbo.tbAehPblAvgiftTaxa2011Tabell19.decN,
  dbo.tbAehPblAvgiftTaxa2011Tabell19.decHF1Justering,
  dbo.tbAehPblAvgiftTaxa2011Tabell19.decHF2Justering
FROM dbo.tbAehPblAvgiftTaxa2011Tabell19

go

