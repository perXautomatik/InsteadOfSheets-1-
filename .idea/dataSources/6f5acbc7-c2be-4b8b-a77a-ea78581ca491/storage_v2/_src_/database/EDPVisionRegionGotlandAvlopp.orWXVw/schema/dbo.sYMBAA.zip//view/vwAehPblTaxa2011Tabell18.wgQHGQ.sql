



CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell18]
AS
SELECT     

recTabell18ID, 
recTaxa2011ID, 
recTabell18ID as 'intRecnum', 
dbo.tbAehPblTaxa2011Tabell18.recTjaenstID,
dbo.tbAehPblTaxa2011Tabell18.recFakturatextID,
strFritext,
decMoms,
	dbo.tbVisTjaenst.strTjaenstKod,
	dbo.tbVisTjaenst.strTjaenst,
	dbo.tbVisFakturatext.strFakturatextkod
	
FROM dbo.tbAehPblTaxa2011Tabell18

	LEFT OUTER JOIN dbo.tbVisFakturatext
	ON dbo.tbVisFakturatext.recFakturatextID = dbo.tbAehPblTaxa2011Tabell18.recFakturatextID
	
	LEFT OUTER JOIN dbo.tbVisTjaenst
	ON dbo.tbVisTjaenst.recTjaenstID = dbo.tbAehPblTaxa2011Tabell18.recTjaenstID



go

