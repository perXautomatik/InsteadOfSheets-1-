/****** Object:  StoredProcedure [dbo].[spEDPGetSearchMethodsWithType]    Script Date: 11/09/2006 13:17:15 ******/
CREATE PROCEDURE [dbo].[spEDPGetSearchMethodsWithType]
AS
BEGIN
	SET NOCOUNT ON;

	SELECT strSearchMethodName as ObjectName, 'SearchMethod' as ObjectTypeName, intSearchMethodID as SearchMethodID, 
    strSearchMethodDescription as SearchMethodDescription 
  FROM tbEDPSearchMethod
END
go

