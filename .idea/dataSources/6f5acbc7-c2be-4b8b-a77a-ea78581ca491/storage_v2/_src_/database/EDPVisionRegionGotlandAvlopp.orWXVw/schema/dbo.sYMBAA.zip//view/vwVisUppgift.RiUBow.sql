

CREATE VIEW [dbo].[vwVisUppgift]
AS
WITH KoppladData AS (
  SELECT 
  tbVisUppgift.recUppgiftID, 
  (REPLACE( (SELECT strDiarienummer + ', ' FROM tbAehAerendeData 
     WHERE recAerendeID IN (
     SELECT recAerendeID FROM tbAehAerendeUppgift WHERE recUppgiftID = tbVisUppgift.recUppgiftID)   
   FOR XML PATH('')) + '...', ', ...','')) AS strKoppladeAerenden, 
   
  (REPLACE( (SELECT CAST(recTillsynsobjektID AS NVARCHAR)+ ', ' FROM tbTrTillsynsobjekt
     WHERE recTillsynsobjektID IN (
     SELECT recTillsynsobjektID FROM tbTrTillsynsobjektUppgift WHERE recUppgiftID = tbVisUppgift.recUppgiftID)   
   FOR XML PATH('')) + '...', ', ...','')) AS strKoppladeTillsynsobjekt,

  (REPLACE( REPLACE( (SELECT ISNULL(strObjektsNamn + ', ', '') FROM tbTrTillsynsobjekt
     WHERE recTillsynsobjektID IN (
     SELECT recTillsynsobjektID FROM tbTrTillsynsobjektUppgift WHERE recUppgiftID = tbVisUppgift.recUppgiftID)   
   FOR XML PATH('')) + '...', ', ...',''), '...', '')) AS strKoppladeTillsynsobjektsNamn,

  (REPLACE( (SELECT CAST(recTillsynsobjektID AS NVARCHAR) + '/' + strVerksamhetNamn + ISNULL('/' + strObjektsNamn, '') + ', ' FROM vwTrTillsynsobjekt
     WHERE recTillsynsobjektID IN (
     SELECT recTillsynsobjektID FROM tbTrTillsynsobjektUppgift WHERE recUppgiftID = tbVisUppgift.recUppgiftID)   
   FOR XML PATH('')) + '...', ', ...','')) AS strKoppladeTillsynsobjektInfo,

  (REPLACE( (SELECT DISTINCT strVerksamhetNamn + ', ' FROM tbTrVerksamhet
     WHERE recVerksamhetID IN (SELECT recVerksamhetID FROM tbTrTillsynsobjekt
     WHERE recTillsynsobjektID IN (
     SELECT recTillsynsobjektID FROM tbTrTillsynsobjektUppgift WHERE recUppgiftID = tbVisUppgift.recUppgiftID))
   FOR XML PATH('')) + '...', ', ...','')) AS strKoppladeVerksamheter
  
  FROM tbVisUppgift
)
SELECT     
	
	dbo.tbVisUppgift.recUppgiftID, 
	dbo.tbVisUppgift.recUppgiftstypID, 
	dbo.tbVisUppgift.datUppgiftsdatum, 
	dbo.tbVisUppgift.intStartadAv, 
	dbo.tbVisUppgift.datStartDatum, 
	dbo.tbVisUppgift.intUtfoerdAv, 
	dbo.tbVisUppgift.datUtfoertDatum, 
	dbo.tbVisUppgift.strBeskrivning,
	dbo.tbVisUppgift.strRubrik,
	dbo.tbVisUppgift.recUppgiftID AS intRecnum,
	dbo.tbVisUppgift.recKommunID, 
	
	dbo.tbVisUppgiftstyp.strUppgiftstyp, 
	tbEDPUserHuvudhandlaeggare.intUserID AS intHuvudhandlaeggareID, 
	tbEDPUserHuvudhandlaeggare.strSignature AS strHuvudhandlaeggareSignatur, 

	dbo.FnKomplettNamn(tbEDPUserHuvudhandlaeggare.strUserSurName, 
					   tbEDPUserHuvudhandlaeggare.strUserFirstname) AS strHuvudhandlaeggareNamn, 

	tbEDPUserUtfoerdAv.strSignature AS strUtfoerdAvSignatur, 
	tbEDPUserStartadAv.strSignature AS strStartadAvSignatur,
	--Bortkommenterat för att kunna ta bort uppgifter från uppgiftswidget
	--tbEDPUserStartadAv.intUserID,

	dbo.FnKomplettNamn(tbEDPUserUtfoerdAv.strUserSurName, 
					   tbEDPUserUtfoerdAv.strUserFirstname) AS strUtfoerdAvNamn, 
	dbo.FnKomplettNamn(tbEDPUserStartadAv.strUserSurName, 
					   tbEDPUserStartadAv.strUserFirstname) AS strStartadAvNamn,
		
	dbo.tbVisEnstakaKontakt.recEnstakaKontaktID,
	dbo.tbVisEnstakaKontakt.strVisasSom,
	dbo.tbVisEnstakaKontakt.strGatuadress,
	dbo.tbVisEnstakaKontakt.strPostnummer,
	dbo.tbVisEnstakaKontakt.strPostort,

	dbo.tbVisUppgiftEnstakaKontakt.strRoll,
	dbo.tbVisUppgiftEnstakaKontakt.recUppgiftEnstakaKontaktID,
	
	dbo.tbVisKontaktRoll.recKontaktRollID,
		
	dbo.tbVisEnstakaFastighet.recFastighetID,
	dbo.tbVisEnstakaFastighet.strFastighetsbeteckning,
	
	dbo.tbVisKommun.strKommunnamn,
	
	KoppladData.strKoppladeAerenden,
	KoppladData.strKoppladeTillsynsobjekt,
	KoppladData.strKoppladeTillsynsobjektsNamn,
	KoppladData.strKoppladeTillsynsobjektInfo,
	KoppladData.strKoppladeVerksamheter
	
FROM dbo.tbVisUppgift

LEFT JOIN dbo.tbVisUppgiftstyp
ON dbo.tbVisUppgift.recUppgiftstypID = dbo.tbVisUppgiftstyp.recUppgiftstypID

LEFT JOIN dbo.tbVisUppgiftUser AS tbVisUppgiftUserHuvudHandlaeggare
ON  dbo.tbVisUppgift.recUppgiftID = tbVisUppgiftUserHuvudHandlaeggare.recUppgiftID 
AND tbVisUppgiftUserHuvudHandlaeggare.bolHuvudhandlaeggare = 1

LEFT JOIN dbo.tbEDPUser as tbEDPUserHuvudhandlaeggare
ON tbVisUppgiftUserHuvudHandlaeggare.intUserID = tbEDPUserHuvudhandlaeggare.intUserID

LEFT JOIN dbo.tbEDPUser AS tbEDPUserStartadAv 
ON dbo.tbVisUppgift.intStartadAv = tbEDPUserStartadAv.intUserID 

LEFT JOIN dbo.tbEDPUser AS tbEDPUserUtfoerdAv 
ON dbo.tbVisUppgift.intUtfoerdAv = tbEDPUserUtfoerdAv.intUserID 

LEFT OUTER JOIN dbo.tbVisUppgiftEnstakaKontakt 
ON dbo.tbVisUppgift.recUppgiftID = dbo.tbVisUppgiftEnstakaKontakt.recUppgiftID 
AND dbo.tbVisUppgiftEnstakaKontakt.bolHuvudKontakt = 1 
LEFT OUTER JOIN dbo.tbVisEnstakaKontakt 
ON dbo.tbVisEnstakaKontakt.recEnstakaKontaktID = dbo.tbVisUppgiftEnstakaKontakt.recEnstakaKontaktID 

LEFT OUTER JOIN  -- Specialhämtning för att undvika problem om de skulle råka få in flera huvudfastigheter, välj den nyaste
  ( SELECT recUppgiftID, MAX(recFastighetID) AS recFastighetID FROM tbVisUppgiftEnstakaFastighet
    WHERE bolHuvudfastighet = 1 GROUP BY recUppgiftID
  ) AS tbVisUppgiftEnstakaFastighet
  ON tbVisUppgiftEnstakaFastighet.recUppgiftID = tbVisUppgift.recUppgiftID
LEFT OUTER JOIN  tbVisEnstakaFastighet
  ON tbVisEnstakaFastighet.recFastighetID = tbVisUppgiftEnstakaFastighet.recFastighetID

LEFT OUTER JOIN dbo.tbVisKontaktRoll
	ON dbo.tbVisKontaktRoll.strRoll = dbo.tbVisUppgiftEnstakaKontakt.strRoll

LEFT OUTER JOIN KoppladData
  ON KoppladData.recUppgiftID = tbVisUppgift.recUppgiftID

LEFT JOIN dbo.tbVisKommun
  ON dbo.tbVisKommun.recKommunID = dbo.tbVisUppgift.recKommunID

go

