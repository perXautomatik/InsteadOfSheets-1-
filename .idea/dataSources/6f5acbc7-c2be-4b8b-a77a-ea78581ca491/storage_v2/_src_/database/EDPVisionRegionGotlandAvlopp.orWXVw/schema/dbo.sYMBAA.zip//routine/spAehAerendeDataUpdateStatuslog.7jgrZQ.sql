CREATE PROCEDURE [dbo].[spAehAerendeDataUpdateStatuslog]
  @recAerendeID int
AS
BEGIN
  SET NOCOUNT ON;
  
  UPDATE dbo.tbAehAerendeData SET recLastAerendeStatusLogID =
    ( SELECT TOP (1) recAerendeStatusLogID FROM 
      ( SELECT recAerendeStatusLogID, datDatum FROM tbAehAerendeStatusLog
        WHERE recAerendeStatusLogTypID IN
          ( SELECT recAerendeStatusLogTypID FROM tbAehAerendeStatusLogTyp 
            WHERE bolVisas = 1
          ) 
          AND recAerendeID = @recAerendeID
      )
      AS tbTemp
      ORDER BY datDatum DESC
    )
  WHERE recAerendeID = @recAerendeID
  
  UPDATE tbAehAerendeData SET
    datDatum = dbo.tbAehAerendeStatusLog.datDatum,
    strLogKommentar = dbo.tbAehAerendeStatusLog.strKommentar,
    strAerendeStatusPresent = dbo.tbAehAerendeStatusLogTyp.strAerendeStatusPresent,
    strLocalizationCode = dbo.tbAehAerendeStatusLogTyp.strLocalizationCode
  FROM tbAehAerendeData
  LEFT OUTER JOIN dbo.tbAehAerendeStatusLog 
    ON dbo.tbAehAerendeData.recLastAerendeStatusLogID = dbo.tbAehAerendeStatusLog.recAerendeStatusLogID 
  LEFT OUTER JOIN dbo.tbAehAerendeStatusLogTyp 
    ON dbo.tbAehAerendeStatusLogTyp.recAerendeStatusLogTypID = dbo.tbAehAerendeStatusLog.recAerendeStatusLogTypID 
  WHERE tbAehAerendeData.recAerendeID = @recAerendeID
  
  UPDATE dbo.tbAehAerendeData SET datKomplett =
		(SELECT TOP(1) datDatum FROM tbAehAerendeStatusLog
			INNER JOIN tbAehAerendeStatusLogTyp 
				ON tbAehAerendeStatusLogTyp.recAerendeStatusLogTypID = tbAehAerendeStatusLog.recAerendeStatusLogTypID
				AND tbAehAerendeStatusLogTyp.strLocalizationCode = 'compl'
			WHERE recAerendeID = @recAerendeID
			ORDER BY datDatum desc
		)
	WHERE recAerendeID = @recAerendeID  
  
END
go

