CREATE VIEW [dbo].[vwMhStandardMoetespunktLista]
AS
SELECT     dbo.tbMhStandardMoetesPunktLista.recStandardMoetespunktListaID AS intRecnum, dbo.tbMhStandardMoetesPunktLista.recStandardMoetespunktListaID,
			dbo.tbMhStandardMoetesPunktLista.strNamn, dbo.tbMhStandardMoetesPunktLista.recOrganID, tbMhOrgan.strOrgannamn 
FROM          dbo.tbMhStandardMoetesPunktLista  LEFT OUTER JOIN     
 dbo.tbMhOrgan ON dbo.tbMhOrgan.recOrganID = dbo.tbMhStandardMoetesPunktLista.recOrganID
go

