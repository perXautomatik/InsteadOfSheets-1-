CREATE VIEW dbo.vwFasTrakt
AS
SELECT     strTRAKT, strLANKOD, strKOMKOD, strKOMMUN, MIN(recFASTIGH) AS intRecNum
FROM         dbo.tbFasFASTIGH
GROUP BY strTRAKT, strLANKOD, strKOMKOD, strKOMMUN
go

