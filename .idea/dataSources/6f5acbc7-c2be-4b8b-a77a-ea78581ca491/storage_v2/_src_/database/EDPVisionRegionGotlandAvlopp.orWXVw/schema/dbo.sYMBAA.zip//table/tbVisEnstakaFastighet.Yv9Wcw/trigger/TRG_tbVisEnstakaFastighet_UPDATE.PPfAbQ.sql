
        CREATE TRIGGER TRG_tbVisEnstakaFastighet_UPDATE ON
        tbVisEnstakaFastighet
        AFTER UPDATE
        AS
        BEGIN
        SET NOCOUNT ON;

        -- Bara intressant om strFastighetsbeteckning eller strFnrID är ändrade
        DECLARE fastighet_cursor CURSOR FAST_FORWARD
        FOR
        SELECT recAerendeID FROM tbAehAerendeEnstakaFastighet WHERE recFastighetID IN
            ( SELECT INSERTED.recFastighetID FROM INSERTED
            INNER JOIN DELETED
            ON INSERTED.recFastighetID = DELETED.recFastighetID
            AND ( ISNULL(INSERTED.strFastighetsbeteckning, '') <> ISNULL(DELETED.strFastighetsbeteckning, '') COLLATE Finnish_Swedish_CS_AS
                    OR ISNULL(INSERTED.strFnrID, '') <> ISNULL(DELETED.strFnrID, '') COLLATE Finnish_Swedish_CS_AS
                )
            )
        OPEN fastighet_cursor
        DECLARE @recAerendeID INT
        FETCH NEXT FROM fastighet_cursor INTO @recAerendeID
        WHILE (@@fetch_status = 0)
        BEGIN
            EXEC spAehAerendeDataUpdateFastighet @recAerendeID

            FETCH NEXT FROM fastighet_cursor INTO @recAerendeID
        END
        CLOSE fastighet_cursor
        DEALLOCATE fastighet_cursor

        DECLARE fastighet_cursor CURSOR FAST_FORWARD
        FOR
        SELECT recHaendelseID FROM tbAehHaendelseEnstakaFastighet WHERE recFastighetID IN
            ( SELECT INSERTED.recFastighetID FROM INSERTED
            INNER JOIN DELETED
            ON INSERTED.recFastighetID = DELETED.recFastighetID
            AND ( ISNULL(INSERTED.strFastighetsbeteckning, '') <> ISNULL(DELETED.strFastighetsbeteckning, '') COLLATE Finnish_Swedish_CS_AS
                    OR ISNULL(INSERTED.strFnrID, '') <> ISNULL(DELETED.strFnrID, '') COLLATE Finnish_Swedish_CS_AS
                )
            )
        OPEN fastighet_cursor
        DECLARE @recHaendelseID INT
        FETCH NEXT FROM fastighet_cursor INTO @recHaendelseID
        WHILE (@@fetch_status = 0)
        BEGIN
            EXEC spAehHaendelseUpdateFastighet @recHaendelseID

            FETCH NEXT FROM fastighet_cursor INTO @recHaendelseID
        END
        CLOSE fastighet_cursor
        DEALLOCATE fastighet_cursor
        END
        go

