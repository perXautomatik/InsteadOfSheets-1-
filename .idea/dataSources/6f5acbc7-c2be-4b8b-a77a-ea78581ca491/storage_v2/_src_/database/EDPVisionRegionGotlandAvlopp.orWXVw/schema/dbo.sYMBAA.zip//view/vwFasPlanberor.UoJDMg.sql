CREATE VIEW [dbo].[vwFasPlanberor]
AS
SELECT     TOP (100) PERCENT dbo.tbFasPLAN.recPLAN AS intRecNum, dbo.tbFasPLAN.strOTYP, dbo.tbFasPLAN.strDATUMLOP, 
                      dbo.tbFasPLANBEROR.strBNKLID, dbo.tbFasPLAN.strGRUPP, dbo.tbFasPLAN.strLMAKT, dbo.tbFasPLAN.strARKPL, dbo.tbFasPLAN.strPLNAMN, 
                      dbo.tbFasPLAN.strPLANFK, dbo.tbFasPLAN.strPSTAT, dbo.tbFasPLAN.strBDAT, dbo.tbFasPLAN.strGDATB, dbo.tbFasPLAN.strGDATU, 
                      dbo.tbFasPLAN.strGTILL, dbo.tbFasPLAN.strLDAT, dbo.tbFasPLAN.strSAJDAT, dbo.tbFasPLAN.strBMYND, dbo.tbFasPLAN.intMFLAGGA, 
                      dbo.tbFasPLAN.strONK, dbo.tbFasPLAN.strPLANANM, dbo.vwFasFastighet.strKOMMUN, dbo.tbFasPLANBEROR.strFNRID
FROM         dbo.tbFasPLAN LEFT OUTER JOIN
                      dbo.tbFasPLANBEROR ON dbo.tbFasPLAN.strBNKLID = dbo.tbFasPLANBEROR.strBNKLID INNER JOIN
                      dbo.vwFasFastighet ON dbo.tbFasPLANBEROR.strFNRID = dbo.vwFasFastighet.strFNRID
GROUP BY dbo.tbFasPLAN.recPLAN, dbo.tbFasPLAN.strOTYP, dbo.tbFasPLAN.strDATUMLOP, dbo.tbFasPLANBEROR.strBNKLID, dbo.tbFasPLAN.strGRUPP, 
                      dbo.tbFasPLAN.strLMAKT, dbo.tbFasPLAN.strARKPL, dbo.tbFasPLAN.strPLNAMN, dbo.tbFasPLAN.strPLANFK, dbo.tbFasPLAN.strPSTAT, 
                      dbo.tbFasPLAN.strBDAT, dbo.tbFasPLAN.strGDATB, dbo.tbFasPLAN.strGDATU, dbo.tbFasPLAN.strGTILL, dbo.tbFasPLAN.strLDAT, 
                      dbo.tbFasPLAN.strSAJDAT, dbo.tbFasPLAN.strBMYND, dbo.tbFasPLAN.intMFLAGGA, dbo.tbFasPLAN.strONK, dbo.tbFasPLAN.strPLANANM, 
                      dbo.vwFasFastighet.strKOMMUN, dbo.tbFasPLANBEROR.strFNRID
HAVING      (dbo.tbFasPLANBEROR.strBNKLID IN
                          (SELECT     strBNKLID
                            FROM          dbo.tbFasPLAN AS tbFasPLAN_1))
go

