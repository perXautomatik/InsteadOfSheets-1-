
CREATE VIEW [dbo].[vwTrRnByggnad]
AS
SELECT
	dbo.tbTrRnByggnad.recByggnadsID,
	dbo.tbTrRnByggnad.recByggnadsID AS intRecnum,

	dbo.tbTrRnByggnad.recTillsynsobjektID,
	dbo.tbTrTillsynsobjekt.strObjektsNamn,

	dbo.tbTrRnByggnad.strByggnadsID,
	dbo.tbTrRnByggnad.strByggnad,
	dbo.tbTrRnByggnad.strByggnadsAdress,
	dbo.tbTrRnByggnad.strRadonStatus,
	dbo.tbTrRnByggnad.datSenasteMaett,
	dbo.tbTrRnByggnad.strAnteckning,
	dbo.tbTrRnByggnad.strHustyp,
	dbo.tbTrRnByggnad.strByggmaterial,
	dbo.tbTrRnByggnad.strMarkTyp,
	dbo.tbTrRnByggnad.strMarkRisk,
	dbo.tbTrRnByggnad.strGrund,
	dbo.tbTrRnByggnad.bolOtaet,
	dbo.tbTrRnByggnad.strVentilationsTyp,
	dbo.tbTrRnByggnad.strVentilationsFunktion,
	dbo.tbTrRnByggnad.intByggnadsår,
	dbo.tbTrRnByggnad.intOmbyggnadsår,
	dbo.tbTrRnByggnad.strHusgrupp,
	dbo.tbTrRnByggnad.intAntalVaaningsplan,
	dbo.tbTrRnByggnad.intAntalLaegenheter,
	dbo.tbTrRnByggnad.intAntalLaegenheterMarkKontakt,
	dbo.tbTrRnByggnad.strVentilationHisschakt,
	dbo.tbTrTillsynsobjektFastighet.strFnrID,
	dbo.tbVisDeladFastighet.strFastighetsbeteckning

FROM dbo.tbTrRnByggnad
INNER JOIN dbo.tbTrTillsynsobjekt
	ON dbo.tbTrRnByggnad.recTillsynsobjektID = dbo.tbTrTillsynsobjekt.recTillsynsobjektID

LEFT OUTER JOIN
tbTrTillsynsobjektFastighet
ON tbTrTillsynsobjektFastighet.recTillsynsobjektID = tbTrRnByggnad.recTillsynsobjektID
AND tbTrTillsynsobjektFastighet.bolHuvudfastighet = 1

LEFT OUTER JOIN
dbo.tbVisDeladFastighet
ON tbVisDeladFastighet.strFnrID = tbTrTillsynsobjektFastighet.strFnrID
go

