CREATE VIEW [dbo].[vwAehHaendelseSekretessLog]
AS
SELECT     dbo.tbAehHaendelseSekretessLog.recHaendelseSekretessLogID, dbo.tbAehHaendelseSekretessLog.recHaendelseID,
                      dbo.tbAehHaendelseSekretessLog.intUserID, dbo.tbAehHaendelseSekretessLog.datDatum, dbo.tbEDPUser.strSignature,
                      dbo.tbAehHaendelseSekretessLog.recHaendelseSekretessLogID AS intRecnum, dbo.tbAehHaendelseSekretessLog.strKommentar,
                      dbo.tbAehHaendelseSekretessLog.strMyndighet, dbo.tbAehHaendelseSekretessLog.strRekommendation,
                      dbo.tbAehHaendelseSekretessLog.strBegraensa
FROM         dbo.tbAehHaendelseSekretessLog INNER JOIN
                      dbo.tbEDPUser ON dbo.tbAehHaendelseSekretessLog.intUserID = dbo.tbEDPUser.intUserID
go

