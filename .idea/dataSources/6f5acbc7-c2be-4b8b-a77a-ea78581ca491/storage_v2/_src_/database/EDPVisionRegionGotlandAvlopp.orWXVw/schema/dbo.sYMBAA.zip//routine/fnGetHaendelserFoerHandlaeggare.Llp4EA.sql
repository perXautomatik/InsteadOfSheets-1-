
            CREATE FUNCTION [dbo].[fnGetHaendelserFoerHandlaeggare] (@intUserID int)
            RETURNS TABLE 
            AS
            RETURN 
            (
              SELECT recHaendelseID FROM vwAehHaendelse  
              WHERE strSekretess IS NULL 
              OR LEN(strSekretess) = 0
              OR (strBegraensa = 'Alla') 
              OR (strBegraensa = 'Avdelning' AND 
                recAerendeID IN (SELECT recAerendeID FROM tbAehAerende WHERE recAvdelningID IN 
                (SELECT recAvdelningID FROM tbVisAvdelningUser WHERE intUserID IN (
                (SELECT @intUserID AS intUserID) UNION 
                (SELECT intChildUserID AS intUserID FROM tbVisHandlaeggareRelation WHERE intUserID = @intUserID)))
                ))
              OR (strBegraensa = 'Handläggare' AND (
                0 < (SELECT COUNT(*) FROM (
                --- Denna händelses alla handläggare ---
                (SELECT intUserID FROM tbAehHaendelseUser WHERE recHaendelseID = vwAehHaendelse.recHaendelseID)
                INTERSECT 
                --- Användaren och dennes kopplade handläggare ---
                ((SELECT @intUserID AS intUserID) UNION 
                (SELECT intChildUserID AS intUserID FROM tbVisHandlaeggareRelation WHERE intUserID = @intUserID))
                ) as HaendelseUsers) 
              )) 
            )
            go

