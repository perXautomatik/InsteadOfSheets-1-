CREATE VIEW [dbo].[vwVisMoms] 
AS
-- Specialvy: Moms ligger i tbVisCombo (NVARCHAR) men ska vara DECIMAL i lathundsvalideringen --
SELECT CAST(REPLACE(strComboVaerde, ',', '.') AS DECIMAL(4,2)) AS decMoms, recComboID AS intRecnum
  FROM dbo.tbVisCombo
  WHERE recCombogruppID = 
    (SELECT recCombogruppID FROM dbo.tbVisComboGrupp WHERE strGruppnamn = 'VisMoms')
  AND ISNUMERIC(strComboVaerde) = 1  -- Hanterar . och ,

go

