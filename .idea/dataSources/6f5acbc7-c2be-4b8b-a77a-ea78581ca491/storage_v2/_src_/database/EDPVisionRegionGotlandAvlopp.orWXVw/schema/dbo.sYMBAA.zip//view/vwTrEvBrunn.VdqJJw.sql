

CREATE VIEW [dbo].[vwTrEvBrunn]
AS

SELECT	dbo.tbTrEvBrunn.recBrunnsID, 
		dbo.tbTrEvBrunn.recBrunnsID AS intRecnum, 
		dbo.tbTrEvBrunn.recTillsynsobjektID, 
		dbo.tbTrEvBrunn.strBrunn, strSGUBrunnsID, 
		dbo.tbTrEvBrunn.strTyp, 
		dbo.tbTrEvBrunn.strJordart, 
		dbo.tbTrEvBrunn.intAnlagdAar, 
		dbo.tbTrEvBrunn.decDjup, 
		dbo.tbTrEvBrunn.decDiameter, 
		dbo.tbTrEvBrunn.strAnvaendning, 
		dbo.tbTrEvBrunn.intAntalLiterPerTimme, 
		dbo.tbTrEvBrunn.strAnteckning,
		dbo.tbTrEvBrunn.strStatus,
		dbo.tbTrEvBrunn.datStatusDatum,
		dbo.tbTrTillsynsobjekt.strObjektsNamn

FROM    dbo.tbTrEvBrunn

LEFT JOIN	dbo.tbTrTillsynsobjekt 
		ON	dbo.tbTrTillsynsobjekt.recTillsynsobjektID = dbo.tbTrEvBrunn.recTillsynsobjektID



go

