










CREATE VIEW [dbo].[vwTrLiLivsmedel]
AS
  SELECT                          
dbo.tbTrLiLivsmedel.recLivsmedelID, dbo.tbTrLiLivsmedel.recTillsynsobjektID, dbo.tbTrLiLivsmedel.strGodkaennandedatum, 
			dbo.tbTrLiLivsmedel.strParagraf, dbo.tbTrLiLivsmedel.strHygienmaerkning, dbo.tbTrLiLivsmedel.intOmsaettning, 
			dbo.tbTrLiLivsmedel.intAntalAnstaellda, dbo.tbTrLiLivsmedel.strRapporteringsID, dbo.tbTrLiLivsmedel.strNivaa1, 
			dbo.tbTrLiLivsmedel.strNivaa2, dbo.tbTrLiLivsmedel.strNivaa3, dbo.tbTrLiLivsmedel.strNivaa4,
			dbo.tbTrLiLivsmedel.intMinskadOmfattning, dbo.tbTrLiLivsmedel.strAnlaeggningsnamn, dbo.tbTrLiLivsmedel.bolSkaEjRapporteras,
			dbo.fnTrLiParametrar(dbo.tbTrLiLivsmedel.recTillsynsobjektID) AS strParametrar, 
			dbo.fnTrLiTyper(dbo.tbTrLiLivsmedel.recTillsynsobjektID) AS strTyper, 
			dbo.fnTrLiPlatser(dbo.tbTrLiLivsmedel.recTillsynsobjektID) AS strPlatser, 
			dbo.tbTrLiRiskklassning.datKlassningsdatum, dbo.tbTrLiRiskklassning.strVerksamhetsgrupp, 
			dbo.tbTrLiRiskklassning.strRiskklasstyp,
			dbo.tbTrLiRiskklassning.strStorlek, dbo.tbTrLiRiskklassning.strKonsument, dbo.tbTrLiRiskklassning.intRiskklass,
			dbo.tbTrLiRiskklassning.strUtformarMaerkning, dbo.tbTrLiRiskklassning.strErfarenhetsklass, 
			strTillsynsmyndighet,dbo.tbTrLiRiskklassning.decRiskmodulensTid,dbo.tbTrLiRiskklassning.decKontrolltidstillaegg,
			dbo.tbTrLiRiskklassning.decTidsfaktor
FROM		dbo.tbTrLiLivsmedel
LEFT OUTER JOIN	dbo.tbTrLiRiskklassning
			ON	dbo.tbTrLiRiskklassning.recTillsynsobjektID = dbo.tbTrLiLivsmedel.recTillsynsobjektID
			AND dbo.tbTrLiRiskklassning.recTrLiRiskklassningID =
                          (
							SELECT		TOP (1) recTrLiRiskklassningID
                            FROM		dbo.tbTrLiRiskklassning
                            WHERE		(recTillsynsobjektID = dbo.tbTrLiLivsmedel.recTillsynsobjektID)
                            ORDER BY	datKlassningsdatum DESC, recTrLiRiskklassningID DESC
                           )



go

