CREATE VIEW dbo.vwMifoOmgivning
AS
SELECT     dbo.tbMifoOmgivning.recOmgivningID, dbo.tbMifoOmgivning.recObjektID, dbo.tbMifoOmgivning.strMarkanvObjekt,
                      dbo.tbMifoOmgivning.strMarkanvPaaverkansOmr, dbo.tbMifoOmgivning.strAvstaandBostadsomr, dbo.tbMifoOmgivning.strVegetationsskadaObjekt,
                      dbo.tbMifoOmgivning.strVegetationsskadaPaaverkansOmr, dbo.tbMifoOmgivning.strJordartTyp, dbo.tbMifoOmgivning.strTopografi,
                      dbo.tbMifoOmgivning.strRecipientTyp, dbo.tbMifoOmgivning.strRecipientNamn, dbo.tbMifoOmgivning.strRecipientAvstaand,
                      dbo.tbMifoOmgivning.intMifoAvrinningId, dbo.tbMifoOmgivning.strByggnader, dbo.tbMifoOmgivning.strDagvattenDraeneringTyp,
                      dbo.tbMifoOmgivning.strDagvattenRecipientTyp, dbo.tbMifoOmgivning.strOevrigt, dbo.tbMifoAvrinning.strAvrinningsomraade,
                      dbo.tbMifoOmgivning.recOmgivningID AS intRecnum
FROM         dbo.tbMifoOmgivning LEFT OUTER JOIN
                      dbo.tbMifoAvrinning ON dbo.tbMifoOmgivning.intMifoAvrinningId = dbo.tbMifoAvrinning.intMifoAvrinningId
go

