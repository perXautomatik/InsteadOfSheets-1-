

CREATE PROCEDURE [dbo].[spGettbEDPRegisterBeroenden]
/* $Date: 2005-09-05 14:20:32+02:00 $ */
/* Givet en tabell, @strTableName, så vill vi hitta alla tabeller som */
/* har relationer som gör att vi ev. inte får lov att ta bort en post */
/* ur tabellen. */
/* Komplettera med att (i kod) för varje rad = tabell kolla om en     */
/* TABLE_NAME har en COLUMN_NAME som är den sökta posten i            */
/* @strTableName.                                                     */
@strTableName varchar(128)
AS

SELECT TABLE_NAME, COLUMN_NAME FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE CONSTRAINT_NAME IN (
  SELECT CONSTRAINT_NAME FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
  WHERE CONSTRAINT_NAME IN (
    SELECT CONSTRAINT_NAME FROM INFORMATION_SCHEMA.REFERENTIAL_CONSTRAINTS
    WHERE UNIQUE_CONSTRAINT_NAME IN (
      SELECT CONSTRAINT_NAME FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
      WHERE TABLE_NAME = @strTableName
    )
    AND DELETE_RULE <> 'CASCADE'
  )
)
go

