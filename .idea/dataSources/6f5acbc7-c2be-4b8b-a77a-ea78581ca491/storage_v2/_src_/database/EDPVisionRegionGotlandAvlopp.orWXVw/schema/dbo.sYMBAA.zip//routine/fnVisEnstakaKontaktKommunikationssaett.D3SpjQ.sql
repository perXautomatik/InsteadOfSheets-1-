
            CREATE FUNCTION [dbo].[fnVisEnstakaKontaktKommunikationssaett] 
            (
              @recEnstakaKontaktID INT
            )
            RETURNS NVARCHAR(MAX)
            AS
            BEGIN
              DECLARE @result NVARCHAR(MAX)
  
               SELECT @result = 
                LTRIM ((
                  SELECT strKommunikationsaettTyp + ' - ' + strVaerde + ', ' FROM tbVisKommunikationssaett
                  INNER JOIN  tbVisEnstakaKontaktKommunikationssaett
                    ON tbVisKommunikationssaett.recKommunikationssaettID = tbVisEnstakaKontaktKommunikationssaett.recKommunikationssaettID
                  WHERE tbVisEnstakaKontaktKommunikationssaett.recEnstakaKontaktID = @recEnstakaKontaktID
                  FOR XML PATH('')
                )) 

              RETURN LEFT(@result, LEN(@result) - 1)
            END
            go

