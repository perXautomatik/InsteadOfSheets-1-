/****** Object:  StoredProcedure [dbo].[spEDPGetValueTypesWithType]    Script Date: 11/09/2006 13:23:44 ******/
create PROCEDURE [dbo].[spEDPGetValueTypesWithType]
AS
BEGIN
	SET NOCOUNT ON;

	SELECT  strValueTypeName as ObjectName, 'ValueType' as ObjectTypeName ,intValueTypeID as ValueTypeID,  
    strValueTypeDescription as ValueTypeDescription 
  FROM tbEDPValueType
END
go

