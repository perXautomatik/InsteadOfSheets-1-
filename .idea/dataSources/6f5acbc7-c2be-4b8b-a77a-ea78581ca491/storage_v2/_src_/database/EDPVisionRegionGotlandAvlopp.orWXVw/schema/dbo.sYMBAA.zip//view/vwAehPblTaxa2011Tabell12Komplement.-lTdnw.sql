

CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell12Komplement]
AS
SELECT     tbAehPblTaxa2011Tabell12Komplement.recTabell12ID,
           recKomplementID as 'intRecnum', 
		   recKomplementID,
		   strObjekt,
		   strBeskrivning,
		   intOF,
		   intHF1,
		   recTaxa2011ID,
		   intHF2
FROM dbo.tbAehPblTaxa2011Tabell12Komplement
LEFT OUTER JOIN vwAehPblTaxa2011Tabell12
ON vwAehPblTaxa2011Tabell12.recTabell12ID = tbAehPblTaxa2011Tabell12Komplement.recTabell12ID



go

