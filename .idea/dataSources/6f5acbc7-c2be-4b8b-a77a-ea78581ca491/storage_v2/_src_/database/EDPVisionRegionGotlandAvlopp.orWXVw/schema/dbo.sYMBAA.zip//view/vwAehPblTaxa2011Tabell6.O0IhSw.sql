
CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell6]
AS
SELECT     recTabell6ID, recTaxa2011ID, recTabell6ID as 'intRecnum'
FROM         dbo.tbAehPblTaxa2011Tabell6



go

