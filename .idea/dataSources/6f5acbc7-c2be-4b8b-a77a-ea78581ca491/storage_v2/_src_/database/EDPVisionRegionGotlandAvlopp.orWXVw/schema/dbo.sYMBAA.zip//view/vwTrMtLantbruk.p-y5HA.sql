
CREATE VIEW [dbo].[vwTrMtLantbruk]
AS
SELECT
	dbo.tbTrMtLantbruk.recLantbrukID, 
	dbo.tbTrMtLantbruk.recLantbrukID as intRecnum, 
	dbo.tbTrMtLantbruk.recTillsynsobjektID,
	dbo.tbTrMtLantbruk.bolLantbruksobjekt,

	CASE 
		WHEN (SELECT TOP(1) strHuvudflik FROM tbTrTillsynsobjektHuvudflik WHERE recTillsynsobjektID  = tbTrMtLantbruk.recTillsynsobjektID ORDER BY recTillsynsobjektHuvudflikID ASC) = 'TrMtLantbruk' THEN 
			CAST(1 as bit)
		ELSE 
			CAST(0 as bit)
	END AS bolHuvudflik,

	dbo.tbTrMtLantbruk.strSENummer, 
	dbo.tbTrMtLantbruk.strInriktning, 
	dbo.tbTrMtLantbruk.strFoersamling, 
	dbo.tbTrMtLantbruk.strKaensligtOmraade, 
	dbo.tbTrMtLantbruk.strCertifiering, 
	dbo.tbTrMtLantbruk.decHektarAakermark, 
	dbo.tbTrMtLantbruk.decHektarBetesmark, 
    dbo.tbTrMtLantbruk.decHektarSkogsmark,	
	dbo.tbTrMtLantbruk.intMarkkarteringAar, 
	dbo.tbTrMtLantbruk.intVaextodlingsplanAar, 
	dbo.tbTrMtLantbruk.strAnvaendsBekaempningsmedel, 
	dbo.tbTrMtLantbruk.decSpriderSlam, 
	dbo.tbTrMtLantbruk.intSenasteSpridning, 
	dbo.tbTrMtLantbruk.decDjurenheter, 
	dbo.tbTrMtLantbruk.datDatum, 
    dbo.tbTrMtLantbruk.decTillgaengligSpridningsareal, 
	dbo.tbTrMtLantbruk.decSpridningskontrakt, 
	dbo.tbTrMtLantbruk.decBortfoerande, 
	dbo.tbTrMtLantbruk.decMottagande, 
	dbo.tbTrMtLantbruk.intKonstgoedsel, 
	dbo.tbTrMtLantbruk.decGoedselplatta, 
	dbo.tbTrMtLantbruk.decFlytgoedsel, 
	dbo.tbTrMtLantbruk.decUrinbrunn
FROM dbo.tbTrMtLantbruk


go

