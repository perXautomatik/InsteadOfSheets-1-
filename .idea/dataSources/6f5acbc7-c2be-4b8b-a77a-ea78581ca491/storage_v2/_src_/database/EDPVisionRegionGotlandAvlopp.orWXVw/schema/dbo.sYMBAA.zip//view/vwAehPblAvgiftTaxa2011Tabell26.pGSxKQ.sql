
CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell26]
AS
SELECT	
  dbo.tbAehPblAvgiftTaxa2011Tabell26.recPblAvgiftTaxa2011Tabell26ID,
  dbo.tbAehPblAvgiftTaxa2011Tabell26.recPblAvgiftTaxa2011Tabell26ID AS intRecnum, 
  dbo.tbAehPblAvgiftTaxa2011Tabell26.recAvgiftID, 
  dbo.tbAehPblAvgiftTaxa2011Tabell26.decAvgift, 
  dbo.tbAehPblAvgiftTaxa2011Tabell26.decAntalHA, 
  dbo.tbAehPblAvgiftTaxa2011Tabell26.decKF, 
  dbo.tbAehPblAvgiftTaxa2011Tabell26.decmPBB, 
  dbo.tbAehPblAvgiftTaxa2011Tabell26.decN, 
  dbo.tbAehPblAvgiftTaxa2011Tabell26.decMaterialKostnad, 
  dbo.tbAehPblAvgiftTaxa2011Tabell26.decAvgiftTotalt, 
  dbo.tbAehPblAvgiftTaxa2011Tabell26.bolDebiterad
FROM dbo.tbAehPblAvgiftTaxa2011Tabell26

go

