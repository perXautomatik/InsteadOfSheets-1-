CREATE PROCEDURE [dbo].[spAehHaendelseUpdateFastighet]
  @recHaendelseID int
AS
BEGIN
  SET NOCOUNT ON;

  UPDATE dbo.tbAehHaendelseData SET
    strFastighetsbeteckning = dbo.tbVisEnstakaFastighet.strFastighetsbeteckning, 
    strFnrID = dbo.tbVisEnstakaFastighet.strFnrID,
    recFastighetID = dbo.tbVisEnstakaFastighet.recFastighetID,
    recKommunID = tbVisEnstakaFastighet.recKommunID
  FROM dbo.tbAehHaendelseData
  LEFT OUTER JOIN dbo.tbAehHaendelseEnstakaFastighet
     ON dbo.tbAehHaendelseEnstakaFastighet.recHaendelseID = dbo.tbAehHaendelseData.recHaendelseID 
     AND dbo.tbAehHaendelseEnstakaFastighet.bolHuvudfastighet = 1
  LEFT OUTER JOIN dbo.tbVisEnstakaFastighet 
     ON dbo.tbAehHaendelseEnstakaFastighet.recFastighetID = dbo.tbVisEnstakaFastighet.recFastighetID 
  WHERE dbo.tbAehHaendelseData.recHaendelseID = @recHaendelseID
END
go

