CREATE VIEW [dbo].[vwTrEaAvloppsanlaeggning]
AS
SELECT

	dbo.tbTrEaAvloppsanlaeggning.recAvloppsanlaeggningID, 
	dbo.tbTrEaAvloppsanlaeggning.recAvloppsanlaeggningID as intRecnum,
	dbo.tbTrEaAvloppsanlaeggning.recTillsynsobjektID, 
	dbo.tbTrEaAvloppsanlaeggning.strBoendetyp, 
	dbo.tbTrEaAvloppsanlaeggning.strVatten, 
	dbo.tbTrEaAvloppsanlaeggning.bolIndraget, 
	dbo.tbTrEaAvloppsanlaeggning.strAnlaeggningstyp, 
	dbo.tbTrEaAvloppsanlaeggning.strStatus, 
	dbo.tbTrEaAvloppsanlaeggning.intByggnadsaar, 
	dbo.tbTrEaAvloppsanlaeggning.datBeslutsdatum, 
	dbo.tbTrEaAvloppsanlaeggning.datBesiktningsdatum,	
	dbo.tbTrEaAvloppsanlaeggning.strNotering, 
	dbo.tbTrEaAvloppsanlaeggning.strEfterfoeljandereningReningstyp, 
	dbo.tbTrEaAvloppsanlaeggning.intEfterfoeljandereningYta, 
	dbo.tbTrEaAvloppsanlaeggning.strEfterfoeljandereningRecipient, 
	dbo.tbTrEaAvloppsanlaeggning.strBedoemning, 
	dbo.tbTrEaAvloppsanlaeggning.strInventering, 
	dbo.tbTrEaAvloppsanlaeggning.datInventeringsdatum,
	dbo.tbTrEaAvloppsanlaeggning.intLoepnr,
	dbo.tbTrEaAvloppsanlaeggning.strVattenskyddsomraade,
	dbo.tbTrEaAvloppsanlaeggning.strPrioritet,
	dbo.tbTrEaAvloppsanlaeggning.strEfterpoleringTyp,
	dbo.tbTrEaAvloppsanlaeggning.intUnderhaallsintervallMaanad,
	dbo.tbTrEaAvloppsanlaeggning.datNaastaService,
	dbo.tbTrEaAvloppsanlaeggning.datFoeregaandeService,
	dbo.tbTrEaAvloppsanlaeggning.strAvrinningsomraade

FROM         dbo.tbTrEaAvloppsanlaeggning

LEFT OUTER JOIN
dbo.tbTrTillsynsobjekt 
ON dbo.tbtrTillsynsobjekt.recTillsynsobjektID = dbo.tbTrEaAvloppsanlaeggning.recTillsynsobjektID

go

