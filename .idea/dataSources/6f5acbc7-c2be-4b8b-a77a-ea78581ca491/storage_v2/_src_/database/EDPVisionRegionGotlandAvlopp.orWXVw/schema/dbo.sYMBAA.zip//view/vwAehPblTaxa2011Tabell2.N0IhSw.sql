
CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell2]
AS
SELECT     

recTabell2ID, 
recTaxa2011ID, 
recTabell2ID as 'intRecnum', 
dbo.tbAehPblTaxa2011Tabell2.recTjaenstID,
dbo.tbAehPblTaxa2011Tabell2.recFakturatextID,
strFritext,
decMoms,
	dbo.tbVisTjaenst.strTjaenstKod,
	dbo.tbVisTjaenst.strTjaenst,
	dbo.tbVisFakturatext.strFakturatextkod
	
FROM dbo.tbAehPblTaxa2011Tabell2

	LEFT OUTER JOIN dbo.tbVisFakturatext
	ON dbo.tbVisFakturatext.recFakturatextID = dbo.tbAehPblTaxa2011Tabell2.recFakturatextID
	
	LEFT OUTER JOIN dbo.tbVisTjaenst
	ON dbo.tbVisTjaenst.recTjaenstID = dbo.tbAehPblTaxa2011Tabell2.recTjaenstID


go

