
        CREATE TRIGGER TRG_tbAehAerendeSekretessLog_INSERT ON tbAehAerendeSekretessLog
        AFTER INSERT
        AS
        BEGIN
        SET NOCOUNT ON;

        DECLARE sekretess_cursor CURSOR FAST_FORWARD
        FOR
        SELECT recAerendeID FROM INSERTED
        OPEN sekretess_cursor
        DECLARE @recAerendeID INT
        FETCH NEXT FROM sekretess_cursor INTO @recAerendeID
        WHILE (@@fetch_status = 0)
        BEGIN
            EXEC spAehAerendeDataUpdateSekretesslog @recAerendeID

            FETCH NEXT FROM sekretess_cursor INTO @recAerendeID
        END
        CLOSE sekretess_cursor
        DEALLOCATE sekretess_cursor
        END
        go

