

CREATE VIEW [dbo].[vwVisDeladFastighetKoppladTill]
AS

SELECT ROW_NUMBER() OVER (order by strTyp) as recKoppladTillID,
  ROW_NUMBER() OVER (order by strTyp) as intRecnum,
  strFnrId,
  intID, 
  strUrsprungsTabellNamn,
  strUrsprungsTabellIdkolumnnamn,
  strTyp,
  strBeskrivning
FROM 
  (SELECT DISTINCT
    tbMmOmraadeDeladFastighet.strFnrID,
    tbMmOmraade.recOmrID as intID,
    'tbMmOmraade' as strUrsprungsTabellNamn,
    'recOmrID' as strUrsprungsTabellIdkolumnnamn,
    'Område' as strTyp,
    strOmrNamn as strBeskrivning
    FROM tbMmOmraade
    INNER JOIN tbMmOmraadeDeladFastighet
      ON tbMmOmraadeDeladFastighet.recOmrID = tbMmOmraade.recOmrID

  UNION
 
    SELECT DISTINCT
    tbVisDeladFastighet.strFnrID,
    tbTrVerksamhet.recVerksamhetID as intID,
    'tbTrVerksamhet' as strUrsprungsTabellNamn,
    'recVerksamhetID' as strUrsprungsTabellIdkolumnnamn,
    'Verksamhet' as strTyp,
    strVerksamhetNamn as strBeskrivning
    FROM tbTrVerksamhet
    INNER JOIN tbVisDeladFastighet
      ON tbVisDeladFastighet.strFnrID = tbTrVerksamhet.strFnrID

  UNION
  
  SELECT DISTINCT
    tbTrHiHissFastighet.strFnrID,
    tbTrHiHiss.recHissID as intID,
    'tbTrHiHiss' as strUrsprungsTabellNamn,
    'recHissID' as strUrsprungsTabellIdkolumnnamn,
    'Hissar' as strTyp,
    strRegistreringsnummer as strBeskrivning
    FROM tbTrHiHiss
    INNER JOIN tbTrHiHissFastighet
      ON tbTrHiHissFastighet.recHissID = tbTrHiHiss.recHissID

  UNION
  
      SELECT DISTINCT
    tbTrSkSkyddsrumPaaObjektFastighet.strFnrID,
    tbTrSkSkyddsrumPaaObjekt.recSkyddsrumPaaObjektID as intID,
    'tbTrSkSkyddsrumPaaObjekt' as strUrsprungsTabellNamn,
    'recSkyddsrumPaaObjektID' as strUrsprungsTabellIdkolumnnamn,
    'Skyddsrum' as strTyp,
    strSkyddsrumsnummer as strBeskrivning
    FROM tbTrSkSkyddsrumPaaObjekt
    INNER JOIN tbTrSkSkyddsrumPaaObjektFastighet
      ON tbTrSkSkyddsrumPaaObjektFastighet.recSkyddsrumPaaObjektID = tbTrSkSkyddsrumPaaObjekt.recSkyddsrumPaaObjektID

  UNION
  
        SELECT DISTINCT
    tbTrVeVentilationsaggregatFastighet.strFnrID,
    tbTrVeVentilationsaggregat.recVentilationsaggregatID as intID,
    'tbTrVeVentilationsaggregat' as strUrsprungsTabellNamn,
    'recVentilationsaggregatID' as strUrsprungsTabellIdkolumnnamn,
    'Ventilationsaggregat' as strTyp,
    strAggregat as strBeskrivning
    FROM tbTrVeVentilationsaggregat
    INNER JOIN tbTrVeVentilationsaggregatFastighet
      ON tbTrVeVentilationsaggregatFastighet.recVentilationsaggregatID = tbTrVeVentilationsaggregat.recVentilationsaggregatID

  UNION
  
      SELECT DISTINCT
    tbTrBvBrandfarligVaraFastighet.strFnrID,
    tbTrBvBrandfarligVara.recBrandfarligVaraID as intID,
    'tbTrBvBrandfarligVara' as strUrsprungsTabellNamn,
    'recBrandfarligVaraID' as strUrsprungsTabellIdkolumnnamn,
    'Brandfarlig vara' as strTyp,
    strBeskrivning as strBeskrivning
    FROM tbTrBvBrandfarligVara
    INNER JOIN tbTrBvBrandfarligVaraFastighet
      ON tbTrBvBrandfarligVaraFastighet.recBrandfarligVaraID = tbTrBvBrandfarligVara.recBrandfarligVaraID

  UNION

    SELECT DISTINCT
    tbTrTillsynsobjektFastighet.strFnrID,
    tbTrTillsynsobjekt.recTillsynsobjektID as intID,
    'tbTrTillsynsobjekt' as strUrsprungsTabellNamn,
    'recTillsynsobjektID' as strUrsprungsTabellIdkolumnnamn,
    'Tillsynsobjekt (' + (SELECT strTillsynsobjektsTypNamn FROM vwTrTillsynsobjekt WHERE recTillsynsobjektID = tbTrTillsynsobjektFastighet.recTillsynsobjektID) + ')' as strTyp,
    CAST(tbTrTillsynsobjekt.recTillsynsObjektID AS NVARCHAR)+ '/' + strVerksamhetNamn + '/' + ISNULL(strObjektsNamn, '') as strBeskrivning
    FROM tbTrTillsynsobjekt
    INNER JOIN tbTrTillsynsobjektFastighet
      ON tbTrTillsynsobjektFastighet.recTillsynsobjektID = tbTrTillsynsobjekt.recTillsynsobjektID
    INNER JOIN tbTrVerksamhet 
      ON tbTrVerksamhet.recVerksamhetID = tbTrTillsynsobjekt.recVerksamhetID

  UNION

    SELECT DISTINCT
    tbTrKmAggregatFastighet.strFnrID,
    tbTrKmAggregat.recAggregatID as intID,
    'tbTrKmAggregat' as strUrsprungsTabellNamn,
    'recAggregatID' as strUrsprungsTabellIdkolumnnamn,
    'Aggregat' as strTyp,
    strAggregatBeteckning as strBeskrivning
    FROM tbTrKmAggregat
    INNER JOIN tbTrKmAggregatFastighet
      ON tbTrKmAggregatFastighet.recAggregatID = tbTrKmAggregat.recAggregatID

  ) AS x



go

