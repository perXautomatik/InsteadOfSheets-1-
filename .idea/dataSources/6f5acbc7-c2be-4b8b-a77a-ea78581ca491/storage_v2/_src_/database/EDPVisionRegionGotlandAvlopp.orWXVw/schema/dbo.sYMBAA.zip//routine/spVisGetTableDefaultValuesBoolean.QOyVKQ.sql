


CREATE PROCEDURE [dbo].[spVisGetTableDefaultValuesBoolean]
/* Hämtar alla booleancolumner där defaultvärdet är null */

AS


SELECT SO.NAME AS "Table Name", SC.NAME AS "Column Name", SM.TEXT AS "Default Value"
FROM dbo.sysobjects SO INNER JOIN dbo.syscolumns SC ON SO.id = SC.id 
LEFT JOIN dbo.syscomments SM ON SC.cdefault = SM.id  
WHERE SO.xtype = 'U' and sc.name like 'bol%' and sm.text is NULL AND SO.Name NOT LIKE 'tbEDP%'
ORDER BY SO.[name], SC.colid

go

