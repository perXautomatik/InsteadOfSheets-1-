

CREATE PROCEDURE dbo.spEDPSortOrderInsert
	(
		@intControlColumnID int,
		@bolDefault bit,
		@intAppearanceOrder int,
		@intSortOrderID int output
	)
AS
	SET NOCOUNT ON
	
	INSERT INTO tbEDPSortOrder
	                      (intControlColumnID, bolDefault, intAppearanceOrder)
	VALUES     (@intControlColumnID, @bolDefault, @intAppearanceOrder)
	
	SELECT @intSortOrderID = (SCOPE_IDENTITY())
	
	RETURN


go

