

CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell20Anlaeggningar]
AS
SELECT        recPblAvgiftTaxa2011Tabell20AnlaeggningarID
			, recPblAvgiftTaxa2011Tabell20ID
			, recPblAvgiftTaxa2011Tabell20AnlaeggningarID as 'intRecnum'
			, strObjekt
			, strBeskrivning
			, intOF
			, intHF1
			, intHF2
FROM         dbo.tbAehPblAvgiftTaxa2011Tabell20Anlaeggningar
go

