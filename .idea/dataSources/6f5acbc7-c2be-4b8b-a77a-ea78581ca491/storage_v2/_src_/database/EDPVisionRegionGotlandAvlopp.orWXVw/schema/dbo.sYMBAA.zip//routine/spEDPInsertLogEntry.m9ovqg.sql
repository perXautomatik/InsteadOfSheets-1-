CREATE PROCEDURE [dbo].[spEDPInsertLogEntry] 
	-- Add the parameters for the stored procedure here
	@strTableName varchar(100),
	@intIdentity int, 
	@intActionID int,
	@strOldValue varchar(8000),
	@strNewValue varchar(8000),
	@intUserID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	INSERT INTO tbEDPLog(strTableName, intIdentity, intActionID, strOldValue, strNewValue, intUserID)
	VALUES(@strTableName, @intIdentity, @intActionID, @strOldValue, @strNewValue, @intUserID)
END
go

