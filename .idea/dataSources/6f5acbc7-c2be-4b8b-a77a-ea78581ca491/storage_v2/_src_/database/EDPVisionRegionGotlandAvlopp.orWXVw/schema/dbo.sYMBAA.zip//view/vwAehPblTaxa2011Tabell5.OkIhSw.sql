
CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell5]
AS
SELECT     

recTabell5ID, 
recTaxa2011ID, 
recTabell5ID as 'intRecnum', 
dbo.tbAehPblTaxa2011Tabell5.recTjaenstID,
dbo.tbAehPblTaxa2011Tabell5.recFakturatextID,
strFritext,
decMoms,
	dbo.tbVisTjaenst.strTjaenstKod,
	dbo.tbVisTjaenst.strTjaenst,
	dbo.tbVisFakturatext.strFakturatextkod
	
FROM dbo.tbAehPblTaxa2011Tabell5

	LEFT OUTER JOIN dbo.tbVisFakturatext
	ON dbo.tbVisFakturatext.recFakturatextID = dbo.tbAehPblTaxa2011Tabell5.recFakturatextID
	
	LEFT OUTER JOIN dbo.tbVisTjaenst
	ON dbo.tbVisTjaenst.recTjaenstID = dbo.tbAehPblTaxa2011Tabell5.recTjaenstID


go

