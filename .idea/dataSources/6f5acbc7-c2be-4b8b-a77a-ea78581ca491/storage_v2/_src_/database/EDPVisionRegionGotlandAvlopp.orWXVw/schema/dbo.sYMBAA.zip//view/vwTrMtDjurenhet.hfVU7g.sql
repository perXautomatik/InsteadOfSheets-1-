CREATE VIEW [dbo].[vwTrMtDjurenhet]
AS
SELECT     recDjurenhetID, recDjurenhetID AS intRecnum, strDjurslag, intDjurPerDjurenhet, decDjurenhetPerHektar, decLagringstid, decFlytgoedsel, decFastgoedsel, 
                      decUrinGoedselvatten, bolEjAktuell
FROM         dbo.tbTrMtDjurenhet
go

