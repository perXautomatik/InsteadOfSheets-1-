
        CREATE TRIGGER TRG_tbEDPUser_UPDATE ON tbEDPUser
        AFTER UPDATE
        AS
        BEGIN
        SET NOCOUNT ON;

        DECLARE user_cursor CURSOR FAST_FORWARD
        FOR
        SELECT recAerendeID FROM tbAehAerendeUser WHERE intUserID IN
        ( SELECT INSERTED.intUserID
            FROM INSERTED
            INNER JOIN DELETED
            ON INSERTED.intUserID = DELETED.intUserID
            AND ISNULL(INSERTED.strSignature, '') <> ISNULL(DELETED.strSignature, '') COLLATE Finnish_Swedish_CS_AS
        )
        OPEN user_cursor
        DECLARE @recAerendeID INT
        FETCH NEXT FROM user_cursor INTO @recAerendeID
        WHILE (@@fetch_status = 0)
        BEGIN
            EXEC spAehAerendeDataUpdateHuvudhandlaeggare @recAerendeID

            FETCH NEXT FROM user_cursor INTO @recAerendeID
        END
        CLOSE user_cursor
        DEALLOCATE user_cursor

        DECLARE user_cursor CURSOR FAST_FORWARD
        FOR
        SELECT recHaendelseID FROM tbAehHaendelseUser WHERE intUserID IN
        ( SELECT INSERTED.intUserID
            FROM INSERTED
            INNER JOIN DELETED
            ON INSERTED.intUserID = DELETED.intUserID
            AND ISNULL(INSERTED.strSignature, '') <> ISNULL(DELETED.strSignature, '') COLLATE Finnish_Swedish_CS_AS
        )
        OPEN user_cursor
        DECLARE @recHaendelseID INT
        FETCH NEXT FROM user_cursor INTO @recHaendelseID
        WHILE (@@fetch_status = 0)
        BEGIN
            EXEC spAehHaendelseUpdateHuvudHandlaeggare @recHaendelseID

            FETCH NEXT FROM user_cursor INTO @recHaendelseID
        END
        CLOSE user_cursor
        DEALLOCATE user_cursor
        END
        go

