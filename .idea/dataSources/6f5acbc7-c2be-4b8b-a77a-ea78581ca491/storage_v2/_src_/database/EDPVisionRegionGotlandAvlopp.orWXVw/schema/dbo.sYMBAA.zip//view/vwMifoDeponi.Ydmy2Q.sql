
CREATE VIEW dbo.vwMifoDeponi
AS
SELECT     dbo.tbMifoDeponi.recDeponiID, dbo.tbMifoDeponi.recObjektID, dbo.tbMifoDeponi.strLokalisering, dbo.tbMifoDeponi.strDeponiTyp, 
                      dbo.tbMifoDeponi.strInnehaall, dbo.tbMifoDeponi.strLaeckage, dbo.tbMifoDeponi.intXKoordinat, dbo.tbMifoDeponi.intYKoordinat, 
                      dbo.tbMifoDeponi.strZKoordinat, dbo.tbMifoObjekt.strObjektId, dbo.tbMifoObjekt.strObjektNamn, dbo.tbMifoDeponi.recDeponiID AS intRecnum
FROM         dbo.tbMifoDeponi LEFT OUTER JOIN
                      dbo.tbMifoObjekt ON dbo.tbMifoDeponi.recObjektID = dbo.tbMifoObjekt.recObjektID
go

