
CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011]
AS
SELECT     
	dbo.tbAehPblAvgiftTaxa2011.*, 
	dbo.tbAehPblAvgiftTaxa2011.recPblAvgiftTaxa2011ID AS intRecnum
FROM dbo.tbAehPblAvgiftTaxa2011

go

