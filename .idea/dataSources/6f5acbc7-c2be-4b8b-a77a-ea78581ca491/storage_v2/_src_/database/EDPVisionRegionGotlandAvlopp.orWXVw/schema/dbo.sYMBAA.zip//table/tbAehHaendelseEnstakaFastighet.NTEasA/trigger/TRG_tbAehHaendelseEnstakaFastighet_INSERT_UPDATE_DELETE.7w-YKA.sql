
        CREATE TRIGGER TRG_tbAehHaendelseEnstakaFastighet_INSERT_UPDATE_DELETE ON tbAehHaendelseEnstakaFastighet
        AFTER INSERT, UPDATE, DELETE
        AS
        BEGIN
        SET NOCOUNT ON;

        DECLARE haendelse_fastighet_cursor CURSOR FAST_FORWARD
        FOR
        SELECT recHaendelseID FROM INSERTED UNION SELECT recHaendelseID FROM DELETED
        OPEN haendelse_fastighet_cursor
        DECLARE @recHaendelseID INT
        FETCH NEXT FROM haendelse_fastighet_cursor INTO @recHaendelseID
        WHILE (@@fetch_status = 0)
        BEGIN
            EXEC spAehHaendelseUpdateFastighet @recHaendelseID

            FETCH NEXT FROM haendelse_fastighet_cursor INTO @recHaendelseID
        END
        CLOSE haendelse_fastighet_cursor
        DEALLOCATE haendelse_fastighet_cursor
        END
        go

