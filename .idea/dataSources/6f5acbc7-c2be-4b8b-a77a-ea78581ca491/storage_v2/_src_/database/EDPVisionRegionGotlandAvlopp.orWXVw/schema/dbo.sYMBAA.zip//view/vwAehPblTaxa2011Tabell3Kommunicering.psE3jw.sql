



CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell3Kommunicering]
AS
SELECT		tbAehPblTaxa2011Tabell3Kommunicering.recTabell3ID, 
			recKommuniceringID as 'intRecnum', 
			recKommuniceringID,
			strKommuniceringstyp,
			strBeskrivning,
			recTaxa2011ID,
			intKOM
FROM         dbo.tbAehPblTaxa2011Tabell3Kommunicering
LEFT OUTER JOIN vwAehPblTaxa2011Tabell3
ON vwAehPblTaxa2011Tabell3.recTabell3ID = tbAehPblTaxa2011Tabell3Kommunicering.recTabell3ID


go

