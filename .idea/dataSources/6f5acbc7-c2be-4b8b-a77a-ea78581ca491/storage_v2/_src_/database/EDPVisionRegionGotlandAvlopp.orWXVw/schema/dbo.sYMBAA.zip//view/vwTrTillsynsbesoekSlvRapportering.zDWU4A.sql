
CREATE VIEW vwTrTillsynsbesoekSlvRapportering
AS

-- Hitta alla rapporteringspunkter för tillsynsbesöken
WITH [Punkter] AS (
  SELECT [recTillsynsbesoekID], [strRapporteringsPunkt] + ': ' + [strVaerde] AS [strResultat]
  FROM [dbo].[tbTrChecklistaPunkt]
  LEFT OUTER JOIN [dbo].[tbTrChecklistamallVersionPunkt]
    ON [dbo].[tbTrChecklistamallVersionPunkt].[recChecklistamallVersionPunktID] = [dbo].[tbTrChecklistaPunkt].[recChecklistamallVersionPunktID]
  LEFT OUTER JOIN [dbo].[tbTrChecklistamallVersionVaerden]
    ON [dbo].[tbTrChecklistamallVersionVaerden].[recChecklistamallVersionVaerdenID] = [dbo].[tbTrChecklistaPunkt].[recChecklistamallVersionVaerdenID]
),
-- Slå ihop alla punkter per tillsynsbesök
[SammanslagnaPunkter] AS(
SELECT [P1].[recTillsynsbesoekID], 
  (SELECT [P2].[strResultat] + ', ' 
   FROM [Punkter] AS [P2] 
   WHERE [P2].[recTillsynsbesoekID] = [P1].[recTillsynsbesoekID] FOR XML PATH('')
  ) AS [strResultat]
FROM [Punkter] AS [P1]
GROUP BY [P1].[recTillsynsbesoekID]
)
-- Välj ut de uppgifter vi behöver
SELECT [dbo].[vwTrTillsynsbesoek].[recTillsynsbesoekID], 
  [dbo].[vwTrTillsynsbesoek].[recTillsynsbesoekID] AS intRecnum, 
  [dbo].[vwTrTillsynsbesoek].[recTillsynsobjektID], 
  [dbo].[vwTrTillsynsbesoek].[strVerksamhetNamn],
  [dbo].[vwTrTillsynsbesoek].[strObjektsNamn],
  [dbo].[vwTrTillsynsbesoek].[datDatum],
  [dbo].[vwTrTillsynsbesoek].strRapporteringsID,
  [dbo].[vwTrTillsynsbesoek].[strNamn],
  [dbo].[vwTrTillsynsbesoek].[strAnmaelningstyp],
  [dbo].[vwTrTillsynsbesoek].[strSyfte], 
  CASE [SammanslagnaPunkter].[strResultat]
    WHEN '' THEN NULL
    ELSE LEFT([SammanslagnaPunkter].[strResultat], LEN([SammanslagnaPunkter].[strResultat]) - 1)
  END AS [strResultat]
FROM [dbo].[vwTrTillsynsbesoek]
LEFT OUTER JOIN [SammanslagnaPunkter]
  ON [SammanslagnaPunkter].[recTillsynsbesoekID] = [dbo].[vwTrTillsynsbesoek].[recTillsynsbesoekID]
go

