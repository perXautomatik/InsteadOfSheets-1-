

CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell10Hissar]
AS
SELECT     tbAehPblTaxa2011Tabell10Hissar.recTabell10ID,            
		   recHissarMotorfordonID,
		   recHissarMotorfordonID as 'intRecnum', 
		   strAatgaerd,
		   recTaxa2011ID,
		   strBeskrivning,intHF

FROM         dbo.tbAehPblTaxa2011Tabell10Hissar
LEFT OUTER JOIN vwAehPblTaxa2011Tabell10 
ON vwAehPblTaxa2011Tabell10.recTabell10ID = tbAehPblTaxa2011Tabell10Hissar.recTabell10ID



go

