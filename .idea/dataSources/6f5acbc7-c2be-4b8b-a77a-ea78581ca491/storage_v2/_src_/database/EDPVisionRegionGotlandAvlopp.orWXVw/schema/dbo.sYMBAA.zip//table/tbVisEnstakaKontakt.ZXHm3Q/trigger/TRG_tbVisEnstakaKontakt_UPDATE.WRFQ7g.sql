
        CREATE TRIGGER TRG_tbVisEnstakaKontakt_UPDATE ON tbVisEnstakaKontakt
        AFTER UPDATE
        AS
        BEGIN
        SET NOCOUNT ON;

        DECLARE kontakt_cursor CURSOR FAST_FORWARD
        FOR
        SELECT recAerendeID FROM tbAehAerendeEnstakaKontakt WHERE recEnstakaKontaktID IN
            ( SELECT INSERTED.recEnstakaKontaktID FROM INSERTED
            INNER JOIN DELETED
            ON INSERTED.recEnstakaKontaktID = DELETED.recEnstakaKontaktID
            AND ( ISNULL(INSERTED.strVisasSom, '') <> ISNULL(DELETED.strVisasSom, '') COLLATE Finnish_Swedish_CS_AS
                    OR ISNULL(INSERTED.strGatuadress, '') <> ISNULL(DELETED.strGatuadress, '') COLLATE Finnish_Swedish_CS_AS
                    OR ISNULL(INSERTED.strPostnummer, '') <> ISNULL(DELETED.strPostnummer, '') COLLATE Finnish_Swedish_CS_AS
                    OR ISNULL(INSERTED.strPostort, '') <> ISNULL(DELETED.strPostort, '') COLLATE Finnish_Swedish_CS_AS
                )
            )

        OPEN kontakt_cursor
        DECLARE @recAerendeID INT
        FETCH NEXT FROM kontakt_cursor INTO @recAerendeID
        WHILE (@@fetch_status = 0)
        BEGIN
            EXEC spAehAerendeDataUpdateKontakt @recAerendeID

            FETCH NEXT FROM kontakt_cursor INTO @recAerendeID
        END
        CLOSE kontakt_cursor
        DEALLOCATE kontakt_cursor

        DECLARE kontakt_cursor CURSOR FAST_FORWARD
        FOR
        SELECT recHaendelseID FROM tbAehHaendelseEnstakaKontakt WHERE recEnstakaKontaktID IN
            ( SELECT INSERTED.recEnstakaKontaktID FROM INSERTED
            INNER JOIN DELETED
            ON INSERTED.recEnstakaKontaktID = DELETED.recEnstakaKontaktID
            AND ( ISNULL(INSERTED.strVisasSom, '') <> ISNULL(DELETED.strVisasSom, '') COLLATE Finnish_Swedish_CS_AS
                    OR ISNULL(INSERTED.strGatuadress, '') <> ISNULL(DELETED.strGatuadress, '') COLLATE Finnish_Swedish_CS_AS
                    OR ISNULL(INSERTED.strPostnummer, '') <> ISNULL(DELETED.strPostnummer, '') COLLATE Finnish_Swedish_CS_AS
                    OR ISNULL(INSERTED.strPostort, '') <> ISNULL(DELETED.strPostort, '') COLLATE Finnish_Swedish_CS_AS
                )
            )
        OPEN kontakt_cursor
        DECLARE @recHaendelseID INT
        FETCH NEXT FROM kontakt_cursor INTO @recHaendelseID
        WHILE (@@fetch_status = 0)
        BEGIN
            EXEC spAehHaendelseUpdateKontakt @recHaendelseID

            FETCH NEXT FROM kontakt_cursor INTO @recHaendelseID
        END
        CLOSE kontakt_cursor
        DEALLOCATE kontakt_cursor
        END
        go

