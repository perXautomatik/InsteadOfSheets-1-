CREATE VIEW [dbo].[vwAehHaendelseHandlaeggare]
AS
SELECT tbAehHaendelseUser.recHaendelseUserID, tbAehHaendelseUser.recHaendelseID,
  tbAehHaendelseUser.intUserID, tbAehHaendelseUser.bolHuvudhandlaeggare,
  tbEDPUser.strSignature
FROM  dbo.tbAehHaendelseUser
INNER JOIN dbo.tbEDPUser
  ON dbo.tbAehHaendelseUser.intUserID = dbo.tbEDPUser.intUserID
WHERE tbAehHaendelseUser.bolHuvudhandlaeggare = 1
go

