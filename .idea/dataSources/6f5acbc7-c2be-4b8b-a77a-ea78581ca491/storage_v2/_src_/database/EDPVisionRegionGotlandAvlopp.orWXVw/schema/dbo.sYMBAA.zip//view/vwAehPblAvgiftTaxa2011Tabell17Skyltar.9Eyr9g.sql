

CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell17Skyltar]
AS
SELECT [recAehPblAvgiftTaxa2011Tabell17SkyltarID],
  [recAehPblAvgiftTaxa2011Tabell17SkyltarID] AS intRecnum,
  [recAehPblAvgiftTaxa2011Tabell17ID],
  [strAatgaerd],
  [strBeskrivning],
  [intHF]
FROM [dbo].[tbAehPblAvgiftTaxa2011Tabell17Skyltar]
go

