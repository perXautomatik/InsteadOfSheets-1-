CREATE VIEW [dbo].[vwFasTidigareFastBeteckning]
AS
SELECT     recTIBET, strOTYP, strDATUMLOP, strFNRID, intLOPID, strOMDAT, strAKT, strKOMMUN, strTREGAST, strBLKVSS, strTKN, strENHET, 
                      ISNULL(strTREGAST, '') + ' ' + ISNULL(strBLKVSS, '') + ISNULL(strTKN, '') + ISNULL(strENHET, '') AS strFastighetsbeteckning, 
                      recTIBET AS intRecnum
FROM         dbo.tbFasTIBET

go

