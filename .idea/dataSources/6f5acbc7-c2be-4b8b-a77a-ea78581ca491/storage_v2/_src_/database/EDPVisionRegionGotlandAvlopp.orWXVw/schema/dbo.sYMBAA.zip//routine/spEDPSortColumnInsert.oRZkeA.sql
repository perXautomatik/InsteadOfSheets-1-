

CREATE PROCEDURE dbo.spEDPSortColumnInsert
	(
		@strTableName varchar(100),
		@strColumnName varchar(100),
		@intID int output
	)
AS

IF (SELECT COUNT(intColumnID) AS TOT FROM tbEDPSortColumn WHERE strTableName = @strTableName AND strColumnName = @strColumnName)>0
	BEGIN
	SELECT @intID =(SELECT intColumnID FROM tbEDPSortColumn WHERE strTableName = @strTableName AND strColumnName = @strColumnName)
	END
ELSE
	BEGIN
		INSERT INTO tbEDPSortColumn
													(strColumnName, strTableName)
		VALUES     (@strColumnName, @strTableName)
		
		SELECT @intID =(SCOPE_IDENTITY())
	END
RETURN


go

