
CREATE VIEW [dbo].[vwVisDeladKontakt]
AS

WITH KontaktKommunikationssaett AS (
SELECT recDeladKontaktID , 
   
    (REPLACE( (SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett
    WHERE strKommunikationsaettTyp = 'Telefon' AND recKommunikationssaettID IN 
      (SELECT recKommunikationssaettID FROM tbVisDeladKontaktKommunikationssaett 
       WHERE  dbo.tbVisDeladKontakt.recDeladKontaktID = dbo.tbVisDeladKontaktKommunikationssaett.recDeladKontaktID)
    FOR XML PATH('')) + '...', ', ...','') 
  ) AS strTelefon,

    (REPLACE( (SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett
    WHERE strKommunikationsaettTyp = 'Mobil' AND recKommunikationssaettID IN 
      (SELECT recKommunikationssaettID FROM tbVisDeladKontaktKommunikationssaett 
       WHERE  dbo.tbVisDeladKontakt.recDeladKontaktID = dbo.tbVisDeladKontaktKommunikationssaett.recDeladKontaktID)
    FOR XML PATH('')) + '...', ', ...','') 
  ) AS strMobil	,

    (REPLACE( (SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett
    WHERE strKommunikationsaettTyp = 'Fax' AND recKommunikationssaettID IN 
      (SELECT recKommunikationssaettID FROM tbVisDeladKontaktKommunikationssaett 
       WHERE  dbo.tbVisDeladKontakt.recDeladKontaktID = dbo.tbVisDeladKontaktKommunikationssaett.recDeladKontaktID)
    FOR XML PATH('')) + '...', ', ...','') 
  ) AS strFax,	

    (REPLACE( (SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett
    WHERE strKommunikationsaettTyp = 'E-post' AND recKommunikationssaettID IN 
      (SELECT recKommunikationssaettID FROM tbVisDeladKontaktKommunikationssaett 
       WHERE  dbo.tbVisDeladKontakt.recDeladKontaktID = dbo.tbVisDeladKontaktKommunikationssaett.recDeladKontaktID)
    FOR XML PATH('')) + '...', ', ...','') 
  ) AS strEpost	


FROM tbVisDeladKontakt
)


SELECT	
		tbVisDeladKontakt.recDeladKontaktID, 
		strFoernamn, 
		strEfternamn, 
		strFoeretag, 
		strOrginisationPersonnummer, 
		strTitel, 
		strKontaktTyp, 
		strGatuadress, 
		strCoadress, 
		strPostnummer, 
        strPostort, 
        strLand, 
        strVisasSom, 
        strSammanslagenAdress,
		KontaktKommunikationssaett.strTelefon,
		KontaktKommunikationssaett.strMobil,
		KontaktKommunikationssaett.strFax,
		KontaktKommunikationssaett.strEpost,
		tbVisDeladKontakt.recDeladKontaktID as intRecnum

FROM    dbo.tbVisDeladKontakt

LEFT OUTER JOIN KontaktKommunikationssaett
  ON KontaktKommunikationssaett.recDeladKontaktID = tbVisDeladKontakt.recDeladKontaktID



go

