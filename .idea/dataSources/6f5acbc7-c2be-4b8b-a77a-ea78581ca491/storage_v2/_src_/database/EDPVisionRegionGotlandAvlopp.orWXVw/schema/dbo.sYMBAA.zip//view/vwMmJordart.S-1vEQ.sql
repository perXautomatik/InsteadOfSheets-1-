CREATE VIEW dbo.vwMmJordart
AS
SELECT     dbo.tbMmJordart.recJordartID, dbo.tbMmJordart.recOmrID, dbo.tbMmJordart.strJordart, dbo.tbMmJordart.decFraanDjup, dbo.tbMmJordart.decTillDjup,
                      dbo.tbMmJordart.recJordartID AS intRecnum, dbo.vwMmOmraade.strOmraadeKod, dbo.vwMmOmraade.strOmrNamn
FROM         dbo.tbMmJordart LEFT OUTER JOIN
                      dbo.vwMmOmraade ON dbo.tbMmJordart.recOmrID = dbo.vwMmOmraade.recOmrID
go

