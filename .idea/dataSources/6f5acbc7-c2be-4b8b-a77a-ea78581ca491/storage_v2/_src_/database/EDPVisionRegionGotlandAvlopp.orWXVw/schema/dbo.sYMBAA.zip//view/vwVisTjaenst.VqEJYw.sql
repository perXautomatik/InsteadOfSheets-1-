
CREATE VIEW [dbo].[vwVisTjaenst]
AS
SELECT     
	tbVisTjaenst.recTjaenstID, 
	tbVisTjaenst.recTjaenstID as intRecnum,
	tbVisTjaenst.strTjaenstKod,
	tbVisTjaenst.strTjaenst,
	tbVisTjaenst.strBeskrivning, 
	tbVisTjaenst.recFoervaltningID, 
	tbVisTjaenst.recAvdelningID, 
	tbVisTjaenst.recEnhetID, 
	tbVisTjaenst.intMoms, 
	tbVisTjaenst.recKontoID, 
    tbVisTjaenst.bolTimTaxa,
    tbVisTjaenst.bolEjAktuell,

	tbVisKonto.strKontoKod, 
	tbVisKonto.strKontoStraeng,

	tbvisavdelning.strAvdelningKod,
	tbVisFoervaltning.strFoervaltningKod,
	tbvisenhet.strEnhetKod,

	(
		SELECT TOP(1) intPris 
		FROM tbVisTjaenstPris
		WHERE recTjaenstID = dbo.tbVisTjaenst.recTjaenstID
		AND datPrisGaellerFraan <= GetDate()
		ORDER BY datPrisGaellerFraan DESC
	) AS intPris,

	(
		SELECT TOP(1) datPrisGaellerFraan 
		FROM tbVisTjaenstPris
		WHERE recTjaenstID = dbo.tbVisTjaenst.recTjaenstID
		AND datPrisGaellerFraan <= GetDate()
		ORDER BY datPrisGaellerFraan DESC
	) AS datPrisGaellerFraan

FROM dbo.tbVisTjaenst

LEFT JOIN dbo.tbVisKonto
	ON dbo.tbVisKonto.recKontoID = dbo.tbVisTjaenst.recKontoID

LEFT JOIN tbvisavdelning
	ON tbvisavdelning.recavdelningid = tbVisTjaenst.recavdelningid
LEFT JOIN tbVisFoervaltning
	ON tbVisFoervaltning.recFoervaltningID = tbVisTjaenst.recFoervaltningID
LEFT JOIN tbvisenhet
	ON tbvisenhet.recEnhetID = tbVisTjaenst.recEnhetID

go

