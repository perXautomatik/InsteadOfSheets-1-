
CREATE VIEW [dbo].[vwVisEnstakaKontaktGrid]

--Lite komplex SQL här, använder oss av två stycken common table expressions, den första 
-- 'kommunikationSaett' används tillsammans med 'LTRIM stycket' för att slå ihop alla kommunikationsätt 
-- i en kommaseparerad lista. Den andra CTE  'kommunikationSaettUtanSistaKomma' används enbart för att kunna
-- ta bort det sista kommat för kommunikationssätt..  fick inte något smartare sätt att fungera.
As
WITH kommunikationSaett AS (
  SELECT strVisasSom, strOrginisationPersonnummer, strSammanslagenAdress, strKommunikationsaettTyp, strVaerde, tbVisEnstakaKontakt.recEnstakaKontaktID, tbVisEnstakaKontakt.recEnstakaKontaktID as intRecnum
	
  FROM tbVisEnstakaKontakt 
	LEFT OUTER JOIN dbo.tbVisEnstakaKontaktKommunikationssaett
	ON dbo.tbVisEnstakaKontaktKommunikationssaett.recEnstakaKontaktID = tbVisEnstakaKontakt.recEnstakaKontaktID
	LEFT OUTER JOIN dbo.tbVisKommunikationssaett
	ON dbo.tbVisEnstakaKontaktKommunikationssaett.recKommunikationssaettID = dbo.tbVisKommunikationssaett.recKommunikationssaettID
)
,
kommunikationSaettUtanSistaKomma as (SELECT strVisasSom,strOrginisationPersonnummer, strSammanslagenAdress, recEnstakaKontaktID,
 LTRIM((SELECT ' ' + strKommunikationsaettTyp + ' - ' + strVaerde + ','
  FROM kommunikationSaett AS K2
  WHERE K2.recEnstakaKontaktID = K1.recEnstakaKontaktID
  FOR XML PATH('')))  AS strKommunikationssaett 
FROM kommunikationSaett AS K1
GROUP BY strOrginisationPersonnummer, strVisasSom, strSammanslagenAdress, recEnstakaKontaktID
)

Select strVisasSom, strOrginisationPersonnummer, strSammanslagenAdress,  recEnstakaKontaktID,
	CASE strKommunikationssaett
		WHEN '' then NULL
		ELSE LEFT( strKommunikationssaett ,  LEN(strKommunikationssaett) - 1 )
	END as strKommunikationssaett
FROM kommunikationSaettUtanSistaKomma



go

