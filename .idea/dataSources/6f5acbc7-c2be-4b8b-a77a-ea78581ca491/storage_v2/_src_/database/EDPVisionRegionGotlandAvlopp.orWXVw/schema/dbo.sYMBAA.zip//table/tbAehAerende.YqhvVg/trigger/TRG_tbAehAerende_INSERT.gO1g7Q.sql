
        CREATE TRIGGER TRG_tbAehAerende_INSERT ON tbAehAerende
        AFTER INSERT
        AS
        BEGIN
        SET NOCOUNT ON;

        --- Skapa ny(a) post(er) i tbAehAerendeData ---
        INSERT INTO tbAehAerendeData (recAerendeID)
        SELECT recAerendeID FROM INSERTED

        DECLARE aerende_insert_cursor CURSOR FAST_FORWARD
        FOR
        SELECT recAerendeID FROM INSERTED
        OPEN aerende_insert_cursor
        DECLARE @recAerendeID as INT
        FETCH NEXT FROM aerende_insert_cursor INTO @recAerendeID
        WHILE (@@fetch_status = 0)
        BEGIN
            EXEC spAehAerendeDataUpdate @recAerendeID

            FETCH NEXT FROM aerende_insert_cursor INTO @recAerendeID
        END
        CLOSE aerende_insert_cursor
        DEALLOCATE aerende_insert_cursor
        END
        go

