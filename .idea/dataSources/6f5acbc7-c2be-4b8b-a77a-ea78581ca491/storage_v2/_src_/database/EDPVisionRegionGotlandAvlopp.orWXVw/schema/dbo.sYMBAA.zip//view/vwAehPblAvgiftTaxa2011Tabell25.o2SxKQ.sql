
CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell25]
AS
SELECT
  dbo.tbAehPblAvgiftTaxa2011Tabell25.recPblAvgiftTaxa2011Tabell25ID, 
	dbo.tbAehPblAvgiftTaxa2011Tabell25.recPblAvgiftTaxa2011Tabell25ID AS intRecnum,
	dbo.tbAehPblAvgiftTaxa2011Tabell25.recAvgiftID, 
	dbo.tbAehPblAvgiftTaxa2011Tabell25.decAvgift, 
	dbo.tbAehPblAvgiftTaxa2011Tabell25.intMF, 
	dbo.tbAehPblAvgiftTaxa2011Tabell25.decmPBB, 
	dbo.tbAehPblAvgiftTaxa2011Tabell25.decN, 
	dbo.tbAehPblAvgiftTaxa2011Tabell25.bolDebiterad
FROM dbo.tbAehPblAvgiftTaxa2011Tabell25

go

