


CREATE VIEW [dbo].[vwVisEnstakaFastighetLagfarenAegare]
AS
SELECT     
	dbo.tbVisEnstakaFastighetLagfarenAegare.recEnstakaFastighetLagfarenAegareID, 
    dbo.tbVisEnstakaFastighetLagfarenAegare.recEnstakaFastighetLagfarenAegareID AS intRecnum, 

    dbo.tbVisEnstakaFastighetLagfarenAegare.recFastighetID, 

	dbo.tbVisEnstakaFastighetLagfarenAegare.strNamn, 
    dbo.tbVisEnstakaFastighetLagfarenAegare.strPnr, 
    dbo.tbVisEnstakaFastighetLagfarenAegare.strCO, 
	dbo.tbVisEnstakaFastighetLagfarenAegare.strAdress, 
    dbo.tbVisEnstakaFastighetLagfarenAegare.strAdress2, 
    dbo.tbVisEnstakaFastighetLagfarenAegare.strPostnr, 
	dbo.tbVisEnstakaFastighetLagfarenAegare.strOrt, 
    dbo.tbVisEnstakaFastighetLagfarenAegare.strLand, 
    dbo.tbVisEnstakaFastighetLagfarenAegare.strFaang, 
	dbo.tbVisEnstakaFastighetLagfarenAegare.strAndel, 
    dbo.tbVisEnstakaFastighetLagfarenAegare.strKommun, 
    
    dbo.tbVisEnstakaFastighet.strFnrID, 
    dbo.tbVisEnstakaFastighet.strBlock, 
	dbo.tbVisEnstakaFastighet.strTkn, 
	dbo.tbVisEnstakaFastighet.intEnhet, 
    dbo.tbVisEnstakaFastighet.strTrakt,
    dbo.tbVisEnstakaFastighet.strFastighetsbeteckning
        
FROM dbo.tbVisEnstakaFastighetLagfarenAegare
LEFT OUTER JOIN  dbo.tbVisEnstakaFastighet 
	ON dbo.tbVisEnstakaFastighetLagfarenAegare.recFastighetID= dbo.tbVisEnstakaFastighet.recFastighetID



go

