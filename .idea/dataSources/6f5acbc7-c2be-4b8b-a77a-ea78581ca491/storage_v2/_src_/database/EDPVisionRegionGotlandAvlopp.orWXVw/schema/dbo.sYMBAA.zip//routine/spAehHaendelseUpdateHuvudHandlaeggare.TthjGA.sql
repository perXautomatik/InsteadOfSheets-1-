CREATE PROCEDURE [dbo].[spAehHaendelseUpdateHuvudHandlaeggare]
  @recHaendelseID int
AS
BEGIN
  SET NOCOUNT ON;

  UPDATE dbo.tbAehHaendelseData SET
    strSignature = dbo.tbEDPUser.strSignature,
    intUserID = dbo.tbEDPUser.intUserID
  FROM dbo.tbAehHaendelseData
  LEFT OUTER JOIN dbo.tbAehHaendelseUser
    ON dbo.tbAehHaendelseUser.recHaendelseID = dbo.tbAehHaendelseData.recHaendelseID
    AND tbAehHaendelseUser.bolHuvudhandlaeggare = 1
  LEFT OUTER JOIN dbo.tbEDPUser 
    ON dbo.tbAehHaendelseUser.intUserID = dbo.tbEDPUser.intUserID
  WHERE dbo.tbAehHaendelseData.recHaendelseID = @recHaendelseID
END
go

