



CREATE PROCEDURE dbo.spEDPGetRolesByUserID
	@intUserID int
AS
SELECT     tbEDPRole.intRoleID, tbEDPRole.intRoleParentID, tbEDPRoleUser.intPriority
	                    FROM         tbEDPRoleUser INNER JOIN
	                                          tbEDPRole ON tbEDPRoleUser.intRoleID = tbEDPRole.intRoleID
	                    WHERE     (tbEDPRoleUser.intUserID = @intUserID)
	                    ORDER BY tbEDPRoleUser.intPriority
RETURN



go

