CREATE VIEW dbo.vwMifoObjektSpridningsfoerutsaettningar
AS
SELECT     dbo.tbMifoSpridningsfoerutsaettningar.recSpridningsfoerutsaettningarID, dbo.tbMifoSpridningsfoerutsaettningar.recObjektID,
                      dbo.tbMifoSpridningsfoerutsaettningar.strMedium, dbo.tbMifoSpridningsfoerutsaettningar.strSpridningsfoerutsaettningar,
                      dbo.tbMifoSpridningsfoerutsaettningar.strXellerAemne, dbo.tbMifoObjekt.strObjektId, dbo.tbMifoObjekt.strObjektNamn,
                      dbo.tbMifoSpridningsfoerutsaettningar.recSpridningsfoerutsaettningarID AS intRecnum
FROM         dbo.tbMifoObjekt RIGHT OUTER JOIN
                      dbo.tbMifoSpridningsfoerutsaettningar ON dbo.tbMifoObjekt.recObjektID = dbo.tbMifoSpridningsfoerutsaettningar.recObjektID
go

