


CREATE VIEW [dbo].[vwTrVeBesiktning]
AS

SELECT		dbo.tbTrVeBesiktning.recBesiktningID, 
			dbo.tbTrVeBesiktning.recBesiktningID AS intRecNum, 
			dbo.tbTrVeBesiktning.recVentilationsaggregatID,
			dbo.tbTrTillsynsobjekt.recTillsynsobjektID,	
			dbo.tbTrTillsynsobjekt.strObjektsNamn,	
			dbo.tbTrVeVentilationsaggregat.strAggregat,	
			dbo.tbTrVeBesiktning.datBesiktningsdatum, 
			dbo.tbTrVeBesiktning.strBesiktningstyp, 
			dbo.tbTrVeBesiktning.strBesiktningGodkaend, 
			dbo.tbTrVeBesiktning.datOmbesiktning, 
			dbo.tbTrVeBesiktning.recSakkunnigID,
			dbo.tbVisEnstakaKontakt.strVisasSom AS strBesiktningsmanVisasSom 

FROM		dbo.tbTrVeBesiktning
LEFT OUTER JOIN	dbo.tbTrVeVentilationsaggregat 
	ON dbo.tbTrVeVentilationsaggregat.recVentilationsaggregatID = dbo.tbTrVeBesiktning.recVentilationsaggregatID
LEFT OUTER JOIN   dbo.tbTrTillsynsobjekt 
	ON dbo.tbTrTillsynsobjekt.recTillsynsobjektID = dbo.tbTrVeVentilationsaggregat.recTillsynsobjektID
LEFT OUTER JOIN   dbo.tbTrSakkunnig 
	ON dbo.tbTrSakkunnig.recSakkunnigID = dbo.tbTrVeBesiktning.recSakkunnigID
LEFT OUTER JOIN    dbo.tbVisEnstakaKontakt 
	ON dbo.tbVisEnstakaKontakt.recEnstakaKontaktID = dbo.tbTrSakkunnig.recEnstakaKontaktID



go

