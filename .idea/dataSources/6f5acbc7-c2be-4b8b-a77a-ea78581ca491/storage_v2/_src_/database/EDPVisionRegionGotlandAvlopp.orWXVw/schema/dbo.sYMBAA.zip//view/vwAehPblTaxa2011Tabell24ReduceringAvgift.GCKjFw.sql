




CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell24ReduceringAvgift]
AS
SELECT     

tbAehPblTaxa2011Tabell24ReduceringAvgift.recTabell24ID, 
recReduceringAvgiftID, 
recReduceringAvgiftID as 'intRecnum', 
strAatgaerd,
strBeskrivning,
recTaxa2011ID,
intProcent
	
FROM dbo.tbAehPblTaxa2011Tabell24ReduceringAvgift
LEFT OUTER JOIN vwAehPblTaxa2011Tabell24 
ON vwAehPblTaxa2011Tabell24.recTabell24ID = tbAehPblTaxa2011Tabell24ReduceringAvgift.recTabell24ID


go

