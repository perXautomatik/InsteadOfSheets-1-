CREATE VIEW dbo.vwFasAvregTillEnhet
AS
SELECT     dbo.tbFasAVREGBET.recAVREGBET, dbo.tbFasAVREGBET.strOTYP, dbo.tbFasAVREGBET.strDATUMLOP, dbo.tbFasAVREGBET.strFNRID, 
                      dbo.tbFasAVREGBET.strAFNRID, dbo.tbFasAVREGBET.recAVREGBET AS intRecnum, dbo.vwFasFastighet.strFastighetsbeteckning, 
                      dbo.vwFasFastighet.strKOMMUN
FROM         dbo.tbFasAVREGBET LEFT OUTER JOIN
                      dbo.vwFasFastighet ON dbo.tbFasAVREGBET.strFNRID = dbo.vwFasFastighet.strFNRID
go

