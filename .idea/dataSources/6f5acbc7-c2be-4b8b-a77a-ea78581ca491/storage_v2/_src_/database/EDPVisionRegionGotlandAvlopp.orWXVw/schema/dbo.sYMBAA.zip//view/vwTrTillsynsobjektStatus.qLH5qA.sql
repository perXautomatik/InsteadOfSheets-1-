CREATE VIEW [dbo].[vwTrTillsynsobjektStatus]
AS
SELECT
dbo.tbTrTillsynsobjektStatus.recTillsynsobjektStatusID as intRecnum,
dbo.tbTrTillsynsobjektStatus.recTillsynsobjektStatusID,
dbo.tbTrTillsynsobjektStatus.strStatus,
dbo.tbTrTillsynsobjektStatus.datDatum,
dbo.tbTrTillsynsobjektStatus.strKommentar,
dbo.tbTrTillsynsobjektStatus.recTillsynsobjektID,
dbo.tbTrTillsynsobjektStatus.intUserID,
dbo.tbTrTillsynsobjektStatus.recStatusID,
dbo.tbEDPUser.strSignature

FROM 
dbo.tbTrTillsynsobjektStatus

LEFT OUTER JOIN	
dbo.tbEDPUser 
ON dbo.tbEDPUser.intUserID = dbo.tbTrTillsynsobjektStatus.intUserID
go

