

CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell17Skyltar]
AS
SELECT     tbAehPblTaxa2011Tabell17Skyltar.recTabell17ID, 
           recSkyltarID as 'intRecnum', 
		   recSkyltarID,
		   strAatgaerd,
		   recTaxa2011ID,
		   strBeskrivning,
		   intHF

FROM         dbo.tbAehPblTaxa2011Tabell17Skyltar
LEFT OUTER JOIN vwAehPblTaxa2011Tabell17 
ON vwAehPblTaxa2011Tabell17.recTabell17ID = tbAehPblTaxa2011Tabell17Skyltar.recTabell17ID



go

