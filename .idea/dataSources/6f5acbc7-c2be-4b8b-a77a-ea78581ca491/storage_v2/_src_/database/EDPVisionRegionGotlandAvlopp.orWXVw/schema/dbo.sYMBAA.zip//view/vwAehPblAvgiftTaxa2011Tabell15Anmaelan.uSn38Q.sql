


CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell15Anmaelan]
AS
SELECT		  recPblAvgiftTaxa2011Tabell15AnmaelanID
			, recPblAvgiftTaxa2011Tabell15AnmaelanID as 'intRecnum'
			, recPblAvgiftTaxa2011Tabell15ID
			, strObjekt
			, strBeskrivning
			, intHF
FROM   dbo.tbAehPblAvgiftTaxa2011Tabell15Anmaelan

go

