
CREATE VIEW [dbo].[vwTrTillsynsobjektHuvudverksamhetutoevare]
AS

SELECT 
	tbTrTillsynsobjektDeladKontakt.recTillsynsobjektID
	, tbTrTillsynsobjektDeladKontakt.strRoll
	, vwVisDeladKontakt.* 
FROM tbTrTillsynsobjektDeladKontakt 
	INNER JOIN vwVisDeladKontakt ON vwVisDeladKontakt.recDeladKontaktID = tbTrTillsynsobjektDeladKontakt.recDeladKontaktID
WHERE 
	bolHuvudverksamhetsutoevare = 1 AND strRoll = 'Verksamhetsutövare'



go

