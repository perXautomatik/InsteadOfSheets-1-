
CREATE PROCEDURE dbo.spGettbEDPRegister
/* $Date: 2005-10-20 12:22:20+02:00 $ */
AS

SELECT strTableName, strTableCaption 
FROM tbEDPRegister
ORDER BY intOrder ASC, strTableCaption ASC

go

