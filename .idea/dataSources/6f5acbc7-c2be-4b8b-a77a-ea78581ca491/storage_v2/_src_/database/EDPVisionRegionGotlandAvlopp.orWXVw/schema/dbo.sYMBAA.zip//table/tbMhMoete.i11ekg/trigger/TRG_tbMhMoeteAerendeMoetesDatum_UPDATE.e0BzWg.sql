
        CREATE TRIGGER TRG_tbMhMoeteAerendeMoetesDatum_UPDATE ON
        tbMhMoete
        AFTER  UPDATE
        AS
        UPDATE tbAehAerende
        SET datMoetesDatum = (SELECT INSERTED.datMoetesDatum FROM  INSERTED)
        WHERE tbAehAerende.recAerendeID in(SELECT a.recAerendeID from tbAehAerende A
        inner join tbMhMoetespunktAerende MPA On MPA.recAerendeID = A.recAerendeID
        inner join tbMhMoetespunkt P on P.recMoetespunktID = MPA.recMoetespunktID
        inner join tbMhMoete M on M.recMoeteID = P.recMoeteID
        WHERE M.recMoeteID = (SELECT INSERTED.recMoeteID FROM  INSERTED))
        go

