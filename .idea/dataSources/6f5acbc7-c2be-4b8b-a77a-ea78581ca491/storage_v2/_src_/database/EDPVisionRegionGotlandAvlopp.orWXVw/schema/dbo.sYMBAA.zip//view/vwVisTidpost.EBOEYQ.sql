

CREATE VIEW [dbo].[vwVisTidpost]
AS
SELECT 
		tbVisTidpost.recTidpostID, 
		tbVisTidpost.intMinuter, 
		tbVisTidpost.datUtfoerandeFraan, 
		tbVisTidpost.datUtfoerandeTill, 
		tbVisTidpost.bolDebiteras, 
		tbVisTidpost.recDebiteringID, 
		tbVisTidpost.intUserID, 
		tbVisTidpost.recAvdelningID, 
		tbVisTidpost.recEnhetID, 
		tbVisTidpost.recAerendeID, 
		tbVisTidpost.recTillsynsobjektID, 
		tbVisTidpost.recVerksamhetsomraadeID, 
		tbVisTidpost.recAktivitetID, 
		tbVisTidpost.recProjektID, 
		tbVisTidpost.strAnteckning,
		tbVisTidpost.recHaendelseID,
		tbVisTidpost.recKategoriID,
		tbVisTidpost.strTid,
		tbVisTidpost.recTidpostID AS intRecnum,
		
		vwVisHandlaeggareEDPUser.strSignature, 
		vwVisHandlaeggareEDPUser.strFullName,
		
		tbVisAvdelning.strAvdelningKod, 
		tbVisAvdelning.strAvdelningNamn, 
		
		tbVisEnhet.strEnhetKod, 
		tbVisEnhet.strEnhetNamn,
		
		tbTrVerksamhet.recVerksamhetID,
		tbTrVerksamhet.strVerksamhetNamn,

		tbAehAerendeData.strDiarienummer, 
		
		tbTrTillsynsobjekt.strObjektsNamn,
		tbTrTillsynsobjekt.intTidsskuld,
		(SELECT TOP 1 strFastighetsbeteckning FROM tbVisDeladFastighet WHERE strFnrID = 
		  (SELECT TOP 1 strFnrID FROM tbTrTillsynsobjektFastighet WHERE recTillsynsobjektID = tbVisTidpost.recTillsynsobjektID AND bolHuvudFastighet = 1)) AS strHuvudfastighetFastighetsbeteckning,
		tbTrTillsynsobjekt.decJusteradKontrolltid,
		
		tbVisVerksamhetsomraade.strVerksamhetsomraade,
		
		tbVisAktivitet.strAktivitet, 
		
		tbAehProjekt.strProjektnamn,
		
		vwAehHaendelse.strHaendelseIdentifiering,
		
		tbVisKategori.strKategori,
		
		vwVisDebitering.strUFIC,
		
		CASE WHEN tbVisTidpost.recDebiteringID IS NULL THEN CAST(0 AS bit) ELSE CAST(1 AS bit) END AS bolHasDebitering,

		tbVisTidpost.intMinuter / 60 AS antalTimmar,
		tbVisTidpost.intMinuter % 60 as antalMinuter,

		CAST(tbTrTillsynsobjekt.decJusteradKontrolltid * 60 AS INTEGER) AS JusteradKontrolltidMinuter
		
FROM tbVisTidpost

LEFT OUTER JOIN vwVisHandlaeggareEDPUser
  ON vwVisHandlaeggareEDPUser.intUserID = tbVisTidpost.intUserID
  
LEFT OUTER JOIN tbVisAvdelning
  ON tbVisAvdelning.recAvdelningID = tbVisTidpost.recAvdelningID
  
LEFT OUTER JOIN tbVisEnhet
  ON tbVisEnhet.recEnhetID = tbVisTidpost.recEnhetID
  
LEFT OUTER JOIN tbAehAerendeData
  ON tbAehAerendeData.recAerendeID = tbVisTidpost.recAerendeID
  
LEFT OUTER JOIN tbVisVerksamhetsomraade
  ON tbVisVerksamhetsomraade.recVerksamhetsomraadeID = tbVisTidpost.recVerksamhetsomraadeID
  
LEFT OUTER JOIN tbVisAktivitet
  ON tbVisAktivitet.recAktivitetID = tbVisTidpost.recAktivitetID
  
LEFT OUTER JOIN tbAehProjekt
  ON tbAehProjekt.recProjektID = tbVisTidpost.recProjektID
  
LEFT OUTER JOIN tbTrTillsynsobjekt
  ON tbTrTillsynsobjekt.recTillsynsobjektID = tbVisTidpost.recTillsynsobjektID
  
LEFT OUTER JOIN vwAehHaendelse
  ON vwAehHaendelse.recHaendelseID = tbVisTidpost.recHaendelseID
  
LEFT OUTER JOIN tbVisKategori
  ON tbVisKategori.recKategoriID = tbVisTidpost.recKategoriID

LEFT OUTER JOIN tbTrVerksamhet
  ON tbTrVerksamhet.recVerksamhetID = tbTrTillsynsobjekt.recVerksamhetID

LEFT OUTER JOIN vwVisDebitering
ON vwVisDebitering.recDebiteringID = tbVisTidpost.recdebiteringID

go

