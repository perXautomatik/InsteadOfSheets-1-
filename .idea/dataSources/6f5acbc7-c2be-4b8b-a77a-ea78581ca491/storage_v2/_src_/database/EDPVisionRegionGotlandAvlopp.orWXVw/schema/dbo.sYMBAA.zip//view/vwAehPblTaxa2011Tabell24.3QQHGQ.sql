



CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell24]
AS
SELECT     

recTabell24ID, 
recTaxa2011ID, 
recTabell24ID as 'intRecnum', 
dbo.tbAehPblTaxa2011Tabell24.recTjaenstID,
dbo.tbAehPblTaxa2011Tabell24.recFakturatextID,
strFritext,
decMoms,
	dbo.tbVisTjaenst.strTjaenstKod,
	dbo.tbVisTjaenst.strTjaenst,
	dbo.tbVisFakturatext.strFakturatextkod
	
FROM dbo.tbAehPblTaxa2011Tabell24

	LEFT OUTER JOIN dbo.tbVisFakturatext
	ON dbo.tbVisFakturatext.recFakturatextID = dbo.tbAehPblTaxa2011Tabell24.recFakturatextID
	
	LEFT OUTER JOIN dbo.tbVisTjaenst
	ON dbo.tbVisTjaenst.recTjaenstID = dbo.tbAehPblTaxa2011Tabell24.recTjaenstID



go

