

CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell27MarkeringInmaetning]
AS
SELECT	recPblAvgiftTaxa2011Tabell27MarkeringInmaetningID,
		recPblAvgiftTaxa2011Tabell27MarkeringInmaetningID as 'intRecnum', 
		recPblAvgiftTaxa2011Tabell27ID, 
		strObjekt, 
		strBeskrivning, 
		intMF
FROM	dbo.tbAehPblAvgiftTaxa2011Tabell27MarkeringInmaetning


go

