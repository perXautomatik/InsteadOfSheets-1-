
CREATE VIEW [dbo].[vwVisSekretess]
AS
SELECT		dbo.tbVisSekretess.recSekretessID,
			dbo.tbVisSekretess.recSekretessID AS intRecNum,
			dbo.tbVisSekretess.strSekretess,
			dbo.tbVisSekretess.strText,
			dbo.tbVisSekretess.bolEjAktuell
FROM		dbo.tbVisSekretess

go

