


CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell23Nybyggnadskarta]
AS
SELECT     

recNybyggnadskartaID, 
tbAehPblTaxa2011Tabell23Nybyggnadskarta.recTabell23ID, 
recNybyggnadskartaID as 'intRecnum', 
strAatgaerd,
strBeskrivning,
recTaxa2011ID,
intNKF
	
FROM dbo.tbAehPblTaxa2011Tabell23Nybyggnadskarta
LEFT OUTER JOIN vwAehPblTaxa2011Tabell23 
ON vwAehPblTaxa2011Tabell23.recTabell23ID = tbAehPblTaxa2011Tabell23Nybyggnadskarta.recTabell23ID

go

