
CREATE VIEW [dbo].[vwAehPblAvgiftTaxa2011Tabell15]
AS
SELECT
  dbo.tbAehPblAvgiftTaxa2011Tabell15.recPblAvgiftTaxa2011Tabell15ID,
  dbo.tbAehPblAvgiftTaxa2011Tabell15.recPblAvgiftTaxa2011Tabell15ID AS intRecnum,
  dbo.tbAehPblAvgiftTaxa2011Tabell15.decN,
  dbo.tbAehPblAvgiftTaxa2011Tabell15.decmPBB,
  dbo.tbAehPblAvgiftTaxa2011Tabell15.intHF,
  dbo.tbAehPblAvgiftTaxa2011Tabell15.decAvgift,
  dbo.tbAehPblAvgiftTaxa2011Tabell15.bolHandlaeggningsfaktor,
  dbo.tbAehPblAvgiftTaxa2011Tabell15.bolTidsersaettning,
  dbo.tbAehPblAvgiftTaxa2011Tabell15.bolDebiterad,
  dbo.tbAehPblAvgiftTaxa2011Tabell15.recAvgiftID
FROM dbo.tbAehPblAvgiftTaxa2011Tabell15

go

