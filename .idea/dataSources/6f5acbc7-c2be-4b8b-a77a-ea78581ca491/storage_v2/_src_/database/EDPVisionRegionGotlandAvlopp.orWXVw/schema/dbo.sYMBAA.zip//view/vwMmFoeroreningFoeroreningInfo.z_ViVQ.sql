CREATE VIEW dbo.vwMmFoeroreningFoeroreningInfo
AS
SELECT     dbo.tbMmFoerorening.recFoeroreningID, dbo.tbMmFoerorening.recOmrID, dbo.tbMmFoerorening.recMediumID,
                      dbo.tbMmFoerorening.strFoeroreningNamn, dbo.tbMmFoerorening.intProvantal, dbo.tbMmFoerorening.strBeskrivning,
                      dbo.tbMmFoeroreningInfo.recFoeroreningInfoID, dbo.tbMmFoeroreningInfo.recFasID, dbo.tbMmFoeroreningInfo.decVolym,
                      dbo.tbMmFoeroreningInfo.decYta, dbo.tbMmFoeroreningInfo.decFraanDjup, dbo.tbMmFoeroreningInfo.decTillDjup, dbo.tbMmFas.intOrdningsNr,
                      dbo.tbMmFas.strFasNamn, dbo.tbMmBedoemningVaerde.strBedoemningVaerde, dbo.tbMmFoerorening.recFoeroreningID AS intRecnum,
                      dbo.tbMmMedium.strMediumNamn, dbo.tbMmFoeroreningInfo.strEnhetVolym, dbo.tbMmBedoemningVaerde.intBedoemningVaerdeFaergARGB,
                      dbo.tbMmFoerorening.intFoeroreningNr, dbo.tbMmFoeroreningInfo.guidBedoemningVaerdeID, dbo.tbMmFoerorening.strKaenslighet
FROM         dbo.tbMmBedoemningVaerde RIGHT OUTER JOIN
                      dbo.tbMmFoeroreningInfo ON
                      dbo.tbMmBedoemningVaerde.guidBedoemningVaerdeID = dbo.tbMmFoeroreningInfo.guidBedoemningVaerdeID RIGHT OUTER JOIN
                      dbo.tbMmFoerorening ON dbo.tbMmFoeroreningInfo.recFoeroreningID = dbo.tbMmFoerorening.recFoeroreningID LEFT OUTER JOIN
                      dbo.tbMmFas ON dbo.tbMmFas.recFasID = dbo.tbMmFoeroreningInfo.recFasID LEFT OUTER JOIN
                      dbo.tbMmMedium ON dbo.tbMmFoerorening.recMediumID = dbo.tbMmMedium.recMediumID
WHERE     (dbo.tbMmFoeroreningInfo.recFoeroreningInfoID IN
                          (SELECT     FI.recFoeroreningInfoID
                            FROM          dbo.tbMmFas AS FAS INNER JOIN
                                                   dbo.tbMmFoeroreningInfo AS FI ON FAS.recFasID = FI.recFasID
                            WHERE      (FAS.recFasID =
                                                       (SELECT     TOP (1) tbMmFas_1.recFasID
                                                         FROM          dbo.tbMmFas AS tbMmFas_1 INNER JOIN
                                                                                dbo.tbMmFoeroreningInfo AS tbMmFoeroreningInfo_1 ON tbMmFas_1.recFasID = tbMmFoeroreningInfo_1.recFasID AND
                                                                                tbMmFoeroreningInfo_1.recFoeroreningID = FI.recFoeroreningID
                                                         ORDER BY tbMmFas_1.intOrdningsNr DESC)))) OR
                      (dbo.tbMmFoeroreningInfo.recFoeroreningInfoID IS NULL)
go

