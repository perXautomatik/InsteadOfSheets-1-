



CREATE PROCEDURE [dbo].[spEDPGetPropertyByRoleIDObjectID]
		@intUserID int,
		@intRoleID int,
		@intObjectID int
AS
	
SELECT     dbo.tbEDPObject.strObjectName, dbo.tbEDPPropertyTemplate.strPropertyTemplateName, dbo.tbEDPRoleUser.intPriority AS intRolePriority, 
                      dbo.tbEDPRoleObjectProperty.strPropertyValue, dbo.tbEDPObjectType.strObjectTypeName, dbo.tbEDPObject.intSortOrder,
                      dbo.tbEDPRoleObjectProperty.bolChangedByUser
FROM         dbo.tbEDPRoleObjectProperty INNER JOIN
                      dbo.tbEDPObject ON dbo.tbEDPRoleObjectProperty.intObjectID = dbo.tbEDPObject.intObjectID INNER JOIN
                      dbo.tbEDPRoleUser ON dbo.tbEDPRoleObjectProperty.intRoleID = dbo.tbEDPRoleUser.intRoleID INNER JOIN
                      dbo.tbEDPPropertyTemplate ON dbo.tbEDPRoleObjectProperty.intPropertyTemplateID = dbo.tbEDPPropertyTemplate.intPropertyTemplateID INNER JOIN
                      dbo.tbEDPObjectType ON dbo.tbEDPObject.intObjectTypeID = dbo.tbEDPObjectType.intObjectTypeID	WHERE   (tbEDPRoleObjectProperty.intRoleID = @intRoleID) AND (tbEDPRoleObjectProperty.intObjectID = @intObjectID) AND (tbEDPRoleUser.intUserID = @intUserID)
	
	RETURN

go

