

CREATE VIEW [dbo].[vwTrFtTobak]
AS
SELECT       recTobakID
			,recTobakID as intRecnum
			,recTillsynsobjektID
			,datAnmaelningsdatum
			,datFoersaeljningsstart
			,datFoersaeljningUpphoert
			,bolTobaksobjekt
			,
			
			CASE 
				WHEN (SELECT TOP(1) strHuvudflik FROM tbTrTillsynsobjektHuvudflik 
						WHERE recTillsynsobjektID  = dbo.tbTrFtTobak.recTillsynsobjektID 
						ORDER BY recTillsynsobjektHuvudflikID ASC) = 'TRTobak' THEN 
					CAST(1 as bit)
				ELSE 
					CAST(0 as bit)
			END AS bolHuvudflik				
			
FROM            dbo.tbTrFtTobak



go

