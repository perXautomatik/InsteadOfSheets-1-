-- =============================================
-- Author:		Ola Rönnerup, Malin Westman
-- Create date: 2009-01-05
-- Description:	Used by Vision Kontakter to fetch parents. A simular exists for fetching childs.
-- =============================================
CREATE PROCEDURE [dbo].[spVisGetContactChildren] (
	@id INTEGER = NULL
)
AS
  -- ERROR HANDLING
  IF @id IS NULL
    BEGIN
      PRINT 'ERROR: First param "id" must be specified and can not be NULL.'
      RETURN(1)
    END
  -- NO ERROR
  BEGIN
    -- SAVE TIME
	SET NOCOUNT ON;
		
		SELECT
	  tmp.recKontaktRelationID AS intRecnum,
	  tmp.intChild AS intChild,
	  h2.strFoernamn AS strFirstname,
	  h2.strEfternamn AS strLastname,
	  roll.strRoleName,
	  roll.intRoleID,
	  h2.strKontaktTyp,
	  h2.recKontaktTypID
	FROM
		 (SELECT relation.recKontaktRelationID,
				 h1.strFoernamn AS firstname,
				 h1.strEfternamn AS lastname,
				 relation.intChild,
				 relation.intParent,
				 relation.intParentRole,
				 relation.intChildRole
		  FROM dbo.tbVisKontaktRelation AS relation INNER JOIN
			   dbo.vwVisKontakt AS h1 ON h1.recKontaktID = relation.intParent) AS tmp 
	INNER JOIN dbo.vwVisKontakt AS h2 ON h2.recKontaktID = tmp.intChild
	INNER JOIN dbo.tbVisKontaktRelationRoll As roll ON roll.intRoleID = tmp.intChildRole
    -- FILTER ON THE SUPPLIED ID
	WHERE tmp.intParent = @id;

    RETURN(0)
  END
go

