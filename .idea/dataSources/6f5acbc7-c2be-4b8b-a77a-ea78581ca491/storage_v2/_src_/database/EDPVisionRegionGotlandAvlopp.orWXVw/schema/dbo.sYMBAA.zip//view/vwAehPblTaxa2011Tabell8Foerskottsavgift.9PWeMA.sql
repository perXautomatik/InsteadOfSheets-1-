
CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell8Foerskottsavgift]
AS
SELECT     tbAehPblTaxa2011Tabell8Foerskottsavgift.recTabell8ID, 
           recFoerskottsavgiftID as 'intRecnum', 
		   recFoerskottsavgiftID,
		   strAatgaerd,
		  strBeskrivning,
		  recTaxa2011ID,
		  intProcent
FROM         dbo.tbAehPblTaxa2011Tabell8Foerskottsavgift
LEFT OUTER JOIN vwAehPblTaxa2011Tabell8
ON vwAehPblTaxa2011Tabell8.recTabell8ID = tbAehPblTaxa2011Tabell8Foerskottsavgift.recTabell8ID

go

