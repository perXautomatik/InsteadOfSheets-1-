

CREATE VIEW [dbo].[vwTrLiUtbrott]
AS
SELECT		tbTrLiUtbrott.recUtbrottID, 
			tbTrLiUtbrott.recUtbrottID as intRecnum,
			tbTrLiUtbrott.strRapporteringsID, 
			datUtbrottsdatum,
			tbTrLiUtbrottagens.strAgens, 
			strAgensOevrigt, 
			strIsolatAgens, 
			strIsolatPlats, 
			strUtpekatLivsmedel, 
			strLivsmedelskategori, 
			strPlats, 
			strAetplats, 
            strUrsprungsland, 
			strBidragandeFaktorer,
			strEpievidens, 
			strTidFoerUtredning,
			strOevrigt, 
			intAntalBeroerda,
			intAntalInlagda, 
			intAntalSjuka, 
			intAntalAvlidna, 
            tbTrLiUtbrott.recLivsmedelID, 
			tbTrTillsynsobjekt.strObjektsNamn,
			tbTrTillsynsobjekt.recTillsynsobjektID
FROM         dbo.tbTrLiUtbrott

LEFT OUTER JOIN dbo.tbTrLiLivsmedel
ON tbTrLiLivsmedel.recLivsmedelID = tbTrLiUtbrott.recLivsmedelID
LEFT OUTER JOIN dbo.tbTrTillsynsobjekt
ON tbTrLiLivsmedel.recTillsynsobjektID = tbTrTillsynsobjekt.recTillsynsobjektID
LEFT OUTER JOIN (SELECT * FROM tbTrLiUtbrottagens WHERE tbTrLiUtbrottagens.bolHuvud = 1) as tbTrLiUtbrottagens
ON tbTrLiUtbrottagens.recUtbrottID = tbTrLiUtbrott.recUtbrottID



go

