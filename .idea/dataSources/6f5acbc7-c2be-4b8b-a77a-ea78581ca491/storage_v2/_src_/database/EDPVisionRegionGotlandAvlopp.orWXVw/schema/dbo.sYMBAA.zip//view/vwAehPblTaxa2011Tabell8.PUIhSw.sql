
CREATE VIEW [dbo].[vwAehPblTaxa2011Tabell8]
AS
SELECT     

recTabell8ID, 
recTaxa2011ID, 
recTabell8ID as 'intRecnum', 
dbo.tbAehPblTaxa2011Tabell8.recTjaenstID,
dbo.tbAehPblTaxa2011Tabell8.recFakturatextID,
strFritext,
decMoms,
	dbo.tbVisTjaenst.strTjaenstKod,
	dbo.tbVisTjaenst.strTjaenst,
	dbo.tbVisFakturatext.strFakturatextkod
	
FROM dbo.tbAehPblTaxa2011Tabell8

	LEFT OUTER JOIN dbo.tbVisFakturatext
	ON dbo.tbVisFakturatext.recFakturatextID = dbo.tbAehPblTaxa2011Tabell8.recFakturatextID
	
	LEFT OUTER JOIN dbo.tbVisTjaenst
	ON dbo.tbVisTjaenst.recTjaenstID = dbo.tbAehPblTaxa2011Tabell8.recTjaenstID


go

