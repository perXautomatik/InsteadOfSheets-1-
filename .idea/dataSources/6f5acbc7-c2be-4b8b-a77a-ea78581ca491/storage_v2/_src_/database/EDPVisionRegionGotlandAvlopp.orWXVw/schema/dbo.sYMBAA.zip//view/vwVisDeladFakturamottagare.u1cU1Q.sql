


CREATE VIEW [dbo].[vwVisDeladFakturamottagare]
AS

WITH KontaktKommunikationssaett AS (
SELECT recDeladFakturamottagareID, 
   

  (REPLACE( (SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett
    WHERE strKommunikationsaettTyp = 'Telefon' AND tbVisKommunikationssaett.recKommunikationssaettID IN 
      (SELECT recKommunikationssaettID FROM tbVisEnstakaKontaktKommunikationssaett 
        WHERE recEnstakaKontaktID =  tbVisDeladFakturamottagare.recEnstakaKontaktID
        
      )
    FOR XML PATH('')) + '...', ', ...','') 
  ) AS strTelefon,


  (REPLACE( (SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett
    WHERE strKommunikationsaettTyp = 'Mobil' AND tbVisKommunikationssaett.recKommunikationssaettID IN 
      (SELECT recKommunikationssaettID FROM tbVisEnstakaKontaktKommunikationssaett 
        WHERE recEnstakaKontaktID =  tbVisDeladFakturamottagare.recEnstakaKontaktID
        
      )
    FOR XML PATH('')) + '...', ', ...','') 
  ) AS strMobil	,

  (REPLACE( (SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett
    WHERE strKommunikationsaettTyp = 'Fax' AND tbVisKommunikationssaett.recKommunikationssaettID IN 
      (SELECT recKommunikationssaettID FROM tbVisEnstakaKontaktKommunikationssaett 
        WHERE recEnstakaKontaktID =  tbVisDeladFakturamottagare.recEnstakaKontaktID
        
      )
    FOR XML PATH('')) + '...', ', ...','') 
  ) AS strFax,	

  (REPLACE( (SELECT strVaerde + ', ' 
    FROM tbVisKommunikationssaett
    WHERE strKommunikationsaettTyp = 'E-post' AND tbVisKommunikationssaett.recKommunikationssaettID IN 
      (SELECT recKommunikationssaettID FROM tbVisEnstakaKontaktKommunikationssaett 
        WHERE recEnstakaKontaktID =  tbVisDeladFakturamottagare.recEnstakaKontaktID
        
      )
    FOR XML PATH('')) + '...', ', ...','') 
  ) AS strEpost	


FROM tbVisDeladFakturamottagare
)




SELECT  
			dbo.tbVisDeladFakturamottagare.recDeladFakturamottagareID, 
			dbo.tbVisEnstakaKontakt.strFoernamn, 
			dbo.tbVisEnstakaKontakt.strEfternamn, 
			dbo.tbVisEnstakaKontakt.strFoeretag, 
			dbo.tbVisEnstakaKontakt.strTitel, 
			dbo.tbVisEnstakaKontakt.strKontaktTyp, 
			dbo.tbVisEnstakaKontakt.strGatuadress, 
			dbo.tbVisEnstakaKontakt.strCoadress, 
			dbo.tbVisEnstakaKontakt.strPostnummer, 
			dbo.tbVisEnstakaKontakt.strPostort, 
			dbo.tbVisEnstakaKontakt.strLand, 
			dbo.tbVisEnstakaKontakt.strVisasSom, 
			dbo.tbVisEnstakaKontakt.strSammanslagenAdress, 
			dbo.tbVisDeladFakturamottagare.intIdNummer, 
			dbo.tbVisDeladFakturamottagare.strExterntIdNummer, 
			dbo.tbVisDeladFakturamottagare.strMotpartKoncernkod, 
			dbo.tbVisDeladFakturamottagare.strFoerklaring, 
			dbo.tbVisDeladFakturamottagare.strSkanningskod, 
			dbo.tbVisDeladFakturamottagare.bolIntern, 
			dbo.tbVisDeladFakturamottagare.strGLN,
			dbo.tbVisDeladFakturamottagare.strKommun, 
			dbo.tbVisDeladFakturamottagare.strReferensnummer, 
			dbo.tbVisEnstakaKontakt.strOrginisationPersonnummer, 
			dbo.tbVisDeladFakturamottagare.strIntBokfoeringsKonto, 
			dbo.tbVisDeladFakturamottagare.recDeladFakturamottagareID AS intRecnum, 
			dbo.tbVisEnstakaKontakt.recEnstakaKontaktID,
				KontaktKommunikationssaett.strTelefon,
				KontaktKommunikationssaett.strMobil,
				KontaktKommunikationssaett.strFax,
				KontaktKommunikationssaett.strEpost
FROM         
			dbo.tbVisDeladFakturamottagare 
INNER JOIN	dbo.tbVisEnstakaKontakt ON 
			dbo.tbVisDeladFakturamottagare.recEnstakaKontaktID = dbo.tbVisEnstakaKontakt.recEnstakaKontaktID

LEFT OUTER JOIN KontaktKommunikationssaett
  ON KontaktKommunikationssaett.recDeladFakturamottagareID = tbVisDeladFakturamottagare.recDeladFakturamottagareID



go

