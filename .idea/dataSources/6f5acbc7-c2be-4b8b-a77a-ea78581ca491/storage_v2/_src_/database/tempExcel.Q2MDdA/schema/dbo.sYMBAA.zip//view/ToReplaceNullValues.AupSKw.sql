CREATE VIEW dbo.ToReplaceNullValues
AS
SELECT        Diarienummer, Fastighet, Status, Anteckning
FROM            dbo.FlaggorUtanHändelseText
go

