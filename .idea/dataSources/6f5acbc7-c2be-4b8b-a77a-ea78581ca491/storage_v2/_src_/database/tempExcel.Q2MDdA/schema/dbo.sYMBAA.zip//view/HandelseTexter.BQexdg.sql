CREATE VIEW dbo.HändelseTexter
AS
SELECT        Fastighet, Diarienummer, Rubrik, Händelsedatum, Riktning, Text
FROM            dbo.HändelserFörbud12019
go

