CREATE VIEW dbo.FNRKIRDIARENR_FörUtskick
AS
SELECT        _KIR_ AS KIR, _FNR_ AS FNR, _ärendenr_ AS Diarienr
FROM            dbo.MedTypAvYta
go

